public class BlockPortalBoss : Block
{
	public BlockPortalBoss(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockPortalBoss(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	public override int GetExtraDropItem(int metaData)
	{
		return 0;
	}
}
