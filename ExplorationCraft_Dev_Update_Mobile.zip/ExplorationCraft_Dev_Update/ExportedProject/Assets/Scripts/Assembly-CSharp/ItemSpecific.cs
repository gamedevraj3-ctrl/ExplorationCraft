public struct ItemSpecific
{
	private static float[] maxSpecific;

	public int specificID;

	public float fillAmount;

	public ItemSpecific(int id, float specific)
	{
		specificID = 0;
		fillAmount = 0f;
	}
}
