using System;
using UnityEngine;

public class BlockWood : Block
{
	public BlockWood(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockWood(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	[Obsolete("To avoid data race, directly get color from biome")]
	public override Color ColorMultiplier(Map map, int worldX, int worldY, int worldZ)
	{
		return default;
	}

	public override Color ColorMultiplier(Biome biome, BlockType type)
	{
		return default;
	}
}
