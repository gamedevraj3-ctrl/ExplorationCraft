using UnityEngine;

public class BlockColorWood : Block
{
	public BlockColorWood(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockColorWood(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	public override Color ColorMultiplier(Biome biome, BlockType type)
	{
		return default;
	}
}
