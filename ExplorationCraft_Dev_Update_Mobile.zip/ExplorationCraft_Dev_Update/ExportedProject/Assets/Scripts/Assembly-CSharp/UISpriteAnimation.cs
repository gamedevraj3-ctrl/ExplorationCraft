using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(UISprite))]
[ExecuteInEditMode]
[AddComponentMenu("NGUI/UI/Sprite Animation")]
public class UISpriteAnimation : MonoBehaviour
{
	[HideInInspector]
	[SerializeField]
	private int mFPS;

	[HideInInspector]
	[SerializeField]
	private string mPrefix;

	[SerializeField]
	[HideInInspector]
	private bool mLoop;

	private UISprite mSprite;

	private float mDelta;

	private int mIndex;

	private bool mActive;

	private List<string> mSpriteNames;

	public int frames => 0;

	public int framesPerSecond
	{
		get
		{
			return 0;
		}
		set
		{
		}
	}

	public string namePrefix
	{
		get
		{
			return null;
		}
		set
		{
		}
	}

	public bool loop
	{
		get
		{
			return false;
		}
		set
		{
		}
	}

	public bool isPlaying => false;

	private void Start()
	{
	}

	private void Update()
	{
	}

	private void RebuildSpriteList()
	{
	}

	public void Reset()
	{
	}
}
