using UnityEngine;

public class NewUIPlaying : NewUIBase
{
	public enum MountState
	{
		Summon = 0,
		Dismount = 1
	}

	public UIPanel uiPanel;

	public JoyStick joyStick;

	public NewUIItemPackageEntry[] itemEntrys;

	public UIButton btPackage;

	public ItemPackage itemPackage;

	public int currentSelect;

	public UILabel txtBiome;

	public UISprite dropPercentageMask;

	public UIButton btShoot;

	public UIButton btGain;

	public UIButton[] btMountGroup;

	public UISprite btShootMask;

	public UISprite btGainMask;

	public UISprite[] imgShootMagic;

	public UISprite[] imgGainMagic;

	public UISprite missionHint;

	public UITweener missionHintTweener;

	public GameObject statusHealth;

	public GameObject statusArmour;

	public GameObject statusFood;

	public GameObject statusMagic;

	public UILabel txtCoin;

	public UILabel txtGem;

	public GameObject objBtShoot;

	public GameObject objBtGain;

	public GameObject objBtMount;

	public GameObject objBtJump;

	public UISprite imgSummon;

	public UISprite imgDismount;

	public UISprite bossHealthBack;

	public UISprite bossHealthFore;

	public GameObject btPause;

	public GameObject shortPackage;

	public GameObject buttonMask;

	public UISprite imgPackage;

	public Transform btDismountTr;

	public GameObject objPlayerStatus;

	public UISprite imgHealth;

	public UISprite imgHealthBack;

	public UISprite imgHealthContainer;

	public UISprite imgFood;

	public UISprite imgFoodBack;

	public UISprite imgFoodContainer;

	public void InitialItemPackage()
	{
	}

	public void ShowShortPackage()
	{
	}

	public void HideShortPackage()
	{
	}

	public NewUIItemPackageEntry GetItemEntry(int itemID)
	{
		return null;
	}

	public void ShowHealth()
	{
	}

	public void ShowFood()
	{
	}

	public void RefreshPanel()
	{
	}

	public void ShowJumpButton()
	{
	}

	public void ShowMountButton()
	{
	}

	public override void Show()
	{
	}

	public override void Hide()
	{
	}

	public void RefreshShortPackage()
	{
	}

	public void ShowUIPackage()
	{
	}

	public void SetSelect(int index, bool playSound = true)
	{
	}

	public void ResetSelectItem()
	{
	}

	public void RefreshMagicButton()
	{
	}

	public void ShowDropPercentage(float fillAmount)
	{
	}

	private void ResetDropPercentagePosition(Vector3 position)
	{
	}

	public void HideDropPercentage()
	{
	}

	public void RefreshMoney()
	{
	}

	public void ShowInAppPurchaseCoin()
	{
	}

	public void ShowInAppPurchaseGem()
	{
	}

	public void SetBossHealthVisibility(bool visiable)
	{
	}

	public void SetBossHealth(float radio)
	{
	}

	private void RefreshButtonState()
	{
	}

	private void ResetMagicButtons()
	{
	}

	public void SetMountButton(MountState state)
	{
	}

	public void ShowMissionHint()
	{
	}

	public void ClearMissionHint()
	{
	}
}
