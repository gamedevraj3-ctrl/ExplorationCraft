using UnityEngine;

public class UIItemName : MonoBehaviour
{
	public UILabel itemName;

	private float timeFlag;

	private const float SHOW_TIME_DURATION = 2f;

	private void Update()
	{
	}

	public void SetName(string name)
	{
	}

	public void Hide()
	{
	}
}
