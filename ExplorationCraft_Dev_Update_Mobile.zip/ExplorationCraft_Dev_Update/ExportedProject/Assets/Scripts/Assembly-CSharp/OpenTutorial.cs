public class OpenTutorial : Tutorial
{
	public OpenTutorial(string description)
	{
	}

	public override void Enter()
	{
	}

	public override bool CheckComplete()
	{
		return false;
	}

	public override void OnComplete()
	{
	}
}
