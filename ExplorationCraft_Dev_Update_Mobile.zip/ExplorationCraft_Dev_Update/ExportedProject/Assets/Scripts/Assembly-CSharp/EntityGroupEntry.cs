public class EntityGroupEntry
{
	public int entityID;

	public int probabilityPermillage;

	public int minGroupCount;

	public int maxGroupCount;

	public EntityGroupEntry(int id, int probability, int minCount, int maxCount)
	{
	}
}
