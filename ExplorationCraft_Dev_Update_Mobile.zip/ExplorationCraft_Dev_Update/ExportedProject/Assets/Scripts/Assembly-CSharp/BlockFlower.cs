public class BlockFlower : Block
{
	private float[] flowerAABBOffset;

	public BlockFlower(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockFlower(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	public override void GenBlockMesh(MeshGenerator meshGenerator, Map map, int blockX, int blockY, int blockZ, Chunk chunk, int x, int y, int z, byte blockLight)
	{
	}

	public override float[] GetAABBOffset(int metaData)
	{
		return null;
	}

	public override DiggingConvertType ConvertAfterDiggingAround(BlockFromDirection direction, int metaData)
	{
		return DiggingConvertType.None;
	}

	public override bool CanPlaceBlockAt(Block attachBlock, BlockFromDirection direction)
	{
		return false;
	}
}
