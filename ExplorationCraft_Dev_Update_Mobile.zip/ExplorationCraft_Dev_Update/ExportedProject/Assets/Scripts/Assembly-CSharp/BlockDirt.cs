public class BlockDirt : Block
{
	public BlockDirt(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockDirt(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	public override bool NeedRandomUpdate()
	{
		return false;
	}

	public override void UpdateTick(World world, Chunk chunk, int x, int y, int z)
	{
	}
}
