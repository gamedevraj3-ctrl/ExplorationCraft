using UnityEngine;

public class UIEquipShowStatusEvent : MonoBehaviour
{
	public NewUITabEquip uiTabEquip;

	public Transform target;

	public float speed;

	private void Start()
	{
	}

	private void SpriteClick(GameObject go)
	{
	}

	private void OnDrag(Vector2 delta)
	{
	}
}
