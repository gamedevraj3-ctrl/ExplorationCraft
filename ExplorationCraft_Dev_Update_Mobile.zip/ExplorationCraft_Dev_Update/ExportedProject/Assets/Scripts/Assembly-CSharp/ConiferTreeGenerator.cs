using System;

public class ConiferTreeGenerator : DecorationGenerator, ITreeGenerator
{
	private int size;

	private int minHeight;

	private int maxLevelCount;

	private int countPerChunk;

	private int probabilityPercentage;

	public ConiferTreeGenerator(int minHeight, int maxLevelCount, int count, int probabilityPercentage)
	{
	}

	public bool Generate(int worldX, int worldY, int worldZ)
	{
		return false;
	}

	public override void Decorate(Chunk chunk, Random rand)
	{
	}

	private bool CheckValidity(int x, int y, int z, int height)
	{
		return false;
	}

	private void GenerateTree(int x, int y, int z, int height, int levelCount, Random rand, bool updateHeight = false)
	{
	}
}
