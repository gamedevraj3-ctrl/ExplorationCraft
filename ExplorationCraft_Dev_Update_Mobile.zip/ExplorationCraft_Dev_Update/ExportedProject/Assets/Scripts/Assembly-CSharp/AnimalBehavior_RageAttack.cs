using BehaviorTree;
using UnityEngine;

public class AnimalBehavior_RageAttack : AnimalBehavior_AttackTarget
{
	public AnimalBehavior_RageAttack(BevNode _o_ParentNode, Entity _targetEntity, Vector3 _dashSpeed, float _hitTime, float _attackDuration, float _cooltime)
		: base(null, null, default, 0f, 0f, 0f)
	{
	}

	protected override void _DoExit(object input, BevRunningStatus _ui_ExitID)
	{
	}

	protected override bool _DoEvaluate(object input)
	{
		return false;
	}
}
