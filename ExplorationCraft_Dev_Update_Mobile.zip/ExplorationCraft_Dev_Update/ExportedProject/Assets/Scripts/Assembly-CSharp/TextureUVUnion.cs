using System;
using UnityEngine;

[Serializable]
public class TextureUVUnion
{
	public int id;

	public Rect uv;

	public TextureUVUnion(int id, Rect uv)
	{
	}
}
