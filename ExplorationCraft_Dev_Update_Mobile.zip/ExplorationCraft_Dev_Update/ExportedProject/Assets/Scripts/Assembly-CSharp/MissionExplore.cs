public class MissionExplore : Mission
{
	private int biomeID;

	public MissionExplore(string description, int param, IMissionPrecondition precondition, int experience, int type, int money)
		: base(null, 0, null, 0, 0, 0)
	{
	}

	public MissionExplore(string description, int param, IMissionPrecondition precondition, int biomeID, int experience, int type, int money)
		: base(null, 0, null, 0, 0, 0)
	{
	}

	public override void SetActive()
	{
	}

	public override bool CheckComplete()
	{
		return false;
	}

	public override void OnComplete()
	{
	}

	public override string GetDescription()
	{
		return null;
	}

	public override string GetProgress()
	{
		return null;
	}
}
