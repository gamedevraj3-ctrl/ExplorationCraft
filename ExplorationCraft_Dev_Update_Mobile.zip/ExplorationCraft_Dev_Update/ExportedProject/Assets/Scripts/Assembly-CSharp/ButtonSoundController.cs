using UnityEngine;

public class ButtonSoundController : MonoInstance<ButtonSoundController>
{
	public AudioSource buttonAudio;

	private void Start()
	{
	}

	public void Play()
	{
	}

	public void SetEnable(bool enable)
	{
	}
}
