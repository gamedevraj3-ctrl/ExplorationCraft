using System;
using UnityEngine;

public class BlockLeaves : Block
{
	private const float orangeDropRatio = 0.02f;

	private const float saplingDropRatio = 0.05f;

	public BlockLeaves(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockLeaves(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	[Obsolete("To avoid data race, directly get color from biome")]
	public override Color ColorMultiplier(Map map, int worldX, int worldY, int worldZ)
	{
		return default;
	}

	public override Color ColorMultiplier(Biome biome, BlockType type)
	{
		return default;
	}

	public override int GetExtraDropItem(int metaData)
	{
		return 0;
	}
}
