public class BlockDoorBottom : Block
{
	private static float[][] doorAABBOffset;

	public static int[] indexTransform;

	public BlockDoorBottom(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockDoorBottom(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	public override bool OnHit(AABB hitAABB)
	{
		return false;
	}

	public override bool CanPlaceBlockAt(Block attachBlock, BlockFromDirection direction)
	{
		return false;
	}

	public override void GenBlockMesh(MeshGenerator meshGenerator, Map map, int blockX, int blockY, int blockZ, Chunk chunk, int x, int y, int z, byte blockLight)
	{
	}

	public override float[] GetAABBOffset(int metaData)
	{
		return null;
	}

	public override DiggingConvertType ConvertAfterDiggingAround(BlockFromDirection direction, int metaData)
	{
		return DiggingConvertType.None;
	}
}
