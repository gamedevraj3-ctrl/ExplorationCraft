using UnityEngine;

public class MockInput
{
	public enum InputType
	{
		None = 0,
		Up = 1,
		Down = 2,
		Stay = 3
	}

	public bool IsEnabled { get; set; }

	public Vector2 TouchPosition { get; set; }

	public InputType TouchType { get; set; }

	public void SetStayPosition(Vector2 position)
	{
	}

	public void CancelInput()
	{
	}
}
