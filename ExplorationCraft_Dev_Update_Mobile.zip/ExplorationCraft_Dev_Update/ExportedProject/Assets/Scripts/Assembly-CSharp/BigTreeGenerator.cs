using System;

public class BigTreeGenerator : DecorationGenerator
{
	private int size;

	private int minHeight;

	private int maxHeight;

	private int countPerChunk;

	private int probabilityPercentage;

	public BigTreeGenerator(int minHeight, int maxHeight, int count, int probabilityPercentage)
	{
	}

	public override void Decorate(Chunk chunk, Random rand)
	{
	}
}
