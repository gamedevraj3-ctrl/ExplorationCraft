using UnityEngine;

public class UIMountArrowButtonEvent : MonoBehaviour
{
	public enum ArrowType
	{
		Prev = 0,
		Succ = 1
	}

	public NewUITabMount uiMount;

	public ArrowType type;

	private void Start()
	{
	}

	private void ButtonClick(GameObject go)
	{
	}
}
