public class EntityDragonFireBall : EntityMagic
{
	public override void MoveEntity(float x, float y, float z)
	{
	}

	private void OnExplode()
	{
	}
}
