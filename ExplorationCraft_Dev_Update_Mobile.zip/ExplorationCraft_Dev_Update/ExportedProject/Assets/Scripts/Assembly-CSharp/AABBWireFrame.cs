using UnityEngine;

public class AABBWireFrame : MonoInstance<AABBWireFrame>
{
	private Mesh mesh;

	private MeshFilter mf;

	private Vector3 meshScale;

	private bool isShow;

	private Vector3[] initVertices;

	private Vector3[] vertices;

	private void Start()
	{
	}

	public void Show()
	{
	}

	public void Hide()
	{
	}

	public void SetByAABB(AABB aabb)
	{
	}

	private void RegenerateMesh(Vector3 size)
	{
	}
}
