namespace AStar3D
{
	public class Node3D
	{
		public int x;

		public int y;

		public int z;

		public Node3D parent;

		public int f;

		public int g;

		public int h;

		public int visitFlag;

		public bool isObstacle()
		{
			return false;
		}

		public bool canVisited()
		{
			return false;
		}

		public bool isInOpenTable()
		{
			return false;
		}

		public void addToCloseTable()
		{
		}

		public void addToOpenTable()
		{
		}
	}
}
