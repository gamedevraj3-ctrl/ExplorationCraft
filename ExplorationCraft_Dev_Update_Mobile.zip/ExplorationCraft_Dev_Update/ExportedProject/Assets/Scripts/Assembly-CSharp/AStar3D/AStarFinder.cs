using System.Collections.Generic;

namespace AStar3D
{
	public class AStarFinder
	{
		private List<Node3D> openList;

		private Map3D map3D;

		private Node3D startNode;

		private Node3D endNode;

		private int[] neighborOffsetXList;

		private int[] neighborOffsetZList;

		private int[] neighborOffsetYList;

		private float[] move2NeighborCostList;

		public void findPath(int xStart, int yStart, int zStart, int xEnd, int yEnd, int zEnd)
		{
		}

		private bool checkNeighbors(Node3D currentNode)
		{
			return false;
		}

		private bool canFromTo(Node3D fromNode, Node3D toNode)
		{
			return false;
		}

		private bool canNodeStay(Node3D node)
		{
			return false;
		}

		private void checkNode(Node3D node, Node3D parent, int neighborIndex)
		{
		}

		public void addToOpenList(Node3D node)
		{
		}

		public void addToCloseList(Node3D node)
		{
		}

		public Node3D getMinFNode()
		{
			return null;
		}

		public int calcH(int x, int y)
		{
			return 0;
		}
	}
}
