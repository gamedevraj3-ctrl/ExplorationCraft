namespace AStar3D
{
	public class Map3D
	{
		private Node3D[,,] map;

		public int xLength;

		public int yLength;

		public int zLength;

		private Map3D()
		{
		}

		public static Map3D newMap(int[,,] mapFlags)
		{
			return null;
		}

		public Node3D getNode(int x, int y, int z)
		{
			return null;
		}

		public void reset()
		{
		}
	}
}
