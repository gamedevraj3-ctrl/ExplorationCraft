using BehaviorTree;
using UnityEngine;

public class AnimalBehavior_AttackTarget : BevNodeTerminal
{
	public Entity targetEntity;

	private Vector3 direction;

	private float timeFlag;

	private float endTime;

	private float hitTime;

	private bool isHitted;

	private float attackDuration;

	private float cooltime;

	private Vector3 attackDashSpeed;

	protected EntityAttackType attackType;

	public AnimalBehavior_AttackTarget(BevNode _o_ParentNode, Entity _targetEntity, Vector3 _dashSpeed, float _hitTime, float _attackDuration, float _cooltime)
		: base(null)
	{
	}

	protected override void _DoEnter(object input)
	{
	}

	protected override BevRunningStatus _DoExecute(object input, object output)
	{
		return BevRunningStatus.k_BRS_Executing;
	}

	protected override void _DoExit(object input, BevRunningStatus _ui_ExitID)
	{
	}

	protected override bool _DoEvaluate(object input)
	{
		return false;
	}
}
