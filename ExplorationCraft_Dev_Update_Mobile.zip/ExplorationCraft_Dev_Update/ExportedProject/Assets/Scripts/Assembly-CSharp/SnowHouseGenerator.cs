using System;

public class SnowHouseGenerator : DecorationGenerator
{
	private int size;

	private int probabilityPermillage;

	public SnowHouseGenerator(int size, int probability)
	{
	}

	public override void Decorate(Chunk chunk, Random rand)
	{
	}
}
