public class BlockCraftingTable : Block
{
	public BlockCraftingTable(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockCraftingTable(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	public override bool OnHit(AABB hitAABB)
	{
		return false;
	}
}
