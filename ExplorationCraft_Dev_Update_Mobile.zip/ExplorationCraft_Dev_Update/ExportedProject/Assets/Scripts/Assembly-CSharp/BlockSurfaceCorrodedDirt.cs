public class BlockSurfaceCorrodedDirt : Block
{
	public BlockSurfaceCorrodedDirt(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockSurfaceCorrodedDirt(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	public override int GetDropItem(int metaData)
	{
		return 0;
	}
}
