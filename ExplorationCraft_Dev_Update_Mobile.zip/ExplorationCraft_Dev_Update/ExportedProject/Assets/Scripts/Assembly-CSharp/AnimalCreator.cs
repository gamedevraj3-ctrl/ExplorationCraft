using System;
using System.Collections.Generic;
using UnityEngine;

public class AnimalCreator : MonoInstance<AnimalCreator>
{
	public const int ANIMAL_COUNT = 19;

	public PrefabListFacade prefabListFacade;

	public List<EntityLiving>[] storedEntityTable;

	public List<EntityLiving>[] usingEntityTable;

	public int[] maxCountList;

	private int maxAnimalCount;

	private Queue<AnimalCreateRequest> createRequest;

	private Queue<EntityLiving> recycleRequest;

	public const float distanceXZToRecycle = 128f;

	public Vector2 createRange;

	private System.Random animalRG;

	public int TotalCreatedEntity => 0;

	private new void Awake()
	{
	}

	public void IncreaseMaxCountByMapSize(int mapSizeLevel)
	{
	}

	private void Update()
	{
	}

	public void AddCreateRequest(AnimalCreateRequest request)
	{
	}

	public void AddRecycleRequest(EntityLiving entity)
	{
	}

	public EntityLiving Create(AnimalCreateRequest request)
	{
		return null;
	}

	public void Recycle(EntityLiving entity)
	{
	}

	public int GetCurrentAnimalCount()
	{
		return 0;
	}

	public int GetMaxAnimalCount()
	{
		return 0;
	}

	public int GetCurrentCount(AnimalType type)
	{
		return 0;
	}

	public int GetMaxCount(AnimalType type)
	{
		return 0;
	}

	public void SpawnAnimalsOnChunkLoaded(Map map, System.Random random, Biome biome, int worldX, int worldZ)
	{
	}

	public void SpawnRandomAnimalsOnChunkLoaded(Chunk chunk)
	{
	}

	public void RecycleAllUnused()
	{
	}

	public EntityBoss SpawnBoss(int entityID, Vector3 position, List<DropoutUnion> dropoutItems, float healthRadio, float damageRadio, float defenseRadio)
	{
		return null;
	}

	public EntityLiving GetTargetEntity(int entityID)
	{
		return null;
	}
}
