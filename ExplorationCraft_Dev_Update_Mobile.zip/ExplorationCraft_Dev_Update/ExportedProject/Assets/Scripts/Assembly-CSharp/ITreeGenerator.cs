public interface ITreeGenerator
{
	bool Generate(int x, int y, int z);
}
