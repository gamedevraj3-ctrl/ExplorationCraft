using BehaviorTree;
using UnityEngine;

public class AnimalBehavior_CoolDown : BevNodeTerminal
{
	protected float coolTime;

	private float timeFlag;

	private Vector3 direction;

	public AnimalBehavior_CoolDown(BevNode _o_ParentNode)
		: base(null)
	{
	}

	protected override void _DoEnter(object input)
	{
	}

	protected override BevRunningStatus _DoExecute(object input, object output)
	{
		return BevRunningStatus.k_BRS_Executing;
	}

	protected override bool _DoEvaluate(object input)
	{
		return false;
	}
}
