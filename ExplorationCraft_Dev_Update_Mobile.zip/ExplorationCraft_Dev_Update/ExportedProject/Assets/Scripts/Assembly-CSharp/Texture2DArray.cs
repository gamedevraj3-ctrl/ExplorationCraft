using System;
using UnityEngine;

[Serializable]
public class Texture2DArray
{
	public Texture2D[] textures;

	public bool isTransparent;
}
