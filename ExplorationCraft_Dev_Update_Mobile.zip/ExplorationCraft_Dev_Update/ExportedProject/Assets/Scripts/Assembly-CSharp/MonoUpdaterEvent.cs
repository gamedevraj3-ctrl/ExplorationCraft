public delegate void MonoUpdaterEvent();
