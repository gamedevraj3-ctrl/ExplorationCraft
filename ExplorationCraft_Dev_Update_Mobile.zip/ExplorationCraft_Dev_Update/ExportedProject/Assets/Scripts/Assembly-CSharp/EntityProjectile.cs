using LibNbt.Tags;
using UnityEngine;

public class EntityProjectile : Entity
{
	public ProjectileType projectileType;

	public CollideLayer targetCollideLayer;

	public float damage;

	public Quaternion targetRot;

	public int buffLevel;

	public Vector3 sourcePos;

	protected bool isHitted;

	public override void Reset()
	{
	}

	public override void MoveEntity(float x, float y, float z)
	{
	}

	public float GetDistanceFromPlayer()
	{
		return 0f;
	}

	public override NbtCompound GetNbtData()
	{
		return null;
	}

	protected virtual void OnPostHit()
	{
	}

	public virtual void OnPostRecycle()
	{
	}
}
