using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class AtlasTexture
{
	public Texture2D texture;

	public List<Rect> uv;
}
