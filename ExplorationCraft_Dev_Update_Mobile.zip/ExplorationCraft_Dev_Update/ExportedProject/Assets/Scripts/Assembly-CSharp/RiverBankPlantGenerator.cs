using System;

public class RiverBankPlantGenerator : DecorationGenerator
{
	private BlockType blockType;

	private int minSize;

	private int maxSize;

	private int maxHeight;

	private int maxHeightOnSurface;

	private int countPerChunk;

	private int probabilityPercentage;

	public RiverBankPlantGenerator(BlockType blockType, int minSize, int maxSize, int maxHeight, int maxHeightOnSurface, int count, int probabilityPercentage)
	{
	}

	public override void Decorate(Chunk chunk, Random rand)
	{
	}
}
