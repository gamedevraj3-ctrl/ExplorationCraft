using UnityEngine;

public class UISelectTutorialEntry : MonoBehaviour
{
	public UILabel nameLabel;

	public UITutorialSelect uiTutorialSelect;

	private void Start()
	{
	}

	private void ButtonClick(GameObject go)
	{
	}

	public void Show()
	{
	}

	public void Hide()
	{
	}

	public void SetInfo(WorldInfo worldInfo)
	{
	}
}
