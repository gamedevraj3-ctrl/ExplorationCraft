public class MoneyFileReader
{
	private const string REVIVE_MONEY_FILE_NAME = "Revive_Money";

	private const string SAVE_SLOT_MONEY_FILE_NAME = "Save_Slot_Money";

	private const string INVENTORY_EXPAND_MONEY_FILE_NAME = "Inventory_Expand_Money";

	public static bool SetConsumableMoney()
	{
		return false;
	}

	private static bool SetReviveMoney()
	{
		return false;
	}

	private static bool SetSaveSlotMoney()
	{
		return false;
	}

	private static bool SetInventoryExpandMoney()
	{
		return false;
	}
}
