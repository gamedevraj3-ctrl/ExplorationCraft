using System.Collections.Generic;

public class ChestPackageController
{
	private Dictionary<Vector3i, ItemPackage> usingPackageDictionary;

	private Stack<ItemPackage> packagePool;

	private const int CHEST_PACKAGE_CAPACITY = 36;

	public ItemPackage Register(Vector3i key)
	{
		return null;
	}

	public void Unregister(Vector3i key, bool clearChunkData)
	{
	}

	public ItemPackage GetPackage(Vector3i key)
	{
		return null;
	}
}
