using System.Collections.Generic;

public class LightProcessor
{
	private readonly IBatchProcessor<Chunk> m_BatchProcessor;

	private readonly Map map;

	public int numberOfLightShades;

	public byte[] shadesOfLight;

	private List<Vector3i> referedBlockList;

	private bool isSetChunkLightDirt;

	public LightProcessor(IBatchProcessor<Chunk> batchProcessor, Map worldData)
	{
	}

	private void SetShadesOfLight(int numberOfShadesOfLight)
	{
	}

	private void FixHeightMap(Chunk chunk)
	{
	}

	private void FixChunksHeightmap(List<Chunk> chunks)
	{
	}

	public void LightChunks(List<Chunk> chunks)
	{
	}

	public void GenLight(Chunk chunk)
	{
	}

	public void SpreadExtBoundarySkyLight(List<Chunk> chunks)
	{
	}

	public void SpreadExtBoundarySkyLight(Chunk chunk)
	{
	}

	private void LightChunk(Chunk chunk)
	{
	}

	private void SetBlockLightInChunk(Chunk chunk)
	{
	}

	private void SetSkyLightInChunk(Chunk chunk)
	{
	}

	private int GetHeight(int xWorld, int zWorld)
	{
		return 0;
	}

	private int GetHeightInChunk(Chunk chunk, int x, int z)
	{
		return 0;
	}

	private void LightNeighborHeightInChunk(Chunk chunk, int x, int z)
	{
	}

	private void LightNeighborHeight(int xWorld, int zWorld)
	{
	}

	private void LightNeighborInHeight(Chunk chunk, int localX, int localZ)
	{
	}

	private void SpreadSkyLightAroundInChunk(Chunk chunk, int x, int y, int z, int lightIndex)
	{
	}

	private void SpreadSkyLightAround(int x, int y, int z, int lightIndex)
	{
	}

	private void SpreadBlockLightAround(int x, int y, int z, int lightIndex)
	{
	}

	private void SpreadBlockLightRecursive(int x, int y, int z, int lightIndex)
	{
	}

	private void SpreadSkyLightRecursiveInChunk(Chunk chunk, int x, int y, int z, int lightIndex)
	{
	}

	private void SpreadSkyLightRecursive(int x, int y, int z, int lightIndex)
	{
	}

	private void FindSkyLightReferedBlocks(int x, int y, int z)
	{
	}

	private void FindSkyLightReferedBlocksRecursive(int x, int y, int z, byte light)
	{
	}

	public void RecalculateSkyLightAround(int x, int y, int z, byte lightTo)
	{
	}

	public void RecalculateSkyLightAroundOnTop(int x, int z, int originHeight, int newHeight)
	{
	}

	public void RecalculateSkyLightAround(int x, int y, int z)
	{
	}

	private void RecalculateSkyLightAroundRecursive(int x, int y, int z)
	{
	}

	private void FindReferedBlocks(int x, int y, int z)
	{
	}

	private void FindReferedBlocksRecursive(int x, int y, int z, byte light)
	{
	}

	public void RecalculateBlockLightAround(int x, int y, int z, byte lightTo)
	{
	}

	public void RecalculateBlockLightAround(int x, int y, int z)
	{
	}

	private void RecalculateBlockLightAroundRecursive(int x, int y, int z)
	{
	}
}
