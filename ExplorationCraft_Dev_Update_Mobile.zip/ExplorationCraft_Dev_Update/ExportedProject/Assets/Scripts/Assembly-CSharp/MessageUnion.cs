public class MessageUnion
{
	public string message;

	public bool showHint;

	public MessageUnion(string message, bool showHint)
	{
	}
}
