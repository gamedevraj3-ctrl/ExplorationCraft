using UnityEngine;

public class GameSceneController : MonoInstance<GameSceneController>
{
	private World world;

	public NewUIPlaying uiPlaying;

	public NewUIPackage uiPackage;

	public NewUIConverter uiConverter;

	public UIMessage uiMessage;

	public UIPause uiPause;

	public UIShop uiShop;

	public UIChest uiChest;

	public UIPortal uiPortal;

	public UIRevive uiRevive;

	public UIPurchaseComfirmation uiPurchaseComfirmation;

	public UIInAppPurchase uiInAppPurchase;

	public UIRoot uiRoot;

	public UIVideoComfirmation uiVideoComfirmation;

	public UIVideoComfirmation uiVideoReward;

	public NewUITabItems uiTabItems;

	public UISprite blackMask;

	public TweenAlpha blackMaskTweener;

	public Color grassColor;

	public Color grassLandColor;

	public Color leavesColor;

	public Color brickColor;

	public Color[] woodColor;

	public Color corrodedGrassColor;

	public Color corrodedLeavesColor;

	public Color corrodedWoodColor;

	public Color globalColor;

	public DiggingProgress diggingProgress;

	public UIGainMagic uiGainMagic;

	public UISlider progressBar;

	public GameObject uiProgress;

	public UILabel txtTips;

	public AdDisplayManager adDisplayManager;

	private void Start()
	{
	}

	private void AdaptiveUI()
	{
	}

	private void Update()
	{
	}

	public void ShowMissionDescription(Mission mission)
	{
	}

	public void ShowMissionCompleted(Mission mission)
	{
	}

	public void OnPause()
	{
	}

	public void OnResume()
	{
	}

	public void ShowFurnanceInterface(AABB aabb, bool isOven)
	{
	}

	public void ShowCraftingInterface()
	{
	}

	public void ShowPortalInterface(Vector3i key)
	{
	}

	public void ShowPortalBossInterface()
	{
	}

	public void HidePortalInterface()
	{
	}

	public void ShowChestInterface(Vector3i key)
	{
	}

	public void HideChestInterface()
	{
	}

	public void TweenBlackMask()
	{
	}

	public void HideBlackMask()
	{
	}

	public void BackToTitle()
	{
	}

	public void ShowProgress()
	{
	}

	public void SetLoadedProgress(float loadedProgress)
	{
	}

	public void HideProgress()
	{
	}

	public void SetRenderLevel(int level)
	{
	}

	public void ShowRevive()
	{
	}

	public void HideRevive()
	{
	}
}
