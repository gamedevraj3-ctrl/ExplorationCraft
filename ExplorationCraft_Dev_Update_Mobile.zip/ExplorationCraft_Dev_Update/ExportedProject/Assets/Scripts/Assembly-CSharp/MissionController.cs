using System.Collections.Generic;

public class MissionController : MonoInstance<MissionController>
{
	public int maxActiveMissionCount;

	public KillCounter killCounter;

	private MissionTopology missionData;

	private List<TopologyNode> activeMission;

	private List<TopologyNode> newActiveMission;

	public List<TopologyNode> ActivedMission => null;

	private new void Awake()
	{
	}

	public MissionTopology GetMissionData()
	{
		return null;
	}

	public List<MissionProgressUnion> GetMissionProgress()
	{
		return null;
	}

	public void SetMissionProgress(List<MissionProgressUnion> missionProgressList)
	{
	}

	private void Update()
	{
	}

	public bool HasNotClaimed()
	{
		return false;
	}
}
