public class EntityHen : EntityLiving
{
	protected override void AddExtraBevTreeNode()
	{
	}

	protected override void SpawnFavorParticle()
	{
	}
}
