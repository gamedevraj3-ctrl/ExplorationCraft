using UnityEngine;

public class UISelectWorldEntry : MonoBehaviour
{
	public UILabel nameLabel;

	public UISelect uiSelect;

	public UISprite imgDelete;

	public UILabel txtTime;

	public UILabel txtSize;

	public UIInput inputField;

	public BoxCollider inputBoxCollider;

	public UISprite outBoundary;

	public UIButton[] buttonArray;

	private WorldInfo worldInfo;

	private void Start()
	{
	}

	private void ButtonClick(GameObject go)
	{
	}

	public void Show()
	{
	}

	public void Hide()
	{
	}

	public void SetInfo(WorldInfo worldInfo, UISelect.SelectMode mode)
	{
	}

	public void Delete()
	{
	}

	private void OnInputFinished()
	{
	}
}
