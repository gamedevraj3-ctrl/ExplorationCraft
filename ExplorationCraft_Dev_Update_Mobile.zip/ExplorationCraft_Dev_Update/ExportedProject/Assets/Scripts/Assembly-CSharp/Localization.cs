using System.Collections.Generic;
using UnityEngine;

[AddComponentMenu("NGUI/Internal/Localization")]
public class Localization : MonoBehaviour
{
	private static Localization mInstance;

	public string startingLanguage;

	public TextAsset[] languages;

	private Dictionary<string, string> mDictionary;

	private string mLanguage;

	public static bool isActive => false;

	public static Localization instance => null;

	public string currentLanguage
	{
		get
		{
			return null;
		}
		set
		{
		}
	}

	private void Awake()
	{
	}

	private void OnEnable()
	{
	}

	private void OnDestroy()
	{
	}

	public void Load(TextAsset asset)
	{
	}

	public void Set(string languageName, Dictionary<string, string> dictionary)
	{
	}

	public string Get(string key)
	{
		return null;
	}

	public static string Localize(string key)
	{
		return null;
	}
}
