public class BlockFire : Block
{
	private int[] chanceToEncourageFire;

	private int[] abilityToCatchFire;

	private Vector3i[] neighborsOffsetList;

	public BlockFire(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockFire(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	private void SetBurnRate(int blockType, int chanceToEncourage, int abilityToCatch)
	{
	}

	private void TryToCatchBlockOnFire(World world, int x, int y, int z, int maxRandom, int metaData)
	{
	}

	public bool CanBlockCatchFire(Map map, int x, int y, int z)
	{
		return false;
	}

	public bool CanBlockCatchFire(BlockType blockType)
	{
		return false;
	}

	private bool CanNeighborBurn(World world, int x, int y, int z)
	{
		return false;
	}

	private int GetChanceOfNeighborsEncouragingFire(World world, int x, int y, int z)
	{
		return 0;
	}

	public new bool CanPlaceBlockAt(World world, int x, int y, int z)
	{
		return false;
	}

	public bool DoesBlockHaveSolidTopSurface(Map map, int x, int y, int z)
	{
		return false;
	}

	public override bool NeedUpdate()
	{
		return false;
	}

	public override void UpdateTick(World world, Chunk chunk, int x, int y, int z)
	{
	}

	public override void GenBlockMesh(MeshGenerator meshGenerator, Map map, int blockX, int blockY, int blockZ, Chunk chunk, int x, int y, int z, byte blockLight)
	{
	}

	public override bool CanPlaceBlockAt(Block attachBlock, BlockFromDirection direction)
	{
		return false;
	}

	public override int GetDropItem(int metaData)
	{
		return 0;
	}
}
