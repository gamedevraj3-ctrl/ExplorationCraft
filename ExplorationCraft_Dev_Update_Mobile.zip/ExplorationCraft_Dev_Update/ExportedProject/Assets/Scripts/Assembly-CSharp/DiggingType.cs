public enum DiggingType : byte
{
	Wood = 0,
	Stone = 1,
	Dirt = 2,
	Leaves = 11,
	None = 12
}
