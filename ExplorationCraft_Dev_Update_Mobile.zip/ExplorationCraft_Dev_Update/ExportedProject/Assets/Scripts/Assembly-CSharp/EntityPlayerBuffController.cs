public class EntityPlayerBuffController
{
	public GainType buffType;

	private EntityPlayer player;

	private float lastBuffChangeTime;

	public float buffAddition;

	public float buffDuration;

	public float RestTime
	{
		get
		{
			return 0f;
		}
		set
		{
		}
	}

	public float IceDefense => 0f;

	public EntityPlayerBuffController(EntityPlayer player)
	{
	}

	public void Update()
	{
	}

	public void SetBuff(GainType buffType, float addition, float duration)
	{
	}
}
