using System;
using UnityEngine;

public class BlockCorrodedLeaves : Block
{
	public BlockCorrodedLeaves(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockCorrodedLeaves(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	[Obsolete("To avoid data race, directly get color from biome")]
	public override Color ColorMultiplier(Map map, int worldX, int worldY, int worldZ)
	{
		return default;
	}

	public override Color ColorMultiplier(Biome biome, BlockType type)
	{
		return default;
	}

	public override int GetDropItem(int metaData)
	{
		return 0;
	}
}
