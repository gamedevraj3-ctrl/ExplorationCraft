using System;

public class LimitSalesController
{
	public const string START_TIME_TAG = "StartLimitTime";

	public const int TOTAL_LIMIT_SALES_SECONDS = 259200;

	private const int SECONDS_HALF_DAY = 43200;

	public DateTime startTime;

	private int drawingID1;

	private int drawingID2;

	private int bonusCoins;

	public bool NeedShowLimitSales()
	{
		return false;
	}

	public void SetStartTime()
	{
	}

	public int GetLeftTime()
	{
		return 0;
	}

	public void OnPurchaseSuccess()
	{
	}
}
