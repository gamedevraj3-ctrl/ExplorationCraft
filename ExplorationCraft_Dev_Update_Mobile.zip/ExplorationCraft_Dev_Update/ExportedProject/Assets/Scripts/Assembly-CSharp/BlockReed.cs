public class BlockReed : BlockFlower
{
	private float[] reedAABBOffset;

	public BlockReed(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockReed(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	public override float[] GetAABBOffset(int metaData)
	{
		return null;
	}
}
