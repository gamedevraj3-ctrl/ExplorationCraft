using UnityEngine;

public class UIConverterQueueSelectButtonEvent : MonoBehaviour
{
	public NewUIConverter uiConverter;

	private NewUIItemConverterEntry itemEntry;

	private void Start()
	{
	}

	private void ButtonClick(GameObject go)
	{
	}
}
