using System;
using UnityEngine;

public class MathHelper
{
	private const int halfSinDataCount = 61;

	private static float[] halfSinData;

	public const float minFloat = 1E-06f;

	public static LayerMask nothingLayer => default;

	public static LayerMask everythingLayer => default;

	[Obsolete("Use Vector3.SetX() instead")]
	public static Vector3 SetX(Vector3 vec3, float x)
	{
		return default;
	}

	[Obsolete("Use Vector3.SetY() instead")]
	public static Vector3 SetY(Vector3 vec3, float y)
	{
		return default;
	}

	[Obsolete("Use Vector3.SetZ() instead")]
	public static Vector3 SetZ(Vector3 vec3, float z)
	{
		return default;
	}

	[Obsolete("Use Vector3.ToVector2() instead")]
	public static Vector2 Vector3To2(Vector3 vec3)
	{
		return default;
	}

	[Obsolete("Use Vector2.ToVector3() instead")]
	public static Vector3 Vector2To3(Vector2 vec2)
	{
		return default;
	}

	[Obsolete("Use Vector2[].ToVector3() instead")]
	public static Vector3[] Vector2ArrayTo3(Vector2[] vec2s)
	{
		return null;
	}

	public static float GetSqrDistance(Vector3 vec1, Vector3 vec2)
	{
		return 0f;
	}

	public static bool Approximately(Vector3 vec1, Vector3 vec2)
	{
		return false;
	}

	[Obsolete("Use Vector2.Rotate() instead")]
	public static Vector2 RotateDirection(Vector2 direction, float angle)
	{
		return default;
	}

	[Obsolete("Use Vector3.Rotate() instead")]
	public static Vector3 RotateDirection(Vector3 direction, float angle)
	{
		return default;
	}

	public static Vector3 FloorVector3(Vector3 vec)
	{
		return default;
	}

	public static bool IsDirectionAtDirecitonRight(Vector2 me, Vector2 other)
	{
		return false;
	}

	public static bool IsDirectionAtDirecitonRight(Vector3 me, Vector3 other)
	{
		return false;
	}

	[Obsolete("Use Rect.ConvertRelativeToScreen() instead")]
	public static Rect ConvertRectRelativeToScreen(Rect rect)
	{
		return default;
	}

	[Obsolete("Use Rect.ConvertScreenToRelative() instead")]
	public static Rect ConvertRectScreenToRelative(Rect rect)
	{
		return default;
	}

	[Obsolete("Use Rect.Contains() instead")]
	public static bool IsInRect(Rect rect, Vector2 pos)
	{
		return false;
	}

	public static bool IsTransfromAtTransformFront(Transform me, Transform other)
	{
		return false;
	}

	public static void GetRandomNoRepeatNums(int[] result)
	{
	}

	public static int[] GetRandomNoRepeatNums(int n)
	{
		return null;
	}

	public static bool IsProbabilityTrue(float p)
	{
		return false;
	}

	public static float[] LerpProbabilityList(float[] p1, float[] p2, float t)
	{
		return null;
	}

	public static bool IsProbabilityListAvaliable(float[] p)
	{
		return false;
	}

	public static void NormalizeProbability(float[] p)
	{
	}

	public static int GetRandomByProbability(float[] p)
	{
		return 0;
	}

	public static int GetRandomIndexByTrue(bool[] l)
	{
		return 0;
	}

	[Obsolete("Use Color.SetAlpha() instead")]
	public static Color SetAlpha(Color color, float alpha)
	{
		return default;
	}

	public static bool IsPosInRectangle(Vector3 pos, Vector3[] vecs)
	{
		return false;
	}

	public static Vector3 GetHitPos(Vector3 mePos, Vector3 targetPos, float speed_me, Vector3 velocity_target)
	{
		return default;
	}

	public static float GetHalfSinValue(float time)
	{
		return 0f;
	}

	public static float GetFixedAngle(float angle)
	{
		return 0f;
	}

	public static LayerMask GetLayerMaskByLayerCount(int layerCount)
	{
		return default;
	}

	[Obsolete("Use Rect.GetRandomPos() instead")]
	public static Vector2 GetRandomPosInRect(Rect rect)
	{
		return default;
	}

	[Obsolete("Use Camera.CalculateClipPlaneSize() instead")]
	public static void CalculateClipPlaneSize(Camera camera, float zPosInCameraSpace, out float clipPlaneHeight, out float clipPlaneWidth)
	{
		clipPlaneHeight = default;
		clipPlaneWidth = default;
	}

	public static T[] Get2DArrayLine<T>(T[,] twoDArray, int lineNum)
	{
		return null;
	}

	public static Vector2 ScaleRange(Vector2 range, float scale)
	{
		return default;
	}

	public static bool IsFloatZero(float a)
	{
		return false;
	}

	public static bool IsFloatEqual(float a, float b)
	{
		return false;
	}

	public static bool IsVector2Equal(Vector2 v1, Vector2 v2)
	{
		return false;
	}

	public static bool IsVector3Equal(Vector3 v1, Vector3 v2)
	{
		return false;
	}

	public static Rect RectRelative2Real(Rect r)
	{
		return default;
	}

	public static int FastFloor(float x)
	{
		return 0;
	}

	public static void Swap(ref float a, ref float b)
	{
	}

	public static int Floor_double(double par0)
	{
		return 0;
	}

	public static long Floor_double_long(double par0)
	{
		return 0L;
	}

	public static float Sqrt_float(float par0)
	{
		return 0f;
	}

	public static float Sin(float par0)
	{
		return 0f;
	}

	public static float Cos(float par0)
	{
		return 0f;
	}
}
