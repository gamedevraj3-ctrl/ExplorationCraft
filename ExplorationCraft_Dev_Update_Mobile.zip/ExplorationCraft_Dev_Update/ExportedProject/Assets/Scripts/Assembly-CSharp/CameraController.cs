using UnityEngine;

public class CameraController : MonoInstance<CameraController>
{
	public Transform cameraHolder;

	private static Vector2 minSensitivity;

	private static Vector2 maxSensitivity;

	private const float maxDeltaAngle = 10f;

	public float rotateSensitivity_X;

	public float rotateSensitivity_Y;

	public float angleUpClamp;

	public float angleDownClamp;

	public Entity player;

	private static bool useInchSensitivity;

	private static Vector2 minSensitivityInch;

	private static Vector2 maxSensitivityInch;

	private float dpi;

	private float[] sensitivityLevel;

	private void Start()
	{
	}

	public void SetSensitivity(float factor)
	{
	}

	public void UpdateRotate(Vector2 deltaPos)
	{
	}
}
