using BehaviorTree;

public class AnimalBehaviorBase : BevNodeTerminal
{
	protected BevInputData bevInputData;

	public AnimalBehaviorBase(BevNode _o_ParentNode, BevInputData _bevInputData)
		: base(null)
	{
	}

	public AnimalBehaviorBase(BevNode _o_ParentNode, BevInputData _bevInputData, BevNodePrecondition _o_NodePrecondition)
		: base(null)
	{
	}
}
