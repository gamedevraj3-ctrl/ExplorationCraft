public class MissionFileReader
{
	private const string MISSION_FILE_NAME = "Mission";

	public static bool SetMissionAttribute()
	{
		return false;
	}
}
