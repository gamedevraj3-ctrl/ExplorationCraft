using UnityEngine;

public class EntityLivingAnimationController : MonoBehaviour
{
	private static string dieAnimName;

	private static string attackAnimName;

	private static string walkAnimName;

	private static string idleAnimName;

	private static string hitedAnimName;

	private static string flyAnimName;

	private static string glideAnimName;

	private static string eatAnimName;

	private static string additionAttackAnimName;

	public bool hasDeathAnimation;

	private Animation animation;

	private void Awake()
	{
	}

	public void PlayDieAnim()
	{
	}

	public void PlayAnimAttack()
	{
	}

	public void PlayAnimWalk()
	{
	}

	public void PlayAnimIdle()
	{
	}

	public void PlayAnimEat()
	{
	}

	public void PlayAnimRun()
	{
	}

	public void PlayAnimHited()
	{
	}

	public void PlayAnimFly()
	{
	}

	public void PlayAnimGlide()
	{
	}

	public void PlayAnimAdditionAttack()
	{
	}

	public void StopAllAnimation()
	{
	}
}
