using UnityEngine;

public class ChunkGameObject : MonoBehaviour
{
	public Shader[] shaders;

	public GameObject[] ojHolders;

	private MeshFilter[] meshFilters;

	private MeshRenderer[] meshRenders;

	public Vector3 newPos;

	public bool hasConvertToUnityMesh;

	public void Init()
	{
	}

	public void Reset()
	{
	}

	public void CreateFromChunk(Chunk chunk)
	{
	}
}
