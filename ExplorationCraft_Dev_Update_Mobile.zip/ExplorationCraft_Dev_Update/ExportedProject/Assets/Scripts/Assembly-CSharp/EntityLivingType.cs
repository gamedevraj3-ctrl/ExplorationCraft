public enum EntityLivingType
{
	Animal = 0,
	Monster = 1
}
