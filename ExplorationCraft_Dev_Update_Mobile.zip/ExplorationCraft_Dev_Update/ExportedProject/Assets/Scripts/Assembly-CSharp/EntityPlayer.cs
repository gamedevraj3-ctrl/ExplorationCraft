using UnityEngine;

public class EntityPlayer : Entity
{
	public NewUIPlayerStatus uiPlayerStatus;

	public HandHolder handHolder;

	public ArmorManager armorManager;

	public Transform trCamera;

	public SkillManager skillManager;

	public Transform mainTransform;

	public int baseDamage;

	public int maxHealth;

	private int health;

	private float realHealth;

	public HungerController hungerController;

	public int maxDefense;

	private int defense;

	private int oxygen;

	private Regulator oxygenTickTimer;

	private bool isDrowned;

	private const float MAX_ARMOR_VALUE = 25f;

	private const float DRAW_SPEED_REDUCE = 0.1f;

	private const float DAMAGE_COOL_TIME = 1f;

	public int currentBiomeID;

	public bool isDoubleJumped;

	private bool firstFall;

	private float lastDamageTime;

	private float lastEnemyDamageTime;

	[HideInInspector]
	public bool isRiding;

	[HideInInspector]
	public EntityLiving ridingEntity;

	public Animation cameraAnimation;

	public EntityPlayerBuffController buffController;

	private bool isOnPortal;

	private Quaternion deadRotation;

	private bool isInRevive;

	private bool isInvisible;

	private float reviveStartTime;

	private const float INVISIBLE_TIME = 5f;

	public bool forbidPortal;

	private Quaternion[] deadRotationList;

	private static float[] actionExhuastion;

	public bool IsInHurtState => false;

	public bool IsFullHealth => false;

	public bool IsDead => false;

	private float SpeedReduce => 0f;

	public void ResetOnPortalState()
	{
	}

	protected override void AwakeInternal()
	{
	}

	protected override void StartInternal()
	{
	}

	public float GetRealHealth()
	{
		return 0f;
	}

	public void ResetHealth(float health)
	{
	}

	public void ResetAABB()
	{
	}

	public Quaternion GetRotation()
	{
		return default;
	}

	public void SetRotation(Quaternion rotation)
	{
	}

	protected override void UpdateInternal()
	{
	}

	public override void MoveEntity(float x, float y, float z)
	{
	}

	public void StopMove()
	{
	}

	public void Mount(EntityLiving entity, bool checkSpace = true)
	{
	}

	public void Dismount()
	{
	}

	protected override void OnJumpDown()
	{
	}

	public override void OnDamage(DamageType damageType, float amount)
	{
	}

	public void OnRecovery(float amount)
	{
	}

	public void OnRecoveryAll()
	{
	}

	public void OnActionComplete(PlayerAction playerAction, float times = 1f)
	{
	}

	private void OnDie()
	{
	}

	public void OnStartDie()
	{
	}

	public void OnRevive()
	{
	}

	private void ReviveCallBack()
	{
	}

	public void OnRespawn()
	{
	}

	public float GetDamage()
	{
		return 0f;
	}

	public void SetVelocityByInput(Vector3 dir, Transform cameraTransform)
	{
	}

	public float GetJumpSpeed()
	{
		return 0f;
	}

	public Vector3 GetBackPositionForSummoning()
	{
		return default;
	}
}
