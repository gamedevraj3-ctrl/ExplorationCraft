public class EntityHag : EntityLiving
{
	protected override void AddExtraBevTreeNode()
	{
	}
}
