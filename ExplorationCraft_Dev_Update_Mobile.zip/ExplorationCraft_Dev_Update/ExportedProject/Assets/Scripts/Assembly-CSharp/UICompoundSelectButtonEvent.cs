using UnityEngine;

public class UICompoundSelectButtonEvent : MonoBehaviour
{
	public NewUITabCrafting uiTabCrafting;

	private NewUIItemCraftEntry itemEntry;

	private void Start()
	{
	}

	private void ButtonClick(GameObject go)
	{
	}
}
