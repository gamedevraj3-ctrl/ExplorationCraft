using UnityEngine;

public class UIMain : NewUIBase
{
	public UISprite imgAchievementPrompt;

	public UISprite imgDailyBonusPrompt;

	public UISprite imgMoreGamesPrompt;

	public UISprite imgLimitSales;

	public UISprite imgTutotial;

	public GameObject maskCollider;

	[HideInInspector]
	public bool showedDailyBonus;

	[HideInInspector]
	public bool showedLimitSales;

	public GameObject groupedTutorial;

	private void Awake()
	{
	}

	public override void Show()
	{
	}

	private void CheckAchievement()
	{
	}

	private void CheckLimitSales()
	{
	}

	private bool CheckDailyBonus()
	{
		return false;
	}
}
