using UnityEngine;

public class UIPlayingItemButtonEvent : MonoBehaviour
{
	public NewUIPlaying uiPlaying;

	public int index;

	private void Start()
	{
	}

	private void DragOut(GameObject go1, GameObject go2)
	{
	}

	private void ButtonPress(GameObject go, bool isPressed)
	{
	}
}
