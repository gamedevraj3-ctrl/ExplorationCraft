using UnityEngine;

public class BlockMaterialController : MonoInstance<BlockMaterialController>
{
	public static BlockMaterial[] blockMaterials;

	private static bool hasInit;

	public AtlasTexture[] atlasList;

	public Material[] materials;

	public Material[] fallMaterials;

	public int materialCount;

	public BlockTexturePacker texturePacker;

	public static void init()
	{
	}

	private static void SetBlock(BlockType type, int textureIndex, params int[] uvIndexs)
	{
	}

	private new void Awake()
	{
	}
}
