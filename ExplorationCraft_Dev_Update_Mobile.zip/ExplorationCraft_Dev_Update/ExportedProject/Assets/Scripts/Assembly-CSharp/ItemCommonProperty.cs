using System.Collections.Generic;

public class ItemCommonProperty
{
	public class ItemDescription
	{
		public string name;

		public string brief;

		public List<ItemSpecific> specific;

		public ItemDescription(string name, string brief, List<ItemSpecific> specific)
		{
		}
	}

	public ItemType itemType;

	public bool isItemFue;

	public int fuelEnergy;

	public ItemDescription description;

	public int summoningFavorInc;

	public int digestSpeed;

	public ItemCommonProperty(ItemType itemType, bool isItemFue, int fuelEnergy = 0)
	{
	}

	public void SetFeedProperty(int summoningFavorInc, int digestSpeed)
	{
	}

	public virtual ItemCommonProperty SetDescription(ItemDescription description)
	{
		return null;
	}
}
