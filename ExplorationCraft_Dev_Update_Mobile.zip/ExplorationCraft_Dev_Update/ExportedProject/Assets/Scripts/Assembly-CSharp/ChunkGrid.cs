public class ChunkGrid
{
	public int minX;

	public int minZ;

	public int size;

	public Chunk[,] chunks;

	public int maxX;

	public int maxZ;

	public int widthX;

	public int widthZ;

	public ChunkGrid(Vector2i left)
	{
	}
}
