using LibNbt.Tags;
using UnityEngine;

public class IndicatorManager : MonoInstance<IndicatorManager>
{
	public enum Type
	{
		Green = 0,
		Red = 1,
		Yellow = 2,
		Blue = 3
	}

	public Compass compass;

	public Indicator[] indicatorList;

	public void Register(Type type, Vector2 position)
	{
	}

	public void Register(Type type, Vector2 position, Vector2i centerAxis)
	{
	}

	public void ResetPositionByCenterAxis()
	{
	}

	public void ShowIndicator()
	{
	}

	public void HideIndicator()
	{
	}

	public void ShowCompass()
	{
	}

	public void HideCompass()
	{
	}

	public NbtList GetNbtCompound()
	{
		return null;
	}

	public void SetNbtCompound(NbtList nbtIndicatorList)
	{
	}
}
