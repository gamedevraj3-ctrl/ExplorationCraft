public class EntityAlpaca : EntityLiving
{
	protected override void AddExtraBevTreeNode()
	{
	}

	protected override void SpawnFavorParticle()
	{
	}
}
