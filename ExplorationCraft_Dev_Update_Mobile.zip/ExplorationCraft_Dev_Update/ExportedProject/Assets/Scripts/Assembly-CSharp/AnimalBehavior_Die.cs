using BehaviorTree;

public class AnimalBehavior_Die : BevNodeTerminal
{
	private float timeFlag;

	public AnimalBehavior_Die(BevNode _o_ParentNode)
		: base(null)
	{
	}

	protected override void _DoEnter(object input)
	{
	}

	protected override BevRunningStatus _DoExecute(object input, object output)
	{
		return BevRunningStatus.k_BRS_Executing;
	}

	protected override bool _DoEvaluate(object input)
	{
		return false;
	}
}
