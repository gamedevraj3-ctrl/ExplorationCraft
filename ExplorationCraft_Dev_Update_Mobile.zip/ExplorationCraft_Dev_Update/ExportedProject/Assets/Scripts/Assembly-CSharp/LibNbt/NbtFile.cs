using System;
using System.IO;
using LZ4Sharp;
using LibNbt.Tags;

namespace LibNbt
{
	public class NbtFile : IDisposable
	{
		private const int BufferSize = 65536;

		private ILZ4Decompressor decompressor;

		private ILZ4Compressor compressor;

		private byte xxxx;

		protected byte[] FileContents { get; set; }

		protected string LoadedFile { get; set; }

		protected bool CompressedFile { get; set; }

		public NbtCompound RootTag { get; set; }

		public NbtFile()
		{
		}

		public NbtFile(string fileName)
		{
		}

		public NbtFile(string fileName, bool compressed)
		{
		}

		public void Dispose()
		{
		}

		public virtual void LoadFile()
		{
		}

		public virtual void LoadFile(string fileName)
		{
		}

		public virtual void LoadFile(string fileName, bool compressed)
		{
		}

		public virtual void LoadFile(Stream fileStream, bool compressed)
		{
		}

		protected void LoadFileInternal(Stream fileStream)
		{
		}

		public virtual void SaveFile(string fileName)
		{
		}

		public virtual void SaveFile(string fileName, bool compressed)
		{
		}

		public virtual void SaveFile(Stream fileStream)
		{
		}

		public virtual void SaveFile(Stream fileStream, bool compressed)
		{
		}

		public NbtTag Query(string query)
		{
			return null;
		}

		public T Query<T>(string query) where T : NbtTag
		{
			return null;
		}
	}
}
