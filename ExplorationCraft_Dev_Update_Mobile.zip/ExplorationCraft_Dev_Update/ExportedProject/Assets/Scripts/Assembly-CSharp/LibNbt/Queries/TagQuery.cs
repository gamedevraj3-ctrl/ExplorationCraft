using System.Collections.Generic;

namespace LibNbt.Queries
{
	public class TagQuery
	{
		public string Query { get; protected set; }

		protected List<TagQueryToken> Tokens { get; set; }

		protected int CurrentTokenIndex { get; set; }

		public TagQuery()
		{
		}

		public TagQuery(string query)
		{
		}

		public void SetQuery(string query)
		{
		}

		public int Count()
		{
			return 0;
		}

		public int TokensLeft()
		{
			return 0;
		}

		public void MoveFirst()
		{
		}

		public TagQueryToken Previous()
		{
			return null;
		}

		public TagQueryToken Next()
		{
			return null;
		}

		public TagQueryToken Peek()
		{
			return null;
		}
	}
}
