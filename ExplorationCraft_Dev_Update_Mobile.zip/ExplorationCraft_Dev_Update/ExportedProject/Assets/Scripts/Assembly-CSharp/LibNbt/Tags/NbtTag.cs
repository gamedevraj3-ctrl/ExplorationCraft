using System.IO;
using LibNbt.Queries;

namespace LibNbt.Tags
{
	public abstract class NbtTag
	{
		public string Name { get; set; }

		public virtual NbtTag Query(string query)
		{
			return null;
		}

		public virtual T Query<T>(string query) where T : NbtTag
		{
			return null;
		}

		internal virtual T Query<T>(TagQuery query) where T : NbtTag
		{
			return null;
		}

		internal virtual T Query<T>(TagQuery query, bool bypassCheck) where T : NbtTag
		{
			return null;
		}

		internal abstract void ReadTag(Stream readStream);

		internal abstract void ReadTag(Stream readStream, bool readName);

		internal abstract void WriteTag(Stream writeStream);

		internal abstract void WriteTag(Stream writeStream, bool writeName);

		internal abstract void WriteData(Stream writeStream);

		internal virtual NbtTagType GetTagType()
		{
			return NbtTagType.TAG_End;
		}
	}
}
