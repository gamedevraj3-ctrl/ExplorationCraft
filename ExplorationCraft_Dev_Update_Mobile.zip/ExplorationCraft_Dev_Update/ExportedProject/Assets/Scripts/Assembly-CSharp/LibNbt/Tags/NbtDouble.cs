using System;
using System.IO;

namespace LibNbt.Tags
{
	public class NbtDouble : NbtTag, INbtTagValue<double>
	{
		public double Value { get; set; }

		public NbtDouble()
		{
		}

		public NbtDouble(string tagName)
		{
		}

		[Obsolete("This constructor will be removed in favor of using NbtDouble(string tagName, double value)")]
		public NbtDouble(double value)
		{
		}

		public NbtDouble(string tagName, double value)
		{
		}

		internal override void ReadTag(Stream readStream)
		{
		}

		internal override void ReadTag(Stream readStream, bool readName)
		{
		}

		internal override void WriteTag(Stream writeStream)
		{
		}

		internal override void WriteTag(Stream writeStream, bool writeName)
		{
		}

		internal override void WriteData(Stream writeStream)
		{
		}

		internal override NbtTagType GetTagType()
		{
			return NbtTagType.TAG_End;
		}

		public override string ToString()
		{
			return null;
		}
	}
}
