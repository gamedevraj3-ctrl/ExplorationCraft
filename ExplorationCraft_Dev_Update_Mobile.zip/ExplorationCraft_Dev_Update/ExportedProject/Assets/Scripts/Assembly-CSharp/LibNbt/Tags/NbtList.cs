using System.Collections.Generic;
using System.IO;
using LibNbt.Queries;

namespace LibNbt.Tags
{
	public class NbtList : NbtTag, INbtTagList
	{
		public List<NbtTag> Tags { get; protected set; }

		public NbtTagType Type { get; protected set; }

		public NbtTagType ListType { get; protected set; }

		public NbtTag this[int tagIdx]
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		public NbtList()
		{
		}

		public NbtList(string tagName)
		{
		}

		public NbtList(string tagName, IEnumerable<NbtTag> tags, NbtTagType listType)
		{
		}

		public NbtTag Get(int tagIdx)
		{
			return null;
		}

		public T Get<T>(int tagIdx) where T : NbtTag
		{
			return null;
		}

		public override NbtTag Query(string query)
		{
			return null;
		}

		public override T Query<T>(string query)
		{
			return null;
		}

		internal override T Query<T>(TagQuery query, bool bypassCheck)
		{
			return null;
		}

		public void SetListType(NbtTagType listType)
		{
		}

		internal override void ReadTag(Stream readStream)
		{
		}

		internal override void ReadTag(Stream readStream, bool readName)
		{
		}

		internal override void WriteTag(Stream writeStream)
		{
		}

		internal override void WriteTag(Stream writeStream, bool writeName)
		{
		}

		internal override void WriteData(Stream writeStream)
		{
		}

		internal override NbtTagType GetTagType()
		{
			return NbtTagType.TAG_End;
		}

		public override string ToString()
		{
			return null;
		}
	}
}
