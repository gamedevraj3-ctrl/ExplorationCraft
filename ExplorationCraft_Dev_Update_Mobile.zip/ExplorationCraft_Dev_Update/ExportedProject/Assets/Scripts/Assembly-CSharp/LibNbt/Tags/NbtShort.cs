using System;
using System.IO;

namespace LibNbt.Tags
{
	public class NbtShort : NbtTag, INbtTagValue<short>
	{
		public short Value { get; set; }

		public NbtShort()
		{
		}

		public NbtShort(string tagName)
		{
		}

		[Obsolete("This constructor will be removed in favor of using NbtShort(string tagName, short value)")]
		public NbtShort(short value)
		{
		}

		public NbtShort(string tagName, short value)
		{
		}

		internal override void ReadTag(Stream readStream)
		{
		}

		internal override void ReadTag(Stream readStream, bool readName)
		{
		}

		internal override void WriteTag(Stream writeStream)
		{
		}

		internal override void WriteTag(Stream writeStream, bool writeName)
		{
		}

		internal override void WriteData(Stream writeStream)
		{
		}

		internal override NbtTagType GetTagType()
		{
			return NbtTagType.TAG_End;
		}

		public override string ToString()
		{
			return null;
		}
	}
}
