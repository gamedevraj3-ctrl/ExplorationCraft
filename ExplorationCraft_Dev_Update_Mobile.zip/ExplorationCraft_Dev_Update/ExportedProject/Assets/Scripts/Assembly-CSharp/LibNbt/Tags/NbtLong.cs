using System;
using System.IO;

namespace LibNbt.Tags
{
	public class NbtLong : NbtTag, INbtTagValue<long>
	{
		public long Value { get; set; }

		public NbtLong()
		{
		}

		public NbtLong(string tagName)
		{
		}

		[Obsolete("This constructor will be removed in favor of using NbtLong(string tagName, long value)")]
		public NbtLong(long value)
		{
		}

		public NbtLong(string tagName, long value)
		{
		}

		internal override void ReadTag(Stream readStream)
		{
		}

		internal override void ReadTag(Stream readStream, bool readName)
		{
		}

		internal override void WriteTag(Stream writeStream)
		{
		}

		internal override void WriteTag(Stream writeStream, bool writeName)
		{
		}

		internal override void WriteData(Stream writeStream)
		{
		}

		internal override NbtTagType GetTagType()
		{
			return NbtTagType.TAG_End;
		}

		public override string ToString()
		{
			return null;
		}
	}
}
