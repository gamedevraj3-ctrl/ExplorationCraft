namespace LibNbt.Tags
{
	internal interface INbtTagValue<T>
	{
		T Value { get; set; }
	}
}
