using System.IO;

namespace LibNbt.Tags
{
	public class NbtString : NbtTag, INbtTagValue<string>
	{
		public string Value { get; set; }

		public NbtString()
		{
		}

		public NbtString(string tagName)
		{
		}

		public NbtString(string tagName, string value)
		{
		}

		internal override void ReadTag(Stream readStream)
		{
		}

		internal override void ReadTag(Stream readStream, bool readName)
		{
		}

		internal override void WriteTag(Stream writeStream)
		{
		}

		internal override void WriteTag(Stream writeStream, bool writeName)
		{
		}

		internal override void WriteData(Stream writeStream)
		{
		}

		internal override NbtTagType GetTagType()
		{
			return NbtTagType.TAG_End;
		}

		public override string ToString()
		{
			return null;
		}
	}
}
