using System;
using System.IO;

namespace LibNbt.Tags
{
	public class NbtByte : NbtTag, INbtTagValue<byte>
	{
		public byte Value { get; set; }

		public NbtByte()
		{
		}

		public NbtByte(string tagName)
		{
		}

		[Obsolete("This constructor will be removed in favor of using NbtByte(string tagName, byte value)")]
		public NbtByte(byte value)
		{
		}

		public NbtByte(string name, byte value)
		{
		}

		internal override void ReadTag(Stream readStream)
		{
		}

		internal override void ReadTag(Stream readStream, bool readName)
		{
		}

		internal override void WriteTag(Stream writeStream)
		{
		}

		internal override void WriteTag(Stream writeStream, bool writeName)
		{
		}

		internal override void WriteData(Stream writeStream)
		{
		}

		internal override NbtTagType GetTagType()
		{
			return NbtTagType.TAG_End;
		}

		public override string ToString()
		{
			return null;
		}
	}
}
