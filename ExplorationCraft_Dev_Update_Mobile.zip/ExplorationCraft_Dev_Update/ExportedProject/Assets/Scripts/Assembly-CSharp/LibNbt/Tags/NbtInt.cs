using System;
using System.IO;

namespace LibNbt.Tags
{
	public class NbtInt : NbtTag, INbtTagValue<int>
	{
		public int Value { get; set; }

		public NbtInt()
		{
		}

		public NbtInt(string tagName)
		{
		}

		[Obsolete("This constructor will be removed in favor of using NbtInt(string tagName, int value)")]
		public NbtInt(int value)
		{
		}

		public NbtInt(string name, int value)
		{
		}

		internal override void ReadTag(Stream readStream)
		{
		}

		internal override void ReadTag(Stream readStream, bool readName)
		{
		}

		internal override void WriteTag(Stream writeStream)
		{
		}

		internal override void WriteTag(Stream writeStream, bool writeName)
		{
		}

		internal override void WriteData(Stream writeStream)
		{
		}

		internal override NbtTagType GetTagType()
		{
			return NbtTagType.TAG_End;
		}

		public override string ToString()
		{
			return null;
		}
	}
}
