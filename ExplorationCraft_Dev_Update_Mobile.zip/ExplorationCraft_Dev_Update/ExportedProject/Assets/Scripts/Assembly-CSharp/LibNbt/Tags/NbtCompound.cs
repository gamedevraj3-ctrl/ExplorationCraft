using System.Collections.Generic;
using System.IO;
using LibNbt.Queries;

namespace LibNbt.Tags
{
	public class NbtCompound : NbtTag, INbtTagList
	{
		public List<NbtTag> Tags { get; protected set; }

		public NbtTag this[int tagIdx]
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		public NbtTag this[string tagName]
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		protected Dictionary<string, NbtTag> TagCache { get; set; }

		public NbtCompound()
		{
		}

		public NbtCompound(string tagName)
		{
		}

		public NbtCompound(string tagName, IEnumerable<NbtTag> tags)
		{
		}

		public T Get<T>(int tagIdx) where T : NbtTag
		{
			return null;
		}

		public void Set(int tagIdx, NbtTag tag)
		{
		}

		public override NbtTag Query(string query)
		{
			return null;
		}

		public override T Query<T>(string query)
		{
			return null;
		}

		internal override T Query<T>(TagQuery query, bool bypassCheck)
		{
			return null;
		}

		public NbtTag Get(string tagName)
		{
			return null;
		}

		public T Get<T>(string tagName) where T : NbtTag
		{
			return null;
		}

		public void Set(string tagName, NbtTag tag)
		{
		}

		internal override void ReadTag(Stream readStream)
		{
		}

		internal override void ReadTag(Stream readStream, bool readName)
		{
		}

		internal override void WriteTag(Stream writeStream)
		{
		}

		internal override void WriteTag(Stream writeStream, bool writeName)
		{
		}

		internal override void WriteData(Stream writeStream)
		{
		}

		internal override NbtTagType GetTagType()
		{
			return NbtTagType.TAG_End;
		}

		public override string ToString()
		{
			return null;
		}
	}
}
