using System;
using System.IO;

namespace LibNbt.Tags
{
	public class NbtByteArray : NbtTag, INbtTagValue<byte[]>
	{
		public byte[] Value { get; set; }

		public byte this[int index]
		{
			get
			{
				return 0;
			}
			set
			{
			}
		}

		public NbtByteArray()
		{
		}

		public NbtByteArray(string tagName)
		{
		}

		[Obsolete("This constructor will be removed in favor of using NbtByteArray(string tagName, byte[] value)")]
		public NbtByteArray(byte[] value)
		{
		}

		public NbtByteArray(string tagName, byte[] value)
		{
		}

		internal override void ReadTag(Stream readStream)
		{
		}

		internal override void ReadTag(Stream readStream, bool readName)
		{
		}

		internal override void WriteTag(Stream writeStream)
		{
		}

		internal override void WriteTag(Stream writeStream, bool writeName)
		{
		}

		internal override void WriteData(Stream writeStream)
		{
		}

		internal override NbtTagType GetTagType()
		{
			return NbtTagType.TAG_End;
		}

		public override string ToString()
		{
			return null;
		}
	}
}
