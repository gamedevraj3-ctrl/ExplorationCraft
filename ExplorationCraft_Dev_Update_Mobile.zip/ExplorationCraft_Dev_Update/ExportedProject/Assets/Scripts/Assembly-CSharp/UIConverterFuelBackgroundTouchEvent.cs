using UnityEngine;

public class UIConverterFuelBackgroundTouchEvent : MonoBehaviour
{
	public NewUIConverter uiConverter;

	private void Start()
	{
	}

	private void ScreenClick(GameObject go)
	{
	}
}
