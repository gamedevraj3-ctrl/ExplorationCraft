public class BlockFileReader
{
	private const string BLOCK_FILE_NAME = "Block";

	public static bool SetBlockAttribute()
	{
		return false;
	}
}
