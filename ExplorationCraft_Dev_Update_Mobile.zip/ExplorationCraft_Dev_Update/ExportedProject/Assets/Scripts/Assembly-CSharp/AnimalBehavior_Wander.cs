using BehaviorTree;
using UnityEngine;

public class AnimalBehavior_Wander : BevNodeTerminal
{
	protected Vector2 wanderTimeRange;

	protected float wanderTime;

	protected float timeFlag;

	protected Vector3 direction;

	public AnimalBehavior_Wander(BevNode _o_ParentNode, Vector2 _wanderTimeRange)
		: base(null)
	{
	}

	protected override void _DoEnter(object input)
	{
	}

	protected override BevRunningStatus _DoExecute(object input, object output)
	{
		return BevRunningStatus.k_BRS_Executing;
	}

	protected override bool _DoEvaluate(object input)
	{
		return false;
	}
}
