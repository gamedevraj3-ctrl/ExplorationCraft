public class ItemPackageEntry
{
	public int id;

	public int count;

	public int durability;

	public int maxDurability;

	public static readonly ItemPackageEntry emptyPackageEntry;

	public ItemPackageEntry()
	{
	}

	public ItemPackageEntry(int id, int count)
	{
	}

	public ItemPackageEntry(int id, int count, int durability)
	{
	}

	public void ReduceDurability()
	{
	}

	public void Clone(ItemPackageEntry other)
	{
	}
}
