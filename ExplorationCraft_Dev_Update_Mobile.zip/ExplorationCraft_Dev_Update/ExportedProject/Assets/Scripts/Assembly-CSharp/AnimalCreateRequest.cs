using UnityEngine;

public class AnimalCreateRequest
{
	public AnimalType animalType;

	public Vector3 position;

	public Quaternion rotation;

	public float health;

	public bool setTamingFlag;

	public float favorability;

	public int probability;

	public BuffType buffType;

	public int buffLevel;

	public float buffPassedTime;

	public int lastTimeTick;

	public bool checkAxis;

	public Vector3i centerAxis;

	public AnimalCreateRequest(AnimalType type, Vector3 pos, Quaternion rotation, float health, int timeTick)
	{
	}

	public AnimalCreateRequest(AnimalType type, Vector3 pos, Quaternion rotation, float health, int timeTick, BuffType buffType, int buffLevel, float buffPassedTime)
	{
	}

	public AnimalCreateRequest(AnimalType type, Vector3 pos, Quaternion rotation, float health, int timeTick, BuffType buffType, int buffLevel, float buffPassedTime, Vector3i centerAxis)
	{
	}

	public AnimalCreateRequest(AnimalType type, Vector3 pos, Quaternion rotation, float health, int timeTick, float favorability, int probability)
	{
	}

	public AnimalCreateRequest(AnimalType type, Vector3 pos, Quaternion rotation, float health, int timeTick, float favorability, int probability, BuffType buffType, int buffLevel, float buffPassedTime)
	{
	}

	public AnimalCreateRequest(AnimalType type, Vector3 pos, Quaternion rotation, float health, int timeTick, float favorability, int probability, BuffType buffType, int buffLevel, float buffPassedTime, Vector3i centerAxis)
	{
	}
}
