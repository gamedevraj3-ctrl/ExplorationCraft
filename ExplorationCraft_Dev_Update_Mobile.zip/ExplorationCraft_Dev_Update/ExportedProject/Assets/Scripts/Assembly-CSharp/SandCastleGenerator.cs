using System;

public class SandCastleGenerator : DecorationGenerator
{
	private int height;

	private int size;

	private int probabilityPermillage;

	public SandCastleGenerator(int height, int size, int probability)
	{
	}

	public override void Decorate(Chunk chunk, Random rand)
	{
	}
}
