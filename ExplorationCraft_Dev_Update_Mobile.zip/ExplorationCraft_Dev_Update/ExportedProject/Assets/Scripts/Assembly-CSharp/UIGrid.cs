using UnityEngine;

[AddComponentMenu("NGUI/Interaction/Grid")]
public class UIGrid : UIWidgetContainer
{
	public delegate void OnReposition();

	public enum Arrangement
	{
		Horizontal = 0,
		Vertical = 1
	}

	public Arrangement arrangement;

	public int maxPerLine;

	public float cellWidth;

	public float cellHeight;

	public bool animateSmoothly;

	public bool sorted;

	public bool hideInactive;

	public OnReposition onReposition;

	private bool mStarted;

	private bool mReposition;

	private UIPanel mPanel;

	private UIScrollView mDrag;

	private bool mInitDone;

	public bool repositionNow
	{
		set
		{
		}
	}

	private void Init()
	{
	}

	private void Start()
	{
	}

	private void Update()
	{
	}

	public static int SortByName(Transform a, Transform b)
	{
		return 0;
	}

	[ContextMenu("Execute")]
	public void Reposition()
	{
	}
}
