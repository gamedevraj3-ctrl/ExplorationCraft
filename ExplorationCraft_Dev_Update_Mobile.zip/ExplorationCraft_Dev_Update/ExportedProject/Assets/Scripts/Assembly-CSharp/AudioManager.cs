using UnityEngine;

public class AudioManager : MonoInstance<AudioManager>
{
	private enum AudioPoolType
	{
		Animal = 0,
		Other = 1
	}

	public AudioSource[] animalAudioSourcePool;

	public AudioSource[] otherAudioSourcePool;

	public AudioSource playerAudioSource;

	public AudioSource buttonAudioSource;

	public AudioSource digAudioSource;

	public AudioSource attackAudioSource;

	public AudioSource backgroundMusic;

	public AudioSource swimAudioSource;

	public AudioClip bowShootAudio;

	public AudioClip arrowHitAudio;

	public AudioClip digDirtAudio;

	public AudioClip digDirtFinishAudio;

	public AudioClip digMineAudio;

	public AudioClip digMineFinishAudio;

	public AudioClip digWoodAudio;

	public AudioClip digWoodFinishAudio;

	public AudioClip digGrassAudio;

	public AudioClip digGrassFinishAudio;

	public AudioClip foodAudio;

	public AudioClip toolBrokenAudio;

	public AudioClip playerHitAudio;

	public AudioClip playerJumpDownAudio;

	public AudioClip playerDeathAudio;

	public AudioClip fireShoot;

	public AudioClip fireHit;

	public AudioClip fireHeal;

	public AudioClip iceShoot;

	public AudioClip iceHit;

	public AudioClip iceArmor;

	public AudioClip arcaneShoot;

	public AudioClip arcaneHit;

	public AudioClip arcaneUltra;

	public AudioClip button;

	public AudioClip error;

	public AudioClip blockInterface;

	public AudioClip chestOpen;

	public AudioClip chestClose;

	public AudioClip doorSound;

	public AudioClip waterSound;

	public AudioClip pickUpAudioClip;

	private void Start()
	{
	}

	public void SetMusicEnable(bool enable)
	{
	}

	public void SetSoundEnable(bool enable)
	{
	}

	public void PlayAnimalAudio(AudioClip audioClip)
	{
	}

	public void PlayPickUpAudio()
	{
	}

	public void PlayEatAudio()
	{
	}

	public void StopEatAudio()
	{
	}

	public void PlayArrowShootAudio()
	{
	}

	public void PlayArrowHitAudio()
	{
	}

	public void PlayDigAudio(DiggingType digType)
	{
	}

	public void StopDigAudio()
	{
	}

	public void PlayDigFinishAudio(DiggingType digType)
	{
	}

	public void PlayPlayerHitAudio()
	{
	}

	public void PlayJumpDownAudio()
	{
	}

	public void PlayPlayerDeathAudio()
	{
	}

	private AudioSource GetFreeAudioSource(AudioPoolType poolType)
	{
		return null;
	}

	public void PlayMagicAudio(ProjectileType type)
	{
	}

	public void PlayMagicAudio(GainType type)
	{
	}

	public void PlayMagicHit(ProjectileType type)
	{
	}

	public void PlayDungeonMusic()
	{
	}

	public void PlaySwimSound()
	{
	}

	public void StopSwimSound()
	{
	}

	public void StopDungeonMusic()
	{
	}

	public void PlayButtonSound()
	{
	}

	public void PlayButtonError()
	{
	}

	public void PlayBlockInterface()
	{
	}

	public void PlayBlockWater()
	{
	}

	public void PlayChestOpen()
	{
	}

	public void PlayChestClose()
	{
	}

	public void PlayDoor()
	{
	}

	public void PlayAttack(AudioClip audioClip)
	{
	}
}
