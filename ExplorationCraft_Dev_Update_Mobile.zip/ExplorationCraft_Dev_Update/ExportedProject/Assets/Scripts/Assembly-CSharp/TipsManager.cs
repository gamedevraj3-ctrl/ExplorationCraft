using System;

public class TipsManager
{
	private string[] tipsList;

	private int tipsIndex;

	private Random rand;

	public string Next => null;

	public string Current => null;

	public TipsManager(string[] tips)
	{
	}
}
