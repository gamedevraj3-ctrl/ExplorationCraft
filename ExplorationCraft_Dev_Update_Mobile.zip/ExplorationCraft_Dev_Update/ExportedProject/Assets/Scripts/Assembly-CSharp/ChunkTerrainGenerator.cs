using System;

public class ChunkTerrainGenerator
{
	private Random rand;

	private byte[] blockIDList;

	private float[] surfaceHeight;

	private float[] topHeight;

	private int[] biomeList;

	private float[] baseNoiseArray;

	private float[] riverNoiseArray;

	private float[] temperatureNoiseArray;

	private float[] humidityNoiseArray;

	private float[] heightNoiseArray;

	private float[] caveNoiseArray;

	private NoiseGenerator temperatureNoise;

	private NoiseGenerator humidityNoise;

	private NoiseGenerator baseNoise;

	private NoiseGenerator platBaseNoise;

	private NoiseGenerator riverNoise;

	private NoiseGenerator heightNoise;

	private NoiseGenerator caveNoise;

	private ErosionNoise erosionNoise;

	private int seaLevel;

	private int baseLevel;

	private const int SAMPLE_RATE = 8;

	public ChunkTerrainGenerator(int seed)
	{
	}

	public byte[] Generate(Chunk chunk)
	{
		return null;
	}

	private void GenerateBiome(int chunkX, int chunkZ)
	{
	}

	public void Populate(Chunk chunk)
	{
	}

	private void GenerateTutorialTerrain(int chunkX, int chunkZ, byte[] blockIdList)
	{
	}

	public void PopulateTutorial(Chunk chunk, Random rand)
	{
	}

	public void GenerateBossTerrain(Chunk chunk, byte[] blockIdList)
	{
	}
}
