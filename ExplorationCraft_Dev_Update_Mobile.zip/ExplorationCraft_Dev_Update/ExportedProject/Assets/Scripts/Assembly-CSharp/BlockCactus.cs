public class BlockCactus : Block
{
	public BlockCactus(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockCactus(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	public override DiggingConvertType ConvertAfterDiggingAround(BlockFromDirection direction, int metaData)
	{
		return DiggingConvertType.None;
	}

	public override bool CanPlaceBlockAt(Block attachBlock, BlockFromDirection direction)
	{
		return false;
	}
}
