public class BiomePlain : Biome
{
	public BiomePlain(int id)
		: base(0)
	{
	}

	public override byte GetSurfaceBlock(int depth, float density, int randomDepth)
	{
		return 0;
	}
}
