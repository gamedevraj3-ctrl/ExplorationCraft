using BehaviorTree;
using UnityEngine;

public class AnimalBehavior_WanderInAir : BevNodeTerminal
{
	private Vector2 wanderTimeRange;

	private float wanderTime;

	private float timeFlag;

	private float velocityY;

	private Vector3 direction;

	private Vector2 heightRange;

	public AnimalBehavior_WanderInAir(BevNode _o_ParentNode, BevNodePrecondition _o_NodePrecondition, Vector2 _wanderTimeRange, Vector2 _heightRange)
		: base(null)
	{
	}

	protected override void _DoEnter(object input)
	{
	}

	protected override BevRunningStatus _DoExecute(object input, object output)
	{
		return BevRunningStatus.k_BRS_Executing;
	}

	protected override bool _DoEvaluate(object input)
	{
		return false;
	}
}
