using UnityEngine;

public class HungerController : MonoBehaviour
{
	public NewUIPlayerStatus uiPlayerStatus;

	public EntityPlayer player;

	public int maxFoodLevel;

	private int foodLevel;

	private float foodSaturationLevel;

	private Regulator foodTickTimer;

	private float foodExhuastionLevel;

	private const int RECOVERY_FOOD_LEVEL = 18;

	private const float MAX_FOOD_EXHUASTION = 40f;

	private const float INITIAL_FOOD_SATURATION = 5f;

	public int GetFoodLevel()
	{
		return 0;
	}

	public float GetFoodSaturationLevel()
	{
		return 0f;
	}

	public float GetFoodExhuastionLevel()
	{
		return 0f;
	}

	private void Awake()
	{
	}

	public void Reset(int foodLevel, float foodSaturationLevel, float foodExhuastionLevel)
	{
	}

	public void Init()
	{
	}

	private void Update()
	{
	}

	public void AddFoodExhuastion(float exhuastionAmount)
	{
	}

	public void OnRecovery(int foodLevelAmount, float foodSaturationAmount)
	{
	}

	public void OnRecoveryAll()
	{
	}
}
