using System.Text;
using UnityEngine;

public class UILimitSales : NewUIBase
{
	public UILabel leftTime;

	public UILabel txtCoin;

	public UILabel txtGem;

	public GameObject objMoney;

	public GameObject objBtBuy;

	public TweenScale scaleTweener;

	private int lastLeftSeconds;

	private StringBuilder sbLeftTime;

	private void Awake()
	{
	}

	public override void Show()
	{
	}

	public override void Hide()
	{
	}

	private void Update()
	{
	}

	private void SetLeftTime()
	{
	}

	private void RefreshMoney()
	{
	}

	public void OnBuy()
	{
	}

	public void ShowInAppPurchaseCoin()
	{
	}

	public void ShowInAppPurchaseGem()
	{
	}

	public void ForbidButtonBuy()
	{
	}
}
