public enum BuffType
{
	None = 0,
	Burning = 1,
	Frozen = 2,
	Sleep = 3
}
