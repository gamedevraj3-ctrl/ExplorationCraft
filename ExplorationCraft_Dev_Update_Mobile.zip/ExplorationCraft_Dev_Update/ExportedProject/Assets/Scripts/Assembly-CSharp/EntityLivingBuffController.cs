using UnityEngine;

public class EntityLivingBuffController
{
	public Color normalColor;

	public Color frozenColor;

	private bool isInHurt;

	private float lastHurtTime;

	private BuffType buffType;

	private Color buffColor;

	private int buffLevel;

	private float lastBuffChangeTime;

	private EntityLiving entity;

	private Material entityMaterial;

	private Material entityExtraMaterial;

	private Regulator burningRegulator;

	private GameObject burningFire;

	private const float HURT_DURATION = 0.5f;

	private const float BURNING_DURATION = 8f;

	private const float FROZEN_DURATION = 8f;

	public float SpeedReduce => 0f;

	public int BuffLevel => 0;

	public float PassedTime => 0f;

	public EntityLivingBuffController(EntityLiving entity)
	{
	}

	public void Reset()
	{
	}

	public void Reset(BuffType type, int level, float passedTime)
	{
	}

	public void ResetAllEffect()
	{
	}

	public void Update()
	{
	}

	public void PlayAnimHurt()
	{
	}

	public void SetBuff(BuffType buffType, int buffLevel)
	{
	}

	public BuffType GetBuff()
	{
		return BuffType.None;
	}
}
