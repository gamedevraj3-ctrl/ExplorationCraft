using System;
using UnityEngine;

public abstract class UIRect : MonoBehaviour
{
	[Serializable]
	public class AnchorPoint
	{
		public Transform target;

		public float relative;

		public int absolute;

		[NonSerialized]
		public UIRect rect;

		[NonSerialized]
		public Camera targetCam;

		public AnchorPoint()
		{
		}

		public AnchorPoint(float relative)
		{
		}

		public void Set(float relative, float absolute)
		{
		}

		public void SetToNearest(float abs0, float abs1, float abs2)
		{
		}

		public void SetToNearest(float rel0, float rel1, float rel2, float abs0, float abs1, float abs2)
		{
		}

		public void SetHorizontal(Transform parent, float localPos)
		{
		}

		public void SetVertical(Transform parent, float localPos)
		{
		}

		public Vector3[] GetSides(Transform relativeTo)
		{
			return null;
		}

		public void Resize(float factor)
		{
		}
	}

	public AnchorPoint leftAnchor;

	public AnchorPoint rightAnchor;

	public AnchorPoint bottomAnchor;

	public AnchorPoint topAnchor;

	protected GameObject mGo;

	protected Transform mTrans;

	protected BetterList<UIRect> mChildren;

	protected bool mChanged;

	protected bool mStarted;

	[NonSerialized]
	public float finalAlpha;

	private UIRoot mRoot;

	private UIRect mParent;

	private Camera mMyCam;

	private int mUpdateFrame;

	private bool mAnchorsCached;

	private bool mParentFound;

	private bool mRootSet;

	private int mLastInvalidate;

	private static Vector3[] mSides;

	public GameObject cachedGameObject => null;

	public Transform cachedTransform => null;

	public Camera anchorCamera => null;

	public bool isFullyAnchored => false;

	public bool isAnchoredHorizontally => false;

	public bool isAnchoredVertically => false;

	public UIRect parent => null;

	public UIRoot root => null;

	public bool isAnchored => false;

	public abstract float alpha { get; set; }

	public abstract Vector3[] localCorners { get; }

	public abstract Vector3[] worldCorners { get; }

	public abstract float CalculateFinalAlpha(int frameID);

	public void Invalidate(bool includeChildren)
	{
	}

	public virtual Vector3[] GetSides(Transform relativeTo)
	{
		return null;
	}

	protected Vector3 GetLocalPos(AnchorPoint ac, Transform trans)
	{
		return default;
	}

	protected void OnEnable()
	{
	}

	protected virtual void OnInit()
	{
	}

	protected virtual void OnDisable()
	{
	}

	protected void Start()
	{
	}

	public void Update()
	{
	}

	public void UpdateAnchors()
	{
	}

	protected abstract void OnAnchor();

	public void SetAnchor(Transform t)
	{
	}

	public void ResetAnchors()
	{
	}

	private void FindCameraFor(AnchorPoint ap)
	{
	}

	public virtual void ParentHasChanged()
	{
	}

	protected abstract void OnStart();

	protected virtual void OnUpdate()
	{
	}
}
