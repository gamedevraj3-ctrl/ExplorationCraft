using UnityEngine;

public class NewUIPlayerStatus : MonoBehaviour
{
	public NewUIPlayerStatus extraPlayerStatus;

	public UISprite healthLevel;

	public UISprite defenseLevel;

	public UISprite foodLevel;

	public UISprite magicValue;

	public UISprite expLevel;

	public UISprite oxygenBack;

	public UISprite oxygenLevel;

	public UILabel expValue;

	private float MAX_FOOD_LEVEL;

	private float MAX_HEALTH_LEVEL;

	private float MAX_DEFENSE_LEVEL;

	private float MAX_MAGIC_LEVEL;

	public void SetHealthLevel(int health)
	{
	}

	public void SetFoodLevel(int food)
	{
	}

	public void SetDefenseLevel(int defense)
	{
	}

	public void SetMagic(float magic)
	{
	}

	public void SetOxygen(int oxygen)
	{
	}

	public void SetExp(int level, float experienceFillAmount)
	{
	}
}
