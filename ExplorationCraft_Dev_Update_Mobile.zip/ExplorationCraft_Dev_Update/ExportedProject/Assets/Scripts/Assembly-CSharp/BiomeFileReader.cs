using System.Collections.Generic;

public class BiomeFileReader
{
	private const string BIOME_BASIC_FILE_NAME = "Biome_Basic";

	private const string BIOME_ANIMAL_GROUP_FILE_NAME = "Biome_AnimalGroup";

	private const string BIOME_ORE_DISTRIBUTION_FILE_NAME = "Biome_OreDistribution";

	public static bool SetBiomeAttribute()
	{
		return false;
	}

	private static List<OreGenerator> ReadOreDistribution(string[] biomeOreDistributionLines)
	{
		return null;
	}

	private static List<EntityGroupEntry> ReadAnimalGroup(string[] biomeAnimalGroupLines)
	{
		return null;
	}

	private static bool SetBiome(string[] biomeBasicLines, string[] biomeAnimalGroupLines, string[] biomeOreDistributionLines)
	{
		return false;
	}
}
