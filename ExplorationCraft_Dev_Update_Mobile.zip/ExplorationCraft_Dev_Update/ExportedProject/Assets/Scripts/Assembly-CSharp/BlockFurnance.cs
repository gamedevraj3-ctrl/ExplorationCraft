public class BlockFurnance : Block
{
	private bool isOven;

	public BlockFurnance(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockFurnance(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	public BlockFurnance(BlockType type, DiggingType material, bool isOven)
		: base(BlockType.Air)
	{
	}

	public override bool OnHit(AABB hitAABB)
	{
		return false;
	}

	public override void OnBlockAdd(World world, int worldX, int worldY, int worldZ)
	{
	}

	public override void OnBlockDestroy(World world, int worldX, int worldY, int worldZ)
	{
	}

	public override bool NeedUpdate()
	{
		return false;
	}

	public override void UpdateTick(World world, Chunk chunk, int x, int y, int z)
	{
	}

	public override void UpdateTick(World world, Chunk chunk, int x, int y, int z, int passedTicks)
	{
	}
}
