using System;

public class SugarbeetGenerator : DecorationGenerator
{
	private int size;

	private int countPerChunk;

	private int probabilityPercentage;

	public SugarbeetGenerator(int size, int count, int probabilityPercentage)
	{
	}

	public override void Decorate(Chunk chunk, Random rand)
	{
	}
}
