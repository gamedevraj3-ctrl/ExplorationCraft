using UnityEngine;

public class LoadingSceneController : MonoBehaviour
{
	public UIRoot uiRoot;

	private void Awake()
	{
	}

	private void Start()
	{
	}
}
