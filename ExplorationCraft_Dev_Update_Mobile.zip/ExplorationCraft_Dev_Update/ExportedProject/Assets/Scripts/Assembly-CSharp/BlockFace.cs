public enum BlockFace : byte
{
	Top = 0,
	Side = 1,
	Bottom = 2,
	Front = 3,
	Back = 4,
	Extra = 5
}
