public class BlockWaterStill : Block
{
	protected enum OccupyType
	{
		None = 0,
		Forbid = 1,
		Override = 2,
		Stone = 3
	}

	public int maxDecay;

	public BlockWaterStill(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockWaterStill(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	public override bool OnHit(AABB hitAABB)
	{
		return false;
	}

	public override void OnBlockAdd(World world, int worldX, int worldY, int worldZ)
	{
	}

	protected OccupyType IsBlockWaterCanOccupy(Map map, Vector3i pos, int metaData)
	{
		return OccupyType.None;
	}

	public override bool NeedUpdate()
	{
		return false;
	}

	public override void UpdateTick(World world, Chunk chunk, int x, int y, int z)
	{
	}

	public override void GenBlockMesh(MeshGenerator meshGenerator, Map map, int blockX, int blockY, int blockZ, Chunk chunk, int x, int y, int z, byte blockLight)
	{
	}

	public override int GetDropItem(int metaData)
	{
		return 0;
	}
}
