using UnityEngine;

public class UIPlayingJumpButtonEvent : MonoBehaviour
{
	public InputHandler inputHandler;

	private void Start()
	{
	}

	private void DragOver(GameObject go1, GameObject go2)
	{
	}

	private void DragOut(GameObject go1, GameObject go2)
	{
	}

	private void DragEnd(GameObject go)
	{
	}

	private void ButtonPress(GameObject go, bool isPressed)
	{
	}

	private void ButtonClick(GameObject go)
	{
	}
}
