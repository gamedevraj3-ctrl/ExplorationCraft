public class Mission
{
	protected string description;

	protected int param;

	public IMissionPrecondition precondition;

	protected bool completed;

	protected bool actived;

	protected bool finished;

	protected int bonusExperience;

	protected int bonusType;

	protected int bonusAmount;

	public bool IsCompleted
	{
		get
		{
			return false;
		}
		set
		{
		}
	}

	public bool IsActived => false;

	public bool IsFinished
	{
		get
		{
			return false;
		}
		set
		{
		}
	}

	public int BonusExperience => 0;

	public int BonusType => 0;

	public int BonusAmount => 0;

	public Mission(string description, int param, IMissionPrecondition precondition, int experience, int bonusType, int bonusAmount)
	{
	}

	public virtual void SetActive()
	{
	}

	public virtual void SetInactive()
	{
	}

	public virtual bool CheckComplete()
	{
		return false;
	}

	public virtual void OnComplete()
	{
	}

	public virtual void OnFinish()
	{
	}

	public virtual string GetDescription()
	{
		return null;
	}

	public virtual string GetProgress()
	{
		return null;
	}

	public virtual int GetProgressStatus()
	{
		return 0;
	}

	public virtual void SetProgress(int progress)
	{
	}
}
