using BehaviorTree;
using UnityEngine;

public class AnimalBehavior_Fly : BevNodeTerminal
{
	private FlyType flyType;

	private Vector2 flyTimeRange;

	private float flyTime;

	private float timeFlag;

	private Vector3 direction;

	private float velocityY;

	private Vector2 heightRange;

	private const int MAX_XZ_DISTANCE = 40;

	public AnimalBehavior_Fly(BevNode _o_ParentNode, FlyType _flyType, Vector2 _flyTimeRange, Vector2 _heightRange)
		: base(null)
	{
	}

	protected override void _DoEnter(object input)
	{
	}

	protected override BevRunningStatus _DoExecute(object input, object output)
	{
		return BevRunningStatus.k_BRS_Executing;
	}

	protected override bool _DoEvaluate(object input)
	{
		return false;
	}
}
