using System.Collections.Generic;
using UnityEngine;

public class FallObjectController : MonoInstance<FallObjectController>
{
	public GameObject prefabFallObjectBlock;

	public GameObject prefabFallObjectPlane;

	public List<EntityFallObject> usingFallObjectBlocks;

	public List<EntityFallObject> storedFallObjectBlocks;

	public List<EntityFallObject> usingFallObjectPlanes;

	public List<EntityFallObject> storedFallObjectPlanes;

	public Transform playerHandTr;

	private Queue<FallObjectCreateRequest> createRequest;

	private Queue<EntityFallObject> recycleRequest;

	private new void Awake()
	{
	}

	private void Update()
	{
	}

	private void GenBlockMesh(EntityFallObject blockFallObject, int id)
	{
	}

	private EntityFallObject CreateFallObjectBlock(int id)
	{
		return null;
	}

	private EntityFallObject CreateFallObjectPlane(int id)
	{
		return null;
	}

	private EntityFallObject PrepareObject(int id, int amount, int durability)
	{
		return null;
	}

	public EntityFallObject CreateFallObject(AABB aabbFrom, int id)
	{
		return null;
	}

	public EntityFallObject CreateFallObject(AABB aabbFrom, int id, int amount)
	{
		return null;
	}

	public EntityFallObject CreateFallObject(AABB aabbFrom, int id, int amount, int durability)
	{
		return null;
	}

	public EntityFallObject CreateFallObject(Vector3 pos, int id, int amount, int durability, bool needThrow)
	{
		return null;
	}

	public EntityFallObject CreateFallObject(Vector3 pos, int id, int amount, int durability, bool needThrow, bool checkAxis, Vector3i centerAxis)
	{
		return null;
	}

	public EntityFallObject DropoutItem(Vector3 pos, int id, int amount, int durability)
	{
		return null;
	}

	public void RethrowFallObject(EntityFallObject entity)
	{
	}

	public void Recycle(EntityFallObject fallObject)
	{
	}

	private void RandomFallObjectPosAndThrow(AABB aabbFrom, EntityFallObject fallObject)
	{
	}

	private void ThrowFallObjectPos(Vector3 pos, EntityFallObject fallObject, bool randomDirection = false)
	{
	}

	public void AddCreateRequest(FallObjectCreateRequest request)
	{
	}

	public void AddRecycleRequest(EntityFallObject entity)
	{
	}

	public void RecycleAllUnused()
	{
	}

	public Vector3 GetTargetPosition(int itemID)
	{
		return default;
	}
}
