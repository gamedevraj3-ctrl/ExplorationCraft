using BehaviorTree;

public class AnimalBehavior_PreconditionHealthLowerThan : BevNodePrecondition
{
	private float targetHealth;

	public AnimalBehavior_PreconditionHealthLowerThan(float minHealth)
	{
	}

	public bool ExternalCondition(object input)
	{
		return false;
	}
}
