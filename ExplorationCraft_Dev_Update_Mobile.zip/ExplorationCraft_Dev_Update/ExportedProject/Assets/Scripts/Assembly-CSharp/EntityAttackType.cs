public enum EntityAttackType
{
	None = 0,
	Normal = 1,
	Projectile = 2,
	Rage = 3
}
