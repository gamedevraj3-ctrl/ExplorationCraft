using System;
using UnityEngine;

[Serializable]
public class AABB
{
	public static readonly AABBPool aabbPool;

	public float MinX;

	public float MinY;

	public float MinZ;

	public float MaxX;

	public float MaxY;

	public float MaxZ;

	public Vector3 center => default;

	public Vector3 size => default;

	public void SetAABB(float minX, float minY, float minZ, float maxX, float maxY, float maxZ)
	{
	}

	private AABB(float minX, float minY, float minZ, float maxX, float maxY, float maxZ)
	{
	}

	public static AABB NewAABB(float minX, float minY, float minZ, float maxX, float maxY, float maxZ)
	{
		return null;
	}

	public static AABB getAABBFromPool(float minX, float minY, float minZ, float maxX, float maxY, float maxZ)
	{
		return null;
	}

	public static AABB getAABBFromPool(Vector3 minPoint, Vector3 maxPoint)
	{
		return null;
	}

	public AABB copy()
	{
		return null;
	}

	public AABB setBounds(float minX, float minY, float minZ, float maxX, float maxY, float maxZ)
	{
		return null;
	}

	public void setBounds(AABB boundingBox)
	{
	}

	public Vector3 getPos()
	{
		return default;
	}

	public AABB TranslateEntityBB(float x, float y, float z)
	{
		return null;
	}

	public AABB TranslateEntityBB(Vector3 translatePos)
	{
		return null;
	}

	public AABB AddCoord(float x, float y, float z)
	{
		return null;
	}

	public AABB Expand(float x, float y, float z)
	{
		return null;
	}

	public bool intersectWith(AABB aabb)
	{
		return false;
	}

	public float GetAverageEdgeLength()
	{
		return 0f;
	}

	public AABB Offset(float x, float y, float z)
	{
		return null;
	}

	public AABB Offset(Vector3 offset)
	{
		return null;
	}

	public AABB Contract(float x, float y, float z)
	{
		return null;
	}

	public bool IsVec3Inside(Vector3 vec)
	{
		return false;
	}

	public AABB GetOffsetBoundingBox(float x, float y, float z)
	{
		return null;
	}

	public float CalculateXOffset(AABB boundingBox, float offset)
	{
		return 0f;
	}

	public float CalculateYOffset(AABB boundingBox, float offset)
	{
		return 0f;
	}

	public float CalculateYOffsetFloatUp(AABB boundingBox, float offset)
	{
		return 0f;
	}

	public float CalculateZOffset(AABB boundingBox, float offset)
	{
		return 0f;
	}

	public AABB Union(AABB other)
	{
		return null;
	}

	public bool IntersectWithRay(Ray ray)
	{
		return false;
	}

	private bool IsVecInYZ(Vector3? vec)
	{
		return false;
	}

	private bool IsVecInXZ(Vector3? vec)
	{
		return false;
	}

	private bool IsVecInXY(Vector3? vec)
	{
		return false;
	}

	public override string ToString()
	{
		return null;
	}
}
