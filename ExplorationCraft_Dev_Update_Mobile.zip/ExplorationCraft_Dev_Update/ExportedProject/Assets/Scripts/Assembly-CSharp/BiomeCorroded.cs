public class BiomeCorroded : Biome
{
	public BiomeCorroded(int id)
		: base(0)
	{
	}

	public override byte GetSurfaceBlock(int depth, float density, int randomDepth)
	{
		return 0;
	}
}
