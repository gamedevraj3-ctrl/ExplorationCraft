using UnityEngine;

public class UIConverterCompoundSelectButtonEvent : MonoBehaviour
{
	public NewUIConverter uiConverter;

	private NewUIItemCraftEntry itemEntry;

	private void Start()
	{
	}

	private void ButtonClick(GameObject go)
	{
	}
}
