public class DataReader
{
	public static bool ReadInitialData()
	{
		return false;
	}
}
