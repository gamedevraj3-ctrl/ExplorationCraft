using System.Collections.Generic;
using UnityEngine;

public class EntityPathMove : MonoBehaviour
{
	public Entity entity;

	public List<Vector3> pathPosList;

	public int index;

	public Vector3 curStart;

	private void Start()
	{
	}

	private void Update()
	{
	}

	public bool IsArriveTarget(Vector3 targetPos, Vector3 curPos)
	{
		return false;
	}
}
