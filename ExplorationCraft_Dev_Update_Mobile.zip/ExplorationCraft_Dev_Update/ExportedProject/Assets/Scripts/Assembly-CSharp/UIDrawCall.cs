using System;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
[AddComponentMenu("NGUI/Internal/Draw Call")]
public class UIDrawCall : MonoBehaviour
{
	public enum Clipping
	{
		None = 0,
		AlphaClip = 2,
		SoftClip = 3,
		ConstrainButDontClip = 4
	}

	private static BetterList<UIDrawCall> mActiveList;

	private static BetterList<UIDrawCall> mInactiveList;

	[NonSerialized]
	[HideInInspector]
	public int depthStart;

	[NonSerialized]
	[HideInInspector]
	public int depthEnd;

	[NonSerialized]
	[HideInInspector]
	public UIPanel manager;

	[NonSerialized]
	[HideInInspector]
	public UIPanel panel;

	[NonSerialized]
	[HideInInspector]
	public bool alwaysOnScreen;

	private Material mMaterial;

	private Texture mTexture;

	private Shader mShader;

	private Clipping mClipping;

	private Vector4 mClipRange;

	private Vector2 mClipSoft;

	private Transform mTrans;

	private Mesh mMesh;

	private MeshFilter mFilter;

	private MeshRenderer mRenderer;

	private Material mDynamicMat;

	private int[] mIndices;

	private bool mRebuildMat;

	private bool mReset;

	private int mRenderQueue;

	private Clipping mLastClip;

	private int mTriangles;

	[NonSerialized]
	public bool isDirty;

	private const int maxIndexBufferCache = 10;

	private static List<int[]> mCache;

	[Obsolete("Use UIDrawCall.activeList")]
	public static BetterList<UIDrawCall> list => null;

	public static BetterList<UIDrawCall> activeList => null;

	public static BetterList<UIDrawCall> inactiveList => null;

	public int renderQueue
	{
		get
		{
			return 0;
		}
		set
		{
		}
	}

	public int finalRenderQueue => 0;

	public Transform cachedTransform => null;

	public Material baseMaterial
	{
		get
		{
			return null;
		}
		set
		{
		}
	}

	public Material dynamicMaterial => null;

	public Texture mainTexture
	{
		get
		{
			return null;
		}
		set
		{
		}
	}

	public Shader shader
	{
		get
		{
			return null;
		}
		set
		{
		}
	}

	public int triangles => 0;

	public bool isClipped => false;

	public Clipping clipping
	{
		get
		{
			return Clipping.None;
		}
		set
		{
		}
	}

	public Vector4 clipRange
	{
		get
		{
			return default;
		}
		set
		{
		}
	}

	public Vector2 clipSoftness
	{
		get
		{
			return default;
		}
		set
		{
		}
	}

	private void CreateMaterial()
	{
	}

	private Material RebuildMaterial()
	{
		return null;
	}

	private void UpdateMaterials()
	{
	}

	public void Set(BetterList<Vector3> verts, BetterList<Vector3> norms, BetterList<Vector4> tans, BetterList<Vector2> uvs, BetterList<Color32> cols)
	{
	}

	private int[] GenerateCachedIndexBuffer(int vertexCount, int indexCount)
	{
		return null;
	}

	private void OnWillRenderObject()
	{
	}

	private void OnEnable()
	{
	}

	private void OnDisable()
	{
	}

	private void OnDestroy()
	{
	}

	public static UIDrawCall Create(UIPanel panel, Material mat, Texture tex, Shader shader)
	{
		return null;
	}

	private static UIDrawCall Create(string name, UIPanel pan, Material mat, Texture tex, Shader shader)
	{
		return null;
	}

	private static UIDrawCall Create(string name)
	{
		return null;
	}

	public static void ClearAll()
	{
	}

	public static void ReleaseAll()
	{
	}

	public static int Count(UIPanel panel)
	{
		return 0;
	}

	public static void Destroy(UIDrawCall dc)
	{
	}
}
