using BehaviorTree;

public class AnimalBehavior_EscapeForSunLight_Box : AnimalBehavior_EscapeForSunLight
{
	private Regulator moveTimer;

	public AnimalBehavior_EscapeForSunLight_Box(BevNode _o_ParentNode)
		: base(null)
	{
	}

	protected override void _DoEnter(object input)
	{
	}

	protected override BevRunningStatus _DoExecute(object input, object output)
	{
		return BevRunningStatus.k_BRS_Executing;
	}
}
