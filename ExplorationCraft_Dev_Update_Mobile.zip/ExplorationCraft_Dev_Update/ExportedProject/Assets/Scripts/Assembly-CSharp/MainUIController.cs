using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

public class MainUIController : MonoInstance<MainUIController>
{
	[CompilerGenerated]
	private sealed class _003CHideFakeLoading_003Ed__24 : IEnumerator<object>, IEnumerator, IDisposable
	{
		private int _003C_003E1__state;

		private object _003C_003E2__current;

		object IEnumerator<object>.Current
		{
			[DebuggerHidden]
			get
			{
				return null;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return null;
			}
		}

		[DebuggerHidden]
		public _003CHideFakeLoading_003Ed__24(int _003C_003E1__state)
		{
		}

		[DebuggerHidden]
		void IDisposable.Dispose()
		{
		}

		private bool MoveNext()
		{
			return false;
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			return this.MoveNext();
		}

		[DebuggerHidden]
		void IEnumerator.Reset()
		{
		}
	}

	public UIRoot uiRoot;

	public UIMain uiMain;

	public UISelect uiSelect;

	public UITutorialSelect uiTutorialSelect;

	public UIAchievement uiAchievement;

	public UISettings uiSettings;

	public UIDailyBonus uiDailyBonus;

	public UILimitSales uiLimitSales;

	public UIInAppPurchase uiInAppPurchase;

	public UIPurchaseConfirmationInMain uiPurchaseComfirmation;

	public UIQuit uiQuit;

	public UIRate uiRate;

	public UICredit uiCredit;

	public UIIntro uiIntro;

	public GameObject uiFakeLoading;

	public GameObject uiVideoReward;

	public UILabel txtCoin;

	public UILabel txtGem;

	public AudioSource backgroundMusic;

	private float startTime;

	private static bool firstOpen;

	private new void Awake()
	{
	}

	private void Start()
	{
	}

	public void Enter()
	{
	}

	[IteratorStateMachine(typeof(_003CHideFakeLoading_003Ed__24))]
	private IEnumerator HideFakeLoading()
	{
		return null;
	}

	private void Update()
	{
	}

	public void EnterWorldSelect()
	{
	}

	public void HideWorldSelect()
	{
	}

	public void EnterTutorialSelect()
	{
	}

	public void HideTutorialSelect()
	{
	}

	public void EnterAchievement()
	{
	}

	public void HideAchievement()
	{
	}

	public void EnterSettings()
	{
	}

	public void HideSettings()
	{
	}

	public void EnterDailyBonus()
	{
	}

	public void HideDailyBonus()
	{
	}

	public void EnterLimitSales()
	{
	}

	public void HideLimitSales()
	{
	}

	public void HandleMoreGames()
	{
	}

	public void SetMusicEnable(bool enable)
	{
	}

	public void RefreshMoney()
	{
	}

	public void ShowVideoAd()
	{
	}

	public void GetVideoReward()
	{
	}
}
