public class BlockAir : Block
{
	public BlockAir(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockAir(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	public override int GetDropItem(int metaData)
	{
		return 0;
	}
}
