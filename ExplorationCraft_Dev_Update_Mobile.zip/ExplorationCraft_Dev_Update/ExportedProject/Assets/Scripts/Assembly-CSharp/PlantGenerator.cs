using System;

public class PlantGenerator : DecorationGenerator
{
	private BlockType plantType;

	private int countPerChunk;

	private int metaData;

	private int probabilityPercentage;

	private bool isCorroded;

	public PlantGenerator(BlockType type, int count, int metaData = 0, int probabilityPercentage = 100, bool isCorroded = false)
	{
	}

	public override void Decorate(Chunk chunk, Random rand)
	{
	}
}
