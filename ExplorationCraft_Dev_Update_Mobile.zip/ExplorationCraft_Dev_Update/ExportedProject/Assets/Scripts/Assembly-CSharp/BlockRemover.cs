public class BlockRemover
{
	private Map map;

	private World world;

	private Vector3i diggingLocation;

	private Block targetBlock;

	private float lastDigTime;

	private const float DIG_COOL_TIME = 0.5f;

	private const float DIG_MAX_PERCENTAGE = 100f;

	private float digPercentage;

	private float digSpeed;

	private static float[] MATERIAL_SPEED_UP;

	private static Vector3i[] blockAdjacentOffset;

	public BlockRemover(World _world, Map _map)
	{
	}

	public static void SetMaterialSpeedUp(float[] materialSpeedUpList)
	{
	}

	public static float GetMaterialSpeedUp(ItemMaterial material)
	{
		return 0f;
	}

	public Block Digging(Vector3i targetLocation)
	{
		return null;
	}

	public void DigBlockAt(Vector3i hitPoint)
	{
	}

	public void RemoveBlockAt(int worldX, int worldY, int worldZ)
	{
	}

	public void RemoveBlockAt(int worldX, int worldY, int worldZ, bool usedSpecifiedTool)
	{
	}
}
