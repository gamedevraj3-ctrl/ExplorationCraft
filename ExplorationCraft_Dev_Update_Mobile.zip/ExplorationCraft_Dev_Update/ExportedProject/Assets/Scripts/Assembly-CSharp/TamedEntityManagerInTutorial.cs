using UnityEngine;

public class TamedEntityManagerInTutorial : TamedEntityManager
{
	private Vector3[] posList;

	public override void AddTamedEntity(EntityLiving target)
	{
	}

	public override void UnlockTamedEntity(int index)
	{
	}

	public override void ResetUnlock()
	{
	}

	public override void Summon()
	{
	}

	private int CompareDistanceToPlayer(Vector3 a, Vector3 b)
	{
		return 0;
	}
}
