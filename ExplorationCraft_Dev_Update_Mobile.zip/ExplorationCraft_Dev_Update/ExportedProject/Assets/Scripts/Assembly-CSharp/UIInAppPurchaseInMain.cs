using UnityEngine;

public class UIInAppPurchaseInMain : UIInAppPurchase
{
	public GameObject objMoney;

	public void ShowTabCoin()
	{
	}

	public void ShowTabGem()
	{
	}

	public override void Hide()
	{
	}
}
