using UnityEngine;

public class PickaxeCallback : MonoBehaviour
{
	public ParticleSystem firework;

	public void OnPick()
	{
	}
}
