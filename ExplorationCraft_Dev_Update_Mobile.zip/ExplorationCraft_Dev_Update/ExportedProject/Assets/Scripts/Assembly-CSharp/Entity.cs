using LibNbt.Tags;
using UnityEngine;

public abstract class Entity : MonoBehaviour
{
	public enum CollideLayer
	{
		All = 0,
		Player = 1,
		Animal = 2,
		FallObject = 3,
		Projectile = 4
	}

	public int entityID;

	public CollideLayer collideLayer;

	public Material selfMaterial;

	public MeshRenderer[] selfRenderers;

	[HideInInspector]
	public AABB aabb;

	[HideInInspector]
	public Vector3 nextPosition;

	public Vector3 velocity;

	[HideInInspector]
	public Vector3 pushVelocity;

	public int weight;

	public float moveSpeed;

	public float jumpSpeed;

	public float swimSpeed;

	[HideInInspector]
	public float gravity;

	public bool isGravity;

	[HideInInspector]
	public bool isGrounded;

	[HideInInspector]
	public bool isInWater;

	[HideInInspector]
	public bool isOnWater;

	public float length;

	public float Width;

	public float Height;

	public float StepHeight;

	[HideInInspector]
	public bool canAutoSwing;

	[HideInInspector]
	public bool isCollidedHorizontally;

	[HideInInspector]
	public bool isCollidedVertically;

	[HideInInspector]
	public bool isInLadder;

	protected bool isInAir;

	private int lastGroundHeight;

	protected const float WATER_SPEED_REDUCE = 0.5f;

	[HideInInspector]
	public bool savedInChunk;

	[HideInInspector]
	public int savedChunkX;

	[HideInInspector]
	public int savedChunkZ;

	[HideInInspector]
	public Vector3 lastPosition;

	[HideInInspector]
	public Quaternion lastRotation;

	private bool isRecycled;

	protected Material clonedMaterial;

	public virtual Vector3 pos
	{
		get
		{
			return default;
		}
		set
		{
		}
	}

	public Vector3 eulerAngle
	{
		get
		{
			return default;
		}
		set
		{
		}
	}

	private void Awake()
	{
	}

	private void Start()
	{
	}

	protected void Update()
	{
	}

	protected virtual void AwakeInternal()
	{
	}

	protected virtual void StartInternal()
	{
	}

	protected virtual void UpdateInternal()
	{
	}

	protected void UpdateSavedChunk()
	{
	}

	public virtual bool IsStaticEntity()
	{
		return false;
	}

	public virtual void MoveEntity(float x, float y, float z)
	{
	}

	protected virtual void PushEntity(float x, float y, float z)
	{
	}

	public virtual void OnHit()
	{
	}

	protected virtual void OnJumpDown()
	{
	}

	public virtual void OnDamage(DamageType damageType, float amount)
	{
	}

	public virtual void OnDamage(DamageType damageType, float amount, int buffLevel)
	{
	}

	public virtual void Reset()
	{
	}

	public void Transport(Vector3 newPos)
	{
	}

	public void SetSavedChunk(Chunk chunk)
	{
	}

	public void ResetSavedChunk()
	{
	}

	public void SetUnsaved()
	{
	}

	public virtual NbtCompound GetNbtData()
	{
		return null;
	}

	public virtual void Create(NbtCompound entityCompound)
	{
	}

	public virtual void Recycle(bool removeFromChunk = false)
	{
	}

	protected void RefreshAABB()
	{
	}
}
