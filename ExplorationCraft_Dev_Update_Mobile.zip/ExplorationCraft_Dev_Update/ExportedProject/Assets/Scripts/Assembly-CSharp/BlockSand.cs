public class BlockSand : Block
{
	public BlockSand(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockSand(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}
}
