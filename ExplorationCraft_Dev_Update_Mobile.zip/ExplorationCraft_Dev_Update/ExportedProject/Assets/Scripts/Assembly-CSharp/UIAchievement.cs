using UnityEngine;

public class UIAchievement : NewUIBase
{
	public UIScrollView scrollView;

	public Transform listFirstPos;

	public float listOffset;

	public GameObject achievementEntryPrefab;

	public TweenScale scaleTweener;

	private UIAchievementEntry[] uiAchievementEntrys;

	private bool hasInited;

	public override void Show()
	{
	}

	private void InstanceItems()
	{
	}

	private void RefreshAchievement()
	{
	}

	public void Achieve(UIAchievementEntry entry)
	{
	}
}
