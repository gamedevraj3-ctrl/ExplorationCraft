using UnityEngine;

[AddComponentMenu("NGUI/Interaction/Center Scroll View on Click")]
public class UICenterOnClick : MonoBehaviour
{
	private UIPanel mPanel;

	private UICenterOnChild mCenter;

	private void Start()
	{
	}

	private void OnClick()
	{
	}
}
