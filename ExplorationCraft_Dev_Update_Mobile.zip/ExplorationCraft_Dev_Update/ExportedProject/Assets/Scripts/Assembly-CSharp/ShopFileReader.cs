public class ShopFileReader
{
	private const string SHOP_SALES_FILE_NAME = "Shop_Sales";

	public static bool SetShopAttribute()
	{
		return false;
	}
}
