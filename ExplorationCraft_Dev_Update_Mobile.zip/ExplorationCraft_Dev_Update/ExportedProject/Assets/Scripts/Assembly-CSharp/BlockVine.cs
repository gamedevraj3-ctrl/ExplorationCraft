using System;
using UnityEngine;

public class BlockVine : Block
{
	private static float[][] vineAABBOffset;

	public BlockVine(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockVine(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	[Obsolete("To avoid data race, directly get color from biome")]
	public override Color ColorMultiplier(Map map, int worldX, int worldY, int worldZ)
	{
		return default;
	}

	public override void GenBlockMesh(MeshGenerator meshGenerator, Map map, int blockX, int blockY, int blockZ, Chunk chunk, int x, int y, int z, byte blockLight)
	{
	}

	public override Color ColorMultiplier(Biome biome, BlockType type)
	{
		return default;
	}

	public override float[] GetAABBOffset(int metaData)
	{
		return null;
	}

	public override bool CanPlaceBlockAt(Block attachBlock, BlockFromDirection direction)
	{
		return false;
	}

	public override int GetDropItem(int metaData)
	{
		return 0;
	}
}
