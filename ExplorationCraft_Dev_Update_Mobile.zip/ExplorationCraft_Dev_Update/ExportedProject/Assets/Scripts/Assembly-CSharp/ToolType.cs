public enum ToolType
{
	Saw = 0,
	Pickaxe = 1,
	Reversed = 2,
	Hoe = 3,
	Sword = 4,
	Bow = 5,
	Helmet = 6,
	Chestplate = 7,
	Leggings = 8,
	Gauntlets = 9,
	Ring = 10,
	Shears = 11,
	Hammer = 12,
	Wand = 13
}
