public class EntityBoxMonster : EntityLiving
{
	protected override void AddExtraBevTreeNode()
	{
	}
}
