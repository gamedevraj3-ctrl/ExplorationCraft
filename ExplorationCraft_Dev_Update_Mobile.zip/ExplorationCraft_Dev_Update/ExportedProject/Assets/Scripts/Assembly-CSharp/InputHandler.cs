using UnityEngine;

public class InputHandler : MonoBehaviour
{
	public enum TouchType
	{
		None = 0,
		Down = 1,
		Up = 2,
		Touching = 3
	}

	public Rect hitInputRect;

	public HandHolder handHolder;

	public EntityPlayer player;

	public Transform cameraTransform;

	public CameraController cameraController;

	public JoyStick joyStick;

	private int maxDistance;

	private bool hasTouchInRect;

	private bool hasTouchStay;

	private bool hasTouchMoved;

	public bool isInteractable;

	public bool isRotatable;

	public bool isMovable;

	public bool isDiggable;

	private Vector2 touchStartPos;

	private float touchStartTime;

	private TouchType currentTouchType;

	private bool isJumpPressed;

	private Vector2 preTouchPos;

	private Vector2[] preTouchPosList;

	private bool[] isTouchUseFlags;

	private const float MAX_DELTA_TIME = 1f / 15f;

	private void Start()
	{
	}

	private TouchType ConvertTouchType(TouchPhase touchPhase)
	{
		return TouchType.None;
	}

	private void Update()
	{
	}

	private BlockType GetInBlock()
	{
		return BlockType.Air;
	}

	private BlockType GetDownBlock()
	{
		return BlockType.Air;
	}

	public void OnBtDown(bool isPressed)
	{
	}

	public void OnBtUp()
	{
	}

	public void OnBtCancel()
	{
	}
}
