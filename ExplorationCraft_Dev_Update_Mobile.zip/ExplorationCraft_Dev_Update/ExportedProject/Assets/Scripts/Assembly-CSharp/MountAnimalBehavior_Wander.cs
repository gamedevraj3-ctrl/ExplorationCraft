using BehaviorTree;
using UnityEngine;

public class MountAnimalBehavior_Wander : BevNodeTerminal
{
	private Vector2 wanderTimeRange;

	private float wanderTime;

	private float timeFlag;

	private float targetAngles;

	public MountAnimalBehavior_Wander(BevNode _o_ParentNode, Vector2 _wanderTimeRange)
		: base(null)
	{
	}

	protected override void _DoEnter(object input)
	{
	}

	protected override BevRunningStatus _DoExecute(object input, object output)
	{
		return BevRunningStatus.k_BRS_Executing;
	}

	protected override bool _DoEvaluate(object input)
	{
		return false;
	}
}
