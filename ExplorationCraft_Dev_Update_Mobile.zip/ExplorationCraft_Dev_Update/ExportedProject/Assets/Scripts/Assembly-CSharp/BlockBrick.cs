using UnityEngine;

public class BlockBrick : Block
{
	public BlockBrick(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockBrick(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	public override Color ColorMultiplier(Biome biome, BlockType type)
	{
		return default;
	}
}
