using System.Collections.Generic;
using UnityEngine;

public class Chunk
{
	public const int SIZE_X_BITS = 4;

	public const int SIZE_Y_BITS = 7;

	public const int SIZE_Z_BITS = 4;

	public const int SIZE_YZ_BITS = 11;

	public const int SIZE_X = 16;

	public const int SIZE_Y = 128;

	public const int SIZE_Z = 16;

	public const int SIZE_X_MASK = 15;

	public const int SIZE_Y_MASK = 127;

	public const int SIZE_Z_MASK = 15;

	public const int BLOCKS_COUNT = 32768;

	public int[] heightMap;

	public int[] biomeList;

	public int[] precipitationHeightMap;

	public List<Entity> entityList;

	public List<KeyValuePair<Vector3i, ItemPackage>> chestList;

	public int chunkX;

	public int chunkZ;

	public BetterList<Vector3>[] verticeMap;

	public BetterList<int>[] indeiceMap;

	public BetterList<Vector2>[] uvMap;

	public BetterList<Color32>[] colorMap;

	public int[] genMeshVerticeIndexList;

	public int genTextureIndex;

	public ChunkGameObject chunkGameObject;

	public bool isBlockDirty;

	public bool needGenMesh;

	public bool markedUpdate;

	public bool isLightDirt;

	public bool isTerrainPopulated;

	public readonly List<Vector3i> TopSoilBlocks;

	public byte[] blockIds;

	public byte[] lights;

	public byte[] blockMetaDatas;

	public int lastUpdateTicks;

	public BetterList<int> updateBlockList;

	public int maxPrecipitationHeight;

	public Chunk(int x, int z)
	{
	}

	public void UpdateHeightMap()
	{
	}

	public void UpdateHeightMap(int x, int z)
	{
	}

	public int UpdateAndGetPrecipitationHeight(int x, int z)
	{
		return 0;
	}

	public int GetPrecipitationHeight(int x, int z)
	{
		return 0;
	}

	public int GetPrecipitationHeightInBossStage(int x, int z)
	{
		return 0;
	}

	public Block GetBlock(int x, int y, int z)
	{
		return null;
	}

	public BlockType GetBlockType(int x, int y, int z)
	{
		return BlockType.Air;
	}

	public void SetBlockType(int x, int y, int z, BlockType type)
	{
	}

	public void SetBlockList(byte[] blockIDList)
	{
	}

	public byte GetSkyLight(int x, int y, int z)
	{
		return 0;
	}

	public void SetSkyLight(int x, int y, int z, byte light)
	{
	}

	public byte GetBlockLight(int x, int y, int z)
	{
		return 0;
	}

	public void SetBlockLight(int x, int y, int z, byte light)
	{
	}

	public byte GetLightValue(int x, int y, int z)
	{
		return 0;
	}

	public int GetBlockMetaData(int x, int y, int z)
	{
		return 0;
	}

	public void SetBlockMetaData(int x, int y, int z, int data)
	{
	}

	public void AddEntity(Entity entity)
	{
	}

	public void RemoveEntity(Entity entity)
	{
	}

	public void AddChestPackage(Vector3i key, ItemPackage package)
	{
	}

	public void RemoveChestPackage(Vector3i key, ItemPackage package)
	{
	}

	public int GetBiomeAt(int x, int z)
	{
		return 0;
	}

	private void InitializeBlocks()
	{
	}

	public int GetHeight(int x, int z)
	{
		return 0;
	}

	public void SetHeight(int x, int z, int height)
	{
	}

	public void Reset()
	{
	}

	public void Unload()
	{
	}

	public void ResetGenMeshData()
	{
	}

	public void SetPos(int x, int z)
	{
	}

	public void SetX(int x)
	{
	}

	public void SetZ(int z)
	{
	}

	public override string ToString()
	{
		return null;
	}

	public void UpdateTick(World world)
	{
	}

	public void RandomUpdateTick(World world)
	{
	}

	public void SpawnMonster(World world)
	{
	}

	public void SpawnAnimal()
	{
	}

	public void UpdateTickAfterLoadFromFile(World world)
	{
	}
}
