using UnityEngine;

public class UIMountFeedBackgroundTouchEvent : MonoBehaviour
{
	public NewUITabMount uiMount;

	private void Start()
	{
	}

	private void ScreenClick(GameObject go)
	{
	}
}
