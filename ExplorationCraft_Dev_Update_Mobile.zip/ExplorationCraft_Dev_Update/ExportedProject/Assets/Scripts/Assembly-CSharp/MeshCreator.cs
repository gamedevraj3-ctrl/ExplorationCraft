using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(MeshFilter), typeof(MeshRenderer))]
public class MeshCreator : MonoBehaviour
{
	public enum MeshType
	{
		Fire = 0,
		MediumFire = 1,
		BigFire = 2
	}

	public MeshType type;

	private Mesh mesh;

	private List<Vector3> vertices;

	private List<Vector2> uv;

	private List<int> triangles;

	private const int QUAD_VERTICE_COUNT = 4;

	public Mesh GetMesh()
	{
		return null;
	}

	private void OnEnable()
	{
	}

	public void Refresh()
	{
	}

	private void CreateFireMesh()
	{
	}

	private void CreateDoubleFace(Vector3[] quadVertices)
	{
	}
}
