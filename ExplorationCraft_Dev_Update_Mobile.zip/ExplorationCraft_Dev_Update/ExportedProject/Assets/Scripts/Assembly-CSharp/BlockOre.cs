public class BlockOre : Block
{
	private int dropItemID;

	public BlockOre(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockOre(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	public BlockOre(BlockType type, DiggingType material, int dropItem)
		: base(BlockType.Air)
	{
	}

	public override int GetDropItem(int metaData)
	{
		return 0;
	}
}
