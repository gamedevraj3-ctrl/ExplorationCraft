public class BlockSugarbeet : BlockCrop
{
	public const int MAX_META_DATA = 2;

	private const int GROWTH_PROBABILITY = 180;

	private const int GROWTH_WET_PROBABILITY = 150;

	private static float[][] sugarbeetAABBOffset;

	public BlockSugarbeet(BlockType type)
		: base(BlockType.Air, 0, 0, 0)
	{
	}

	public BlockSugarbeet(BlockType type, DiggingType material)
		: base(BlockType.Air, 0, 0, 0)
	{
	}

	public override void GenBlockMesh(MeshGenerator meshGenerator, Map map, int blockX, int blockY, int blockZ, Chunk chunk, int x, int y, int z, byte blockLight)
	{
	}

	public override int GetDropQuantity(int metaData)
	{
		return 0;
	}

	public override int GetExtraDropItem(int metaData)
	{
		return 0;
	}

	public override float[] GetAABBOffset(int metaData)
	{
		return null;
	}
}
