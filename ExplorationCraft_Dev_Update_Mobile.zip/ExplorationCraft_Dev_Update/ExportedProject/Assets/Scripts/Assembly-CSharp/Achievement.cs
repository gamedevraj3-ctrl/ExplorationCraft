using System.Text;

public class Achievement
{
	public string name;

	protected string descriptionFormat;

	protected int typeParam;

	protected int[] amountParamArray;

	protected int[] bonusAmountArray;

	protected MoneyType[] moneyTypeArray;

	protected StringBuilder description;

	protected StringBuilder progressString;

	public int Level { get; private set; }

	public Achievement(string name, string descriptionFormat, int typeParam, int[] amountParamArray, MoneyType[] moneyTypeArray, int[] bonusAmountArray)
	{
	}

	public virtual bool CheckComplete()
	{
		return false;
	}

	public virtual void OnComplete()
	{
	}

	public virtual string GetDescription()
	{
		return null;
	}

	public virtual float GetProgress()
	{
		return 0f;
	}

	public virtual string GetProgressStr()
	{
		return null;
	}

	public MoneyType GetBonusType()
	{
		return MoneyType.Coin;
	}

	public int GetBonusAmount()
	{
		return 0;
	}

	public void SetLevel(int level)
	{
	}
}
