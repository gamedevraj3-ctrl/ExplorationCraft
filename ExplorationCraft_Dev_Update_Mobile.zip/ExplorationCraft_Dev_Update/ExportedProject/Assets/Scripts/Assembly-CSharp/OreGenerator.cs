using System;

public class OreGenerator : DecorationGenerator
{
	private BlockType oreType;

	private int minHeight;

	private int maxHeight;

	private int countPerChunk;

	private int probabilityPercentage;

	public OreGenerator(BlockType oreType, int minHeight, int maxHeight, int count, int probabilityPercentage)
	{
	}

	public override void Decorate(Chunk chunk, Random rand)
	{
	}
}
