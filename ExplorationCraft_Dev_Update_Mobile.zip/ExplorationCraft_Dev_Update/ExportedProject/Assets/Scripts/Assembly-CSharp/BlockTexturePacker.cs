using UnityEngine;

public class BlockTexturePacker : MonoBehaviour
{
	public Texture2DArray[] textureArrayList;

	public AtlasTexture[] atlasList;

	public int materialCount;
}
