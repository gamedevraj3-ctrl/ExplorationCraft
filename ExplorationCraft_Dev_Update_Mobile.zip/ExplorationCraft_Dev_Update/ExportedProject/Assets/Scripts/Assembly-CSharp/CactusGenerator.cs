using System;

public class CactusGenerator : DecorationGenerator
{
	private int countPerChunk;

	private int maxHeight;

	private int probabilityPercentage;

	public CactusGenerator(int height, int count, int probabilityPercentage)
	{
	}

	public override void Decorate(Chunk chunk, Random rand)
	{
	}
}
