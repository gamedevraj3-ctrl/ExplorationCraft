public class Regulator
{
	private float timePeriod;

	private float timePeriodInverse;

	private float timeStep;

	public Regulator()
	{
	}

	public Regulator(float timePeriod)
	{
	}

	public void Reset()
	{
	}

	public void ForceReady()
	{
	}

	public void SetTimePeriod(float timePeriod)
	{
	}

	public float GetNormalizedTime()
	{
		return 0f;
	}

	public float GetTime()
	{
		return 0f;
	}

	public bool IsReady(float deltaTime)
	{
		return false;
	}
}
