public class UICredit : NewUIBase
{
	public TweenScale scaleTweener;

	public override void Show()
	{
	}
}
