public class TamedEntityManager
{
	public int selectedEntity;

	public NewUITabMount uiMount;

	public TamedEntity[] entitiesCanBeTamed;

	public void Initialize()
	{
	}

	public bool IsEntityTamed(int entityID)
	{
		return false;
	}

	public virtual void AddTamedEntity(EntityLiving target)
	{
	}

	public virtual void UnlockTamedEntity(int index)
	{
	}

	public void SetTamedEntity(int entityID, float favorability, int feedItem, int feedCount, int feedPercentage)
	{
	}

	public void SetSelect(int index)
	{
	}

	public FeedController GetFeedController(int index)
	{
		return null;
	}

	public virtual void Summon()
	{
	}

	public bool IsFavorabilityEnough(int entityID)
	{
		return false;
	}

	public void DecreaseFavorability(int entityID, float distance)
	{
	}

	public float GetSummoningFavorabilityRatio(int index)
	{
		return 0f;
	}

	public void SetSummonedEntity(EntityLiving entity)
	{
	}

	public void UpdateTick()
	{
	}

	public virtual void ResetUnlock()
	{
	}
}
