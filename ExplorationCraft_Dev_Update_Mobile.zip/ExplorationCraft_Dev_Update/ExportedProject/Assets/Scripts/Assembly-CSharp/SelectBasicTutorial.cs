public class SelectBasicTutorial : Tutorial
{
	public SelectBasicTutorial(string description)
	{
	}

	public override void Enter()
	{
	}

	public override bool CheckComplete()
	{
		return false;
	}

	public override void OnComplete()
	{
	}
}
