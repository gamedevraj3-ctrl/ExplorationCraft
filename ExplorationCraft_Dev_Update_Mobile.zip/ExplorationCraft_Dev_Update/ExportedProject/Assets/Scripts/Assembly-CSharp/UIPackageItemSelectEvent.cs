using UnityEngine;

public class UIPackageItemSelectEvent : MonoBehaviour
{
	public NewUITabItems uiTabItems;

	public NewUIItemPackageEntry itemEntry;

	private void Start()
	{
	}

	private void ButtonClick(GameObject go)
	{
	}
}
