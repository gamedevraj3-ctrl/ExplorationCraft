using UnityEngine;

public class UIDailyBonus : NewUIBase
{
	public UIDailyBonusEntry[] entryList;

	public UIWidget[] entryWidgets;

	public UIButton btClaim;

	public UILabel txtCoin;

	public UILabel txtGem;

	public GameObject objMoney;

	public GameObject obj7thMoney;

	public GameObject obj7thMount;

	public GameObject groupedOnline;

	public UILabel txtOffline;

	private bool needShowDailyBonus;

	private int continousLoginDays;

	public TweenScale scaleTweener;

	public override void Show()
	{
	}

	public override void Hide()
	{
	}

	public void RefreshDailyBonus()
	{
	}

	public void Claim()
	{
	}

	private void RefreshMoney()
	{
	}

	public void ResizeHorizontal(float factor)
	{
	}
}
