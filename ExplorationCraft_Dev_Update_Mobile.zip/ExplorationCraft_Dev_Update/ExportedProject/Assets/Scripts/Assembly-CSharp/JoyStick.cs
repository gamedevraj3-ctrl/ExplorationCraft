using UnityEngine;

public class JoyStick : MonoBehaviour
{
	public Camera uiCamera;

	public Transform directionTr;

	public UISprite anchorSprite;

	public UIPanel uiJoyStick;

	public Vector2 position;

	public int currentTouchID;

	public bool isInActiveState;

	private Vector2 centerPosition;

	public void Show()
	{
	}

	public void Hide()
	{
	}

	private void Start()
	{
	}

	private void Drag(GameObject go, Vector2 delta)
	{
	}

	private void ButtonPress(GameObject go, bool isPressed)
	{
	}

	private void SetDirection()
	{
	}
}
