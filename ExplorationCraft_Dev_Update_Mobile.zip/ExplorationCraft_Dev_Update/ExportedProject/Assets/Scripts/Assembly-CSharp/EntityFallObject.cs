using LibNbt.Tags;
using UnityEngine;

public class EntityFallObject : Entity
{
	public int itemID;

	public int amount;

	public int durability;

	public Animation animRoot;

	public EntityPlayer entityPlayer;

	public bool hasCollected;

	public MeshFilter modelMeshFilter;

	private float timeFlag;

	private const float COLLECT_COOL_TIME = 1f;

	private const float RECYLE_TIME = 300f;

	protected override void StartInternal()
	{
	}

	public override void Reset()
	{
	}

	protected override void UpdateInternal()
	{
	}

	public override void MoveEntity(float x, float y, float z)
	{
	}

	protected void Collect()
	{
	}

	public override bool IsStaticEntity()
	{
		return false;
	}

	public override NbtCompound GetNbtData()
	{
		return null;
	}

	public override void Create(NbtCompound entityCompound)
	{
	}

	public override void Recycle(bool removeFromChunk = false)
	{
	}
}
