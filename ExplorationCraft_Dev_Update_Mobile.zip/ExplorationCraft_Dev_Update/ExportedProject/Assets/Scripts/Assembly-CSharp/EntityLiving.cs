using System.Collections.Generic;
using BehaviorTree;
using LibNbt.Tags;
using UnityEngine;

public class EntityLiving : Entity
{
	public int livingID;

	public AnimalType animalType;

	public bool isDarkMonster;

	public int maxHealth;

	protected float health;

	public float damage;

	public float defense;

	public float rotateSpeed;

	public BevNode bevRoot;

	public BevInputData bevInputData;

	public Material extraMaterial;

	public MeshRenderer[] extraRenderers;

	public SimpleEffectType fireType;

	public Transform firePos;

	public AudioClip idleAudio;

	public AudioClip hitAudio;

	public AudioClip attackAudio;

	public AudioClip deathAudio;

	public Renderer saddle;

	public Transform particleSpawnPos;

	public EntityLivingAnimationController animationController;

	public bool isRidable;

	public bool isRiding;

	public bool isTamed;

	public int feedItemID;

	public int tamingSucceedFavorability;

	public int maxTamingFavorability;

	public float tamingFavorabilityReduceSpeed;

	protected float tamingFavorability;

	protected float lastFeedTime;

	public float feedTimeInterval;

	public int initTamingProbability;

	public int tamingProbabilityInc;

	protected int currentTamingProbability;

	public float ridingSpeedForward;

	public float ridingSpeedBack;

	public float ridingSpeedHorizontal;

	public float ridingJumpSpeed;

	public float fallDamageReduceRatio;

	public int exp;

	public List<DropoutUnion> dropoutItems;

	public float hitTime;

	public float cooltime;

	public float attackDuration;

	public float disappearTime;

	public int maxHatred;

	public int hatred;

	public int hatredDecreasePerSecond;

	private Regulator hatredRegulator;

	public int lastTimeTick;

	public int rage;

	public int maxRage;

	private float lastDismountTime;

	private float lastDamageTime;

	public EntityLivingBuffController buffController;

	public Color frozenColor;

	protected Material clonedExtraMaterial;

	private const float MAX_ARMOR_VALUE = 25f;

	private const float DAMAGE_COOL_TIME = 1f;

	private const float MAX_DISTANCE_FOR_RECYCLE = 48f;

	private bool isTutorialStop;

	protected override void AwakeInternal()
	{
	}

	protected override void StartInternal()
	{
	}

	private void CreateBevTree()
	{
	}

	protected virtual void AddExtraBevTreeNode()
	{
	}

	public override void Reset()
	{
	}

	public void SetHealth(float newHealth)
	{
	}

	public void SetTamingState(float favorability, int probability)
	{
	}

	public virtual bool AddFavorability()
	{
		return false;
	}

	protected virtual void SpawnFavorParticle()
	{
	}

	public Material GetMaterial()
	{
		return null;
	}

	public Material GetExtraMaterial()
	{
		return null;
	}

	public bool IsFriendly()
	{
		return false;
	}

	protected new void Update()
	{
	}

	public override void MoveEntity(float x, float y, float z)
	{
	}

	public override void OnDamage(DamageType damageType, float amount)
	{
	}

	public override void OnDamage(DamageType damageType, float amount, int buffLevel)
	{
	}

	public virtual void DropItems()
	{
	}

	public void AddKillCountRecord()
	{
	}

	public float GetDistanceFromPlayer()
	{
		return 0f;
	}

	public float GetHealth()
	{
		return 0f;
	}

	public override NbtCompound GetNbtData()
	{
		return null;
	}

	public override void Create(NbtCompound entityCompound)
	{
	}

	public void SpawnSmoke()
	{
	}

	public override void Recycle(bool removeFromChunk = false)
	{
	}

	public void AddPlayerExperience()
	{
	}

	public void SetRidden(EntityPlayer player)
	{
	}

	public void ResetRidden()
	{
	}

	public bool CanBeRidden()
	{
		return false;
	}

	public bool IsAwayFromPlayer()
	{
		return false;
	}

	public bool IsNearMapEdge()
	{
		return false;
	}

	public bool CheckAttack(Entity entity)
	{
		return false;
	}

	public virtual bool IsBoss()
	{
		return false;
	}

	private void SetMaterialLight(Vector3i posi)
	{
	}

	public void StopAllAction(bool resetAnimation = false)
	{
	}

	public void ResumeAction()
	{
	}
}
