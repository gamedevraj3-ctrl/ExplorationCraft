using UnityEngine;

public class UIPortalSwitchTabEvent : MonoBehaviour
{
	public UIPortal uiPortal;

	public PortalType type;

	private void Start()
	{
	}

	private void ButtonClick(GameObject go)
	{
	}
}
