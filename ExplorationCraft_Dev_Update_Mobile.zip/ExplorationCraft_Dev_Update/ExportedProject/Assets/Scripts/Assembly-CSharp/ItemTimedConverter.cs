using System.Collections.Generic;

public class ItemTimedConverter : ItemConverter
{
	public enum ConverterProcessingType
	{
		Start = 0,
		Stationary = 1,
		End = 2
	}

	private bool isLastUpdateBurning;

	private static int[] expandPrice;

	private static MoneyType[] expandMoneyType;

	private Vector3i pos;

	private int activedQueueCount;

	private const int MAX_QUEUE_COUNT = 11;

	private List<CompoundBundle> compoundBundleQueue;

	public int energyItemId;

	public int energyCount;

	public int leftEnergy;

	public ItemTimedConverter(ItemPackage _itemPackage)
		: base(null)
	{
	}

	public List<CompoundBundle> GetCurrentCompounds()
	{
		return null;
	}

	public int GetExpandPrice()
	{
		return 0;
	}

	public MoneyType GetExpandMoneyType()
	{
		return MoneyType.Coin;
	}

	public int GetActivedQueueCount()
	{
		return 0;
	}

	public bool AddActivedQueueCount()
	{
		return false;
	}

	public int GetMaxQueueCount()
	{
		return 0;
	}

	public bool AddCompoundBundle(CompoundBundle cBundle)
	{
		return false;
	}

	public bool AddCompound(Compound c)
	{
		return false;
	}

	public bool AddAndUseCompound(Compound c)
	{
		return false;
	}

	public bool ClaimAndRemoveCompound(int index)
	{
		return false;
	}

	public ConverterProcessingType UpdateTick(int passedTicks)
	{
		return ConverterProcessingType.Start;
	}

	public void Clear()
	{
	}

	public bool IsFuelBurning()
	{
		return false;
	}

	public void SetPosition(Vector3i vec)
	{
	}

	public Vector3i GetPosition()
	{
		return default;
	}

	public bool IsConverterExist()
	{
		return false;
	}
}
