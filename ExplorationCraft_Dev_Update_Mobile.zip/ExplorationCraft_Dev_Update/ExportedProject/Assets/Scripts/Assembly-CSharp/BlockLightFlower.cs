public class BlockLightFlower : BlockFlower
{
	private float[] lightFlowerAABBOffset;

	public BlockLightFlower(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockLightFlower(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	public override float[] GetAABBOffset(int metaData)
	{
		return null;
	}

	public override DiggingConvertType ConvertAfterDiggingAround(BlockFromDirection direction, int metaData)
	{
		return DiggingConvertType.None;
	}

	public override bool CanPlaceBlockAt(Block attachBlock, BlockFromDirection direction)
	{
		return false;
	}
}
