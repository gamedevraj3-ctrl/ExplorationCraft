public class ShopGenerator : IBaseCampGenerator
{
	private readonly Map map;

	public ShopGenerator(Map worldData)
	{
	}

	public Chunk GenerateBuilding(int blockX, int blockY, int blockZ, int metaData)
	{
		return null;
	}
}
