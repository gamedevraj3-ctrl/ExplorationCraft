public class AchievementBlockBreak : Achievement
{
	public AchievementBlockBreak(string name, string descriptionFormat, int typeParam, int[] amountParamArray, MoneyType[] moneyTypeArray, int[] bonusAmountArray)
		: base(null, null, 0, null, null, null)
	{
	}

	public override bool CheckComplete()
	{
		return false;
	}

	public override float GetProgress()
	{
		return 0f;
	}

	public override string GetProgressStr()
	{
		return null;
	}
}
