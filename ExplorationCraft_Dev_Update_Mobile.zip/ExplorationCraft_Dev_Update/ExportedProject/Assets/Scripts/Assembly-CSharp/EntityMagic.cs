using LibNbt.Tags;
using UnityEngine;

public class EntityMagic : EntityProjectile
{
	public ParticleSystem trailPariticle;

	public SimpleEffectType explorationEffect;

	public float maxDistance;

	private float sqrMaxDistance;

	protected override void StartInternal()
	{
	}

	public override void Reset()
	{
	}

	protected new void Update()
	{
	}

	public override void Create(NbtCompound entityCompound)
	{
	}

	public override void Recycle(bool removeFromChunk = false)
	{
	}

	protected override void OnPostHit()
	{
	}

	public override void OnPostRecycle()
	{
	}
}
