using System;
using UnityEngine;

[Serializable]
public class BevInputData
{
	public EntityLiving entity;

	public EntityPlayer entityPlayer;

	public float deltaTime;

	public bool isHited;

	public Vector2 moveToTargetRange;

	public float attackRadius;

	public EntityAttackType attackType;

	public bool isPanic;

	public string curState;

	public void Reset()
	{
	}
}
