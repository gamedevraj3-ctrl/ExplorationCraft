public class ItemToolProperty : ItemCommonProperty
{
	public ItemMaterial itemMaterial;

	public ToolType toolType;

	public float damage;

	public int defense;

	private static int[] durabilityList;

	public int durability => 0;

	public ItemToolProperty(ItemType itemType, ToolType toolType, ItemMaterial itemMaterial, int damage = 0, int defense = 0)
		: base(ItemType.ToolWeapons, isItemFue: false)
	{
	}

	public static void SetDurability(int[] materialDurability)
	{
	}

	public override ItemCommonProperty SetDescription(ItemDescription description)
	{
		return null;
	}
}
