using System.Collections.Generic;

public class ItemConverterController
{
	private static Vector3i illegalPos;

	private List<ItemTimedConverter> converters;

	public ItemTimedConverter AddItemConverter(ItemPackage itemPackage)
	{
		return null;
	}

	public List<ItemTimedConverter> GetConverters()
	{
		return null;
	}

	public ItemTimedConverter GetItemConverterByAABB(AABB aabb)
	{
		return null;
	}

	public ItemTimedConverter GetItemConverterByPos(Vector3i vec)
	{
		return null;
	}

	public void Register(Vector3i vec)
	{
	}

	public void Unregister(Vector3i vec)
	{
	}

	public bool IsConverterProcessing(Vector3i vec)
	{
		return false;
	}
}
