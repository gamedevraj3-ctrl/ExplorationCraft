using UnityEngine;

public class DayNightCycleController : MonoInstance<DayNightCycleController>
{
	public int totalTicksPerDay;

	public Color dayColor;

	public Color nightColor;

	public StellarBody sun;

	public StellarBody moon;

	private float lastDayTime;

	private float targetDayTime;

	private const float DAWN_START_RATIO = 0.43f;

	private const float DAWN_DURATION = 7.5f;

	private const int SKY_LIGHT_REDUCE_STEP = 20;

	private const int NIGHT_SKY_LIGHT = 8;

	private int dawnStartTicks;

	private int twilightStartTicks;

	public byte SkyLightReduce { get; private set; }

	private void Update()
	{
	}

	private void LateUpdate()
	{
	}

	public void Initialize(int timeTicks)
	{
	}

	public void SetTime(int timeTicks)
	{
	}

	public void ForceSetTime(int timeTicks)
	{
	}

	private void SetSkyLightReduce(int timeTicks)
	{
	}

	private void SetFogColor(float dayTime)
	{
	}

	private void SetSkyColor(float dayTime)
	{
	}

	public bool IsAtNight()
	{
		return false;
	}

	public bool IsSkyDark()
	{
		return false;
	}

	public int SetToDayTime(int timeTicks)
	{
		return 0;
	}
}
