using System;
using System.Collections.Generic;
using UnityEngine;

public class Biome
{
	public static Biome[] biomeList;

	public static Biome plain;

	public static Biome snow;

	public static Biome desert;

	public static Biome mountain;

	public static Biome taiga;

	public static Biome forest;

	public static Biome jungle;

	public static Biome river;

	public static Biome sandMountain;

	public static Biome snowMountain;

	public static Biome hellDesert;

	public static Biome hellSnow;

	public static Biome corroded;

	public int id;

	public string name;

	public bool isInited;

	protected Color grassColor;

	protected Color grassLandColor;

	protected Color leavesColor;

	protected Color corrodedLeavesColor;

	protected Color brickColor;

	protected Color woodColor;

	protected Color[] woodColors;

	protected List<EntityGroupEntry> spawnAnimalList;

	public int monsterSpawnIndex;

	protected List<EntityGroupEntry> spawnMonsterList;

	protected List<DecorationGenerator> decoratorList;

	public Biome(int id)
	{
	}

	public void SetName(string name)
	{
	}

	public void AddSpawnAnimal(EntityGroupEntry entityGroup)
	{
	}

	public void AddSpawnMonster(EntityGroupEntry entityGroup)
	{
	}

	public void AddOreGenerator(OreGenerator oreGenerator)
	{
	}

	public virtual byte GetSurfaceBlock(int depth, float density, int randomDepth)
	{
		return 0;
	}

	public void Populate(Chunk chunk, System.Random rand)
	{
	}

	public List<EntityGroupEntry> GetSpawnListByType(EntityLivingType type)
	{
		return null;
	}

	public Color GetGrassColor()
	{
		return default;
	}

	public Color GetGrassLandColor()
	{
		return default;
	}

	public Color GetLeavesColor()
	{
		return default;
	}

	public Color GetCorrodedLeavesColor()
	{
		return default;
	}

	public Color GetBrickColor(BlockType type)
	{
		return default;
	}

	public Color GetWoodColor()
	{
		return default;
	}

	public Color GetWoodColor(BlockType type)
	{
		return default;
	}

	public ITreeGenerator GetTreeGenerator()
	{
		return null;
	}
}
