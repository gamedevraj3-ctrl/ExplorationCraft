public class BlockCrop : Block
{
	protected int maxMetaData;

	private int growthProbability;

	private int growthWetProbability;

	public BlockCrop(BlockType type, int maxMetaData, int growthProbability, int growthWetProbability)
		: base(BlockType.Air)
	{
	}

	public BlockCrop(BlockType type, DiggingType material, int maxMetaData, int growthProbability, int growthWetProbability)
		: base(BlockType.Air)
	{
	}

	public override void OnBlockAdd(World world, int worldX, int worldY, int worldZ)
	{
	}

	public override bool NeedUpdate()
	{
		return false;
	}

	public override void UpdateTick(World world, Chunk chunk, int x, int y, int z)
	{
	}

	public override void UpdateTick(World world, Chunk chunk, int x, int y, int z, int passedTicks)
	{
	}

	public override DiggingConvertType ConvertAfterDiggingAround(BlockFromDirection direction, int metaData)
	{
		return DiggingConvertType.None;
	}

	public override bool CanPlaceBlockAt(Block attachBlock, BlockFromDirection direction)
	{
		return false;
	}
}
