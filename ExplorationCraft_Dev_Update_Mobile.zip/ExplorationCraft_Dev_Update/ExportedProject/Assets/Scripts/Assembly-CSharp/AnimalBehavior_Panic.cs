using BehaviorTree;
using UnityEngine;

public class AnimalBehavior_Panic : BevNodeTerminal
{
	private float timeFlag;

	private Vector3 panicSpeed;

	private const float PANIC_DURATION = 0.8f;

	public AnimalBehavior_Panic(BevNode _o_ParentNode)
		: base(null)
	{
	}

	protected override void _DoEnter(object input)
	{
	}

	protected override BevRunningStatus _DoExecute(object input, object output)
	{
		return BevRunningStatus.k_BRS_Executing;
	}

	protected override void _DoExit(object input, BevRunningStatus _ui_ExitID)
	{
	}

	protected override bool _DoEvaluate(object input)
	{
		return false;
	}
}
