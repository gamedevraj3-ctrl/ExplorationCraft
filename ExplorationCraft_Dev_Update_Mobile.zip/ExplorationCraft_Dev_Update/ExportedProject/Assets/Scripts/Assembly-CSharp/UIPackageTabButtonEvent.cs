using UnityEngine;

public class UIPackageTabButtonEvent : MonoBehaviour
{
	public NewUITabHolder uiTabHolder;

	public int tabIndex;

	private void Start()
	{
	}

	private void ButtonClick(GameObject go)
	{
	}
}
