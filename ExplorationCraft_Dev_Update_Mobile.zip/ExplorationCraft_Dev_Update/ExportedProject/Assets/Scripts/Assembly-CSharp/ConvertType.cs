public enum ConvertType
{
	NULL_START = -1,
	Base = 0,
	CraftingTable = 1,
	Furnance = 2,
	NULL_END = 3
}
