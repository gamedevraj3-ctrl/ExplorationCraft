public class BlockShop : Block
{
	public BlockShop(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockShop(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	public override bool OnHit(AABB hitAABB)
	{
		return false;
	}
}
