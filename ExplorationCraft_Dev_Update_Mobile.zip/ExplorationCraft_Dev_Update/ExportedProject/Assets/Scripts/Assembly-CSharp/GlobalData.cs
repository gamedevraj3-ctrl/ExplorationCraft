public class GlobalData
{
	public enum InterludeType
	{
		ToGame = 0,
		ToMainUI = 1
	}

	public enum SensitivityLevel
	{
		Low = 0,
		Medium = 1,
		High = 2
	}

	public static InterludeType interludeType;

	public static int worldID;

	public static int mapSizeLevel;

	public static int seed;

	public static bool isTutorial;

	public static bool autoJump;

	public static bool musicSwitch;

	public static bool soundSwitch;

	public static bool reverseYAxis;

	public static SensitivityLevel sensitivityLevel;

	public static bool showIndicator;

	public static bool showNotification;

	public static bool isSentivitySetted;

	public static bool isOpenedMoreGames;

	public static bool isAdFree;

	public static bool isRateShown;

	public static bool isOnline;

	public static int resetTimes;

	public static MoneyType[] reviveMoneyType;

	public static int[] reviveMoney;

	public static int[] saveSlotMoney;

	public static bool firstTutorial;

	public static int videoCount;

	public static bool firstOpenGame;

	public static DailyBonusController dailyBonusController;

	public static LimitSalesController limitSalesController;

	public static AchievementManager achievementManager;

	public static int coins;

	public static int gems;

	public static bool[] mountUnlockArray;

	public static CompoundDrawing[] drawingArray;

	private static int[] xHash;

	private static int[] zHash;

	public static int GenerateSeed(int x, int z)
	{
		return 0;
	}

	public static void InitialSettings()
	{
	}

	public static void GetVideoReward()
	{
	}
}
