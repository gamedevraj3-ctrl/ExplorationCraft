public class EntityDuck : EntityLiving
{
	protected override void AddExtraBevTreeNode()
	{
	}
}
