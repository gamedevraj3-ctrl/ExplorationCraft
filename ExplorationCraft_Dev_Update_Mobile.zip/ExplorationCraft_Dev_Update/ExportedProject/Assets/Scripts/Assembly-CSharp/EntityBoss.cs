public class EntityBoss : EntityLiving
{
	private int originHealth;

	private float originDamage;

	private float originDefense;

	public bool IsDead => false;

	protected override void AwakeInternal()
	{
	}

	public override void Reset()
	{
	}

	public void ResetByRadio(float healthRadio, float damageRadio, float defenseRadio)
	{
	}

	public override bool IsBoss()
	{
		return false;
	}
}
