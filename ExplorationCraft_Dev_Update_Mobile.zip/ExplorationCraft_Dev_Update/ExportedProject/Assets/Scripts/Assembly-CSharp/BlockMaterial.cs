using UnityEngine;

public class BlockMaterial
{
	public int[] textureIndexs;

	public Rect[] uvs;

	public BlockMaterial(int differentFacesCount)
	{
	}
}
