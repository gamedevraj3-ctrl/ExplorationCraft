public class ItemMaterialController : MonoInstance<ItemMaterialController>
{
	public TextureUVUnion[] itemUVArray;

	public int[] itemUVIndex;

	public ItemTexturePacker texturePacker;

	public void InitializeIndex()
	{
	}
}
