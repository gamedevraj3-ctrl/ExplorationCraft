using System;

public class BigCactusGenerator : DecorationGenerator
{
	private int countPerChunk;

	private int minHeight;

	private int maxHeight;

	private int maxSize;

	private int probabilityPercentage;

	public BigCactusGenerator(int minHeight, int maxHeight, int maxSize, int count, int probabilityPercentage)
	{
	}

	public override void Decorate(Chunk chunk, Random rand)
	{
	}
}
