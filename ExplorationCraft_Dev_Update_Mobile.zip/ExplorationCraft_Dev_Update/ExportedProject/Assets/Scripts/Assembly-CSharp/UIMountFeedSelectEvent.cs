using UnityEngine;

public class UIMountFeedSelectEvent : MonoBehaviour
{
	public NewUITabMount uiMount;

	private NewUIItemPackageEntry itemEntry;

	private void Start()
	{
	}

	private void ButtonClick(GameObject go)
	{
	}
}
