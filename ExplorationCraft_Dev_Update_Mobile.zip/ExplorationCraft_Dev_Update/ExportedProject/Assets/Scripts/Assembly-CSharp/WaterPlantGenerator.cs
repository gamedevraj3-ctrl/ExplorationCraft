using System;

public class WaterPlantGenerator : DecorationGenerator
{
	private int plantBlockID;

	private int countPerChunk;

	private int probabilityPercentage;

	public WaterPlantGenerator(int id, int count, int probabilityPercentage)
	{
	}

	public override void Decorate(Chunk chunk, Random rand)
	{
	}
}
