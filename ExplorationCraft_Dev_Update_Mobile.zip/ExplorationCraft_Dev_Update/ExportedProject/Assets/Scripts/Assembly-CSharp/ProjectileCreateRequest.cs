using UnityEngine;

public class ProjectileCreateRequest
{
	public ProjectileType type;

	public Vector3 position;

	public Quaternion rotation;

	public float speed;

	public float damage;

	public int buffLevel;

	public Entity.CollideLayer targetCollideLayer;

	public Vector3 sourcePos;

	public Vector3i centerAxis;

	public bool checkAxis;

	public ProjectileCreateRequest(ProjectileType type, Vector3 pos, Quaternion rot, float speed, float damage, Entity.CollideLayer targetCollideLayer, Vector3 sourcePos, int buffLevel = 0)
	{
	}

	public ProjectileCreateRequest(ProjectileType type, Vector3 pos, Quaternion rot, float speed, float damage, Entity.CollideLayer targetCollideLayer, Vector3 sourcePos, Vector3i centerAxis, int buffLevel = 0)
	{
	}
}
