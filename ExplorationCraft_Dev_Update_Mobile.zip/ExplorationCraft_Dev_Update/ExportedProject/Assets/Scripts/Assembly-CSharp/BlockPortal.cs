public class BlockPortal : Block
{
	public BlockPortal(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockPortal(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	public override void OnBlockDestroy(World world, int worldX, int worldY, int worldZ)
	{
	}

	public override int GetExtraDropItem(int metaData)
	{
		return 0;
	}
}
