public class KillCounter
{
	public int[] killCount;

	public void AddKillCount(int id)
	{
	}

	public int GetKillCount(int id)
	{
		return 0;
	}
}
