using UnityEngine;

public class EntityVampire : EntityBoss
{
	public float crawlSpeed;

	public Transform magicSpawnPosition;

	public float healthLinePercentage;

	public float magicAttackRadius;

	public float magicHitTime;

	public float magicAttackDuration;

	public float magicCooltime;

	protected override void AddExtraBevTreeNode()
	{
	}

	public override void MoveEntity(float x, float y, float z)
	{
	}
}
