using System;
using UnityEngine;

public class Block
{
	public class BlockProperty
	{
		public bool isOpaqueCube;

		public bool hasColor;

		public float selfLight;

		public float blockHardness;

		public bool canBurn;

		public bool isReplaceable;

		public bool isTranslucent;

		public bool isLiquid;

		public bool isSolid;

		public bool renderAsNormalBlock;

		public bool canRayCheck;

		public bool isCollideWithEntity;

		public bool needSpecifiedTool;

		public bool needUpdateTick;

		public int exp;

		public BlockProperty(int blockId)
		{
		}

		public BlockProperty(int blockId, float blockHardness, bool renderAsNormalBlock, bool canRayCheck, bool isCollideWithEntity, bool isReplaceable, bool needSpecifiedTool, bool canBurn, int exp, bool hasColor)
		{
		}

		public void SetHardness(float hardness)
		{
		}

		public void SetExperience(int experience)
		{
		}
	}

	public const int MAX_COUNT = 256;

	public static Block[] blocks;

	public static Block air;

	public static Block grassland;

	public static Block farmland;

	public static Block dirt;

	public static Block water;

	public static Block leaves;

	public static Block corrodedLeaves;

	public static Block stone;

	public static Block redBrick;

	public static Block greyBrick;

	public static Block solidSnow;

	public static Block wood;

	public static Block sand;

	public static Block snow;

	public static Block cactus;

	public static Block fence;

	public static Block torch;

	public static Block ladder;

	public static Block wheat;

	public static BlockFire fire;

	public static Block grass;

	public static BlockWaterFlow waterFlow;

	public static Block waterStill;

	public static Block glass;

	public static BlockLavaFlow lavaFlow;

	public static BlockLavaStill lavaStill;

	public static Block bedrock;

	public static Block ice;

	public static Block sandStone;

	public static Block flower;

	public static Block mushroom;

	public static Block waterLily;

	public static Block waterLilyPad;

	public static Block vine;

	public static Block craftingTable;

	public static Block furnance;

	public static Block shop;

	public static Block portal;

	public static Block portalSpace;

	public static Block portalBase;

	public static Block portalBoss;

	public static Block magicCrystal;

	public static Block darkIron;

	public static Block gold;

	public static Block amethyst;

	public static Block woodDoorTop;

	public static Block woodDoor;

	public static Block ironDoorTop;

	public static Block ironDoor;

	public static Block fenceGate;

	public static Block woodPlank;

	public static Block bedHead;

	public static Block bedFeet;

	public static Block sapling;

	public static Block chest;

	public static Block oven;

	public static Block airWall;

	public static Block sugarbeet;

	public static Block berryTree;

	public static Block whiteWood;

	public static Block yellowWood;

	public static Block redWood;

	public static Block greenWood;

	public static Block blueWood;

	public static Block purpleWood;

	public static Block blackWood;

	public static Block orangeWood;

	public static Block corrodedDirt;

	public static Block corrodedDirtLight;

	public static Block corrodedDirtSurface;

	public static Block sunflower;

	public static Block rose;

	public static Block clove;

	public static Block carnation;

	public static Block reed;

	public static Block lightFlower;

	public static Block hintPortalBase;

	public static Block hintPortal;

	public static Block hintStone;

	public static readonly Vector3i[] directions;

	public byte blockID;

	public byte materialID;

	public BlockProperty blockProperty;

	private static readonly float[] commonAABBOffset;

	public BlockType type
	{
		get
		{
			return BlockType.Air;
		}
		set
		{
		}
	}

	public DiggingType material
	{
		get
		{
			return DiggingType.Wood;
		}
		set
		{
		}
	}

	public static void InitializeAllBlocks()
	{
	}

	public Block(BlockType type)
	{
	}

	public Block(BlockType type, DiggingType material)
	{
	}

	public static void InitBlockPropertys()
	{
	}

	public virtual bool IsOpaqueCube()
	{
		return false;
	}

	public virtual float GetSelfLight()
	{
		return 0f;
	}

	public virtual float GetBlockHardness()
	{
		return 0f;
	}

	public virtual bool CanBurn()
	{
		return false;
	}

	public virtual bool IsReplaceable()
	{
		return false;
	}

	public virtual bool IsTranslucent()
	{
		return false;
	}

	public virtual bool IsLiquid()
	{
		return false;
	}

	public bool RenderAsNormalBlock()
	{
		return false;
	}

	public virtual bool CanRayCheck()
	{
		return false;
	}

	public virtual bool IsCollideWithEntity()
	{
		return false;
	}

	public virtual int GetExperience()
	{
		return 0;
	}

	public virtual float[] GetAABBOffset(int metaData)
	{
		return null;
	}

	public virtual int GetDropItem(int metaData)
	{
		return 0;
	}

	public virtual int GetDropQuantity(int metaData)
	{
		return 0;
	}

	public virtual int GetExtraDropItem(int metaData)
	{
		return 0;
	}

	public virtual DiggingConvertType ConvertAfterDiggingAround(BlockFromDirection direction, int metaData)
	{
		return DiggingConvertType.None;
	}

	public virtual bool CanPlaceBlockAt(Block attachBlock, BlockFromDirection direction)
	{
		return false;
	}

	public bool IsNormalCube()
	{
		return false;
	}

	public bool IsBlockTopFacingSurfaceSolid()
	{
		return false;
	}

	public bool CanPlaceBlockAt(World world, int worldX, int worldY, int worldZ)
	{
		return false;
	}

	public bool CanBlockStay(World world, int worldX, int worldY, int worldZ)
	{
		return false;
	}

	[Obsolete("To avoid data race, directly get color from biome")]
	public virtual Color ColorMultiplier(Map map, int worldX, int worldY, int worldZ)
	{
		return default;
	}

	public virtual Color ColorMultiplier(Biome biome, BlockType type)
	{
		return default;
	}

	public virtual void GenBlockMesh(MeshGenerator meshGenerator, Map map, int blockX, int blockY, int blockZ, Chunk chunk, int x, int y, int z, byte blockLight)
	{
	}

	public bool CanDigging()
	{
		return false;
	}

	public bool NeedSpecifiedTool()
	{
		return false;
	}

	public virtual bool OnHit(AABB hitAABB)
	{
		return false;
	}

	public virtual bool IsCube()
	{
		return false;
	}

	public virtual bool IsDirectional()
	{
		return false;
	}

	public virtual bool NeedRandomUpdate()
	{
		return false;
	}

	public virtual bool NeedUpdate()
	{
		return false;
	}

	public virtual void UpdateTick(World world, Chunk chunk, int x, int y, int z)
	{
	}

	public virtual void UpdateTick(World world, Chunk chunk, int x, int y, int z, int passedTicks)
	{
	}

	public virtual void OnBlockAdd(World world, int worldX, int worldY, int worldZ)
	{
	}

	public virtual void OnBlockDestroy(World world, int worldX, int worldY, int worldZ)
	{
	}

	public virtual void OnEntityCollidedWithBlock(World world, int worldX, int worldY, int worldZ, Entity entity)
	{
	}

	public virtual bool CanBlockPlacedByPlayer(World world, int worldX, int worldY, int worldZ, int side, int flag)
	{
		return false;
	}

	public virtual void OnEntityWalking(World world, int worldX, int worldY, int worldZ, Entity entity)
	{
	}

	public virtual void OnNeighborBlockChange(World world, int worldX, int worldY, int worldZ, int neightBlockId)
	{
	}

	public virtual void OnSetBlockMetaData(World world, int worldX, int worldY, int worldZ, int metaData)
	{
	}

	public static bool IsNullBlock(Block block)
	{
		return false;
	}

	public static Block GetNullBlock()
	{
		return null;
	}

	public static bool HasFrontFace(BlockType type)
	{
		return false;
	}

	public bool IsSolid22()
	{
		return false;
	}

	public static bool IsSolid(BlockType type)
	{
		return false;
	}

	public bool CanAttachFire()
	{
		return false;
	}

	public bool IsWater()
	{
		return false;
	}

	public bool IsLava()
	{
		return false;
	}

	public bool HasFrontFace()
	{
		return false;
	}

	public bool IsLiquid22()
	{
		return false;
	}

	public bool IsObstacle()
	{
		return false;
	}

	public static bool IsTransparent(BlockType type)
	{
		return false;
	}

	public static bool IsLiquid(BlockType type)
	{
		return false;
	}

	public static bool IsObstacle(BlockType type)
	{
		return false;
	}
}
