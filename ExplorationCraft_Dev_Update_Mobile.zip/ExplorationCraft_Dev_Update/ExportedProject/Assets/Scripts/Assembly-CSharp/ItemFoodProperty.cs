public class ItemFoodProperty : ItemCommonProperty
{
	public bool isEatable;

	public int foodLevelValue;

	public float foodSaturationLevelValue;

	public ItemFoodProperty(ItemType itemType, bool isItemFue)
		: base(ItemType.ToolWeapons, isItemFue: false)
	{
	}

	public ItemFoodProperty(ItemType itemType, bool isItemFue, int fuelEnergy)
		: base(ItemType.ToolWeapons, isItemFue: false)
	{
	}

	public ItemFoodProperty(ItemType itemType, bool isItemFue, int fuelEnergy, int foodLevelValue, float foodSaturationLevelValue)
		: base(ItemType.ToolWeapons, isItemFue: false)
	{
	}

	public ItemFoodProperty(ItemType itemType, bool isItemFue, int foodLevelValue, float foodSaturationLevelValue)
		: base(ItemType.ToolWeapons, isItemFue: false)
	{
	}

	public override ItemCommonProperty SetDescription(ItemDescription description)
	{
		return null;
	}
}
