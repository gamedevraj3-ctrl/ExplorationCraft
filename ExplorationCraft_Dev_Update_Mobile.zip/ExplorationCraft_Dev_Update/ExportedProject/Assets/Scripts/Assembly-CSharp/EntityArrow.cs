using LibNbt.Tags;
using UnityEngine;

public class EntityArrow : EntityProjectile
{
	public int id;

	private bool hasCollected;

	private float gravitySpeedAcculate;

	private Entity entityPlayer;

	private Quaternion finalRot;

	public override void Reset()
	{
	}

	protected new void Update()
	{
	}

	public override void Create(NbtCompound entityCompound)
	{
	}

	public override void Recycle(bool removeFromChunk = false)
	{
	}
}
