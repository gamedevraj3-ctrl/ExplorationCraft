public class EntityTigger : EntityLiving
{
	protected override void AddExtraBevTreeNode()
	{
	}

	protected override void SpawnFavorParticle()
	{
	}
}
