using UnityEngine;

public class UIChestPackageItemSelectEvent : MonoBehaviour
{
	public UIChestPackage uiChestPackage;

	public NewUIItemPackageEntry itemEntry;

	private void Start()
	{
	}

	private void ButtonClick(GameObject go)
	{
	}
}
