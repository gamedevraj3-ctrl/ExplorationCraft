using System;
using System.Collections.Generic;
using UnityEngine;

public class BaseCampGenerator
{
	public List<Chunk> populatedChunks;

	private readonly ShopGenerator shopGenerator;

	private readonly RiverFootholdGenerator riverFootholdGenerator;

	private System.Random random;

	public BaseCampGenerator(Map worldData, int seed)
	{
	}

	public void GenerateBuildings(Vector3 playerPos)
	{
	}
}
