using System.Collections.Generic;
using UnityEngine;

[AddComponentMenu("NGUI/Interaction/Table")]
public class UITable : UIWidgetContainer
{
	public delegate void OnReposition();

	public enum Direction
	{
		Down = 0,
		Up = 1
	}

	public int columns;

	public Direction direction;

	public bool sorted;

	public bool hideInactive;

	public bool keepWithinPanel;

	public Vector2 padding;

	public OnReposition onReposition;

	private UIPanel mPanel;

	private UIScrollView mDrag;

	private bool mInitDone;

	private bool mReposition;

	private List<Transform> mChildren;

	public bool repositionNow
	{
		set
		{
		}
	}

	public List<Transform> children => null;

	public static int SortByName(Transform a, Transform b)
	{
		return 0;
	}

	private void RepositionVariableSize(List<Transform> children)
	{
	}

	[ContextMenu("Execute")]
	public void Reposition()
	{
	}

	private void Start()
	{
	}

	private void Init()
	{
	}

	private void LateUpdate()
	{
	}
}
