using UnityEngine;

public class UISkillButtonEvent : MonoBehaviour
{
	public enum MagicType
	{
		Combat = 0,
		Passive = 1
	}

	public NewUITabSkill uiSkill;

	public MagicType magicType;

	public int routeIndex;

	public int index;

	private void Start()
	{
	}

	private void ButtonClick(GameObject go)
	{
	}
}
