public class BlockPortalSpace : Block
{
	public BlockPortalSpace(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockPortalSpace(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	public override int GetDropItem(int metaData)
	{
		return 0;
	}

	public override void GenBlockMesh(MeshGenerator meshGenerator, Map map, int blockX, int blockY, int blockZ, Chunk chunk, int x, int y, int z, byte blockLight)
	{
	}
}
