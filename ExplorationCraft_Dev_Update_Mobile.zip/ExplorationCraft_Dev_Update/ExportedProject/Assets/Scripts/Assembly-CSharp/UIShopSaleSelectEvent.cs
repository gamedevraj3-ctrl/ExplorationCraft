using UnityEngine;

public class UIShopSaleSelectEvent : MonoBehaviour
{
	public UIShop uiShop;

	public UIShopSaleItemEntry saleEntry;

	private void Start()
	{
	}

	private void ButtonClick(GameObject go)
	{
	}
}
