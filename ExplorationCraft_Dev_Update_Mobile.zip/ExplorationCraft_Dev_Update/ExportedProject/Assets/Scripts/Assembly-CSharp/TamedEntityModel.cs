using BehaviorTree;
using UnityEngine;

public class TamedEntityModel : MonoBehaviour
{
	public MeshRenderer[] bodyRenderer;

	public MeshRenderer saddleRenderer;

	public Material normalMaterial;

	public Material shadowedMaterial;

	public Material normalSaddleMaterial;

	public Material shadowedSaddleMaterial;

	public float speed;

	public Vector2 velocity;

	public bool hasEatAnimation;

	public Vector2 eatTimeInternal;

	public EntityLivingAnimationController animationController;

	public Renderer shadowRenderer;

	private Transform entityTr;

	private bool isUnlocked;

	private BevNode bevRoot;

	private MountBevInputData bevInputData;

	public void SetNormal()
	{
	}

	public void SetShadowed()
	{
	}

	public void Show()
	{
	}

	public void Hide()
	{
	}

	private void Awake()
	{
	}

	private void Start()
	{
	}

	private void Update()
	{
	}
}
