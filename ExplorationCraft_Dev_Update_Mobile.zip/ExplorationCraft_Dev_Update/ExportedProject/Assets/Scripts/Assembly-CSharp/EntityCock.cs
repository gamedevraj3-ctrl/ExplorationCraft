public class EntityCock : EntityLiving
{
	protected override void AddExtraBevTreeNode()
	{
	}

	protected override void SpawnFavorParticle()
	{
	}
}
