using BehaviorTree;

public class AnimalBehavior_MoveToTarget_Box : AnimalBehavior_MoveToTarget
{
	private Regulator moveTimer;

	public AnimalBehavior_MoveToTarget_Box(BevNode _o_ParentNode, Entity _targetEntity)
		: base(null, null)
	{
	}

	protected override void _DoEnter(object input)
	{
	}

	protected override BevRunningStatus _DoExecute(object input, object output)
	{
		return BevRunningStatus.k_BRS_Executing;
	}
}
