public enum ProjectileType
{
	None = -1,
	Arrow = 0,
	Fireball = 1,
	IceLance = 2,
	Arcana = 3,
	Poison = 4,
	Vampire = 5,
	DragonFireBall = 6,
	HagMagic = 7,
	WandMagic = 8,
	Count = 9
}
