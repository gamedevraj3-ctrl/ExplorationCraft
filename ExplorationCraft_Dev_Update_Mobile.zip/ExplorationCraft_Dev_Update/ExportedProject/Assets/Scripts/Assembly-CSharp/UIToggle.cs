using System;
using System.Collections.Generic;
using UnityEngine;

[AddComponentMenu("NGUI/Interaction/Toggle")]
[ExecuteInEditMode]
public class UIToggle : UIWidgetContainer
{
	public static BetterList<UIToggle> list;

	public static UIToggle current;

	public int group;

	public UIWidget activeSprite;

	public Animation activeAnimation;

	public bool startsActive;

	public bool instantTween;

	public bool optionCanBeNone;

	public List<EventDelegate> onChange;

	[SerializeField]
	[HideInInspector]
	private Transform radioButtonRoot;

	[SerializeField]
	[HideInInspector]
	private bool startsChecked;

	[SerializeField]
	[HideInInspector]
	private UISprite checkSprite;

	[SerializeField]
	[HideInInspector]
	private Animation checkAnimation;

	[SerializeField]
	[HideInInspector]
	private GameObject eventReceiver;

	[HideInInspector]
	[SerializeField]
	private string functionName;

	private bool mIsActive;

	private bool mStarted;

	public bool value
	{
		get
		{
			return false;
		}
		set
		{
		}
	}

	[Obsolete("Use 'value' instead")]
	public bool isChecked
	{
		get
		{
			return false;
		}
		set
		{
		}
	}

	public static UIToggle GetActiveToggle(int group)
	{
		return null;
	}

	private void OnEnable()
	{
	}

	private void OnDisable()
	{
	}

	private void Start()
	{
	}

	private void OnClick()
	{
	}

	private void Set(bool state)
	{
	}
}
