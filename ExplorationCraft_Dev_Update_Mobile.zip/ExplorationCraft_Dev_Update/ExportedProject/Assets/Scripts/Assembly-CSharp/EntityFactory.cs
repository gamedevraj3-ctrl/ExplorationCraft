using LibNbt.Tags;

public class EntityFactory : MonoInstance<EntityFactory>
{
	public Entity[] entityList;

	private new void Awake()
	{
	}

	public Entity GetEntityByID(int entityID)
	{
		return null;
	}

	public void Recycle(Entity entity)
	{
	}

	public void CreateEntityFromNbtCompound(NbtCompound entityCompound)
	{
	}
}
