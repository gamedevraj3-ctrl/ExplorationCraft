using UnityEngine;

public class UIEquipArmorSelectEvent : MonoBehaviour
{
	public NewUITabEquip uiTabEquip;

	private NewUIItemPackageEntry itemEntry;

	private void Start()
	{
	}

	private void ButtonClick(GameObject go)
	{
	}
}
