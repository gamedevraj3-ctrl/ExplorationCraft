using BehaviorTree;
using UnityEngine;

public class AnimalBehavior_MoveToTarget : BevNodeTerminal
{
	public Entity targetEntity;

	private float timeFlag;

	protected Vector3 direction;

	public AnimalBehavior_MoveToTarget(BevNode _o_ParentNode, Entity _targetEntity)
		: base(null)
	{
	}

	protected override void _DoEnter(object input)
	{
	}

	protected override BevRunningStatus _DoExecute(object input, object output)
	{
		return BevRunningStatus.k_BRS_Executing;
	}

	protected override bool _DoEvaluate(object input)
	{
		return false;
	}
}
