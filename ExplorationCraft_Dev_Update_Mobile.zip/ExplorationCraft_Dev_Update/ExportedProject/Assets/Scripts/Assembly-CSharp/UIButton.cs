using System.Collections.Generic;
using UnityEngine;

[AddComponentMenu("NGUI/Interaction/Button")]
public class UIButton : UIButtonColor
{
	public static UIButton current;

	public Color disabledColor;

	public bool dragHighlight;

	public List<EventDelegate> onClick;

	public bool isEnabled
	{
		get
		{
			return false;
		}
		set
		{
		}
	}

	protected override void OnEnable()
	{
	}

	protected override void OnHover(bool isOver)
	{
	}

	protected override void OnPress(bool isPressed)
	{
	}

	protected override void OnDragOver()
	{
	}

	protected override void OnDragOut()
	{
	}

	protected override void OnSelect(bool isSelected)
	{
	}

	private void OnClick()
	{
	}

	public void UpdateColor(bool shouldBeEnabled, bool immediate)
	{
	}
}
