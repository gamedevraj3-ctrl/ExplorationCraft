using System;

public class HouseGenerator : DecorationGenerator
{
	private int width;

	private int length;

	private int height;

	private int probabilityPermillage;

	public HouseGenerator(int size, int height, int probability)
	{
	}

	public override void Decorate(Chunk chunk, Random rand)
	{
	}
}
