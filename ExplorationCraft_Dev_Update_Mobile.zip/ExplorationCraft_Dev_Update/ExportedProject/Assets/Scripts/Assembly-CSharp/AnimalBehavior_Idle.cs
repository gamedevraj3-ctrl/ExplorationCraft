using BehaviorTree;
using UnityEngine;

public class AnimalBehavior_Idle : BevNodeTerminal
{
	public enum IdleAnimationType
	{
		Idle = 0,
		Eat = 1
	}

	private Vector2 idleTimeRange;

	private float idleTime;

	private float timeFlag;

	private IdleAnimationType idleAnimationType;

	public AnimalBehavior_Idle(BevNode _o_ParentNode, Vector2 _idleTimeRange, IdleAnimationType idleAnimationType = IdleAnimationType.Idle)
		: base(null)
	{
	}

	protected override void _DoEnter(object input)
	{
	}

	protected override BevRunningStatus _DoExecute(object input, object output)
	{
		return BevRunningStatus.k_BRS_Executing;
	}

	protected override bool _DoEvaluate(object input)
	{
		return false;
	}
}
