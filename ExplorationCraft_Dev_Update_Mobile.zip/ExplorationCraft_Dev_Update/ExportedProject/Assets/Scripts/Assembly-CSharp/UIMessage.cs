using System.Collections.Generic;
using UnityEngine;

public class UIMessage : MonoBehaviour
{
	public enum MessageSize
	{
		Small = 0,
		Medium = 1,
		Large = 2
	}

	public enum MessagePosition
	{
		Center = 0,
		Top = 1,
		Right = 2,
		Left = 3,
		Bottom = 4
	}

	public Vector3[] messagePosition;

	public UITutorialMessageEntry[] tutorialMessageEntryList;

	public UITutorialMessageEntry tutorialMessageEntryWithPic;

	public UIMessageEntry[] messageEntryList;

	public float entryOffset;

	public UIErrorMessage errorMessageEntry;

	public UIErrorMessage bigErrorMessageEntry;

	public UIHintDot[] hintDotList;

	public Transform hintDestination;

	private Queue<MessageUnion> messageQueue;

	private UIMessageEntry bottomEntry;

	private const int TIME_LIMIT = 5;

	private void Awake()
	{
	}

	private void Update()
	{
	}

	public void ShowMessage(string message, bool showHint = false)
	{
	}

	public void ShowErrorMessage(string message)
	{
	}

	public UITutorialMessageEntry ShowMessage(string message, MessageSize size, MessagePosition position)
	{
		return null;
	}

	public UITutorialMessageEntry ShowMessage(string message, string spriteName, MessagePosition position)
	{
		return null;
	}

	public void ShowMessageHint(Vector3 startPos)
	{
	}

	private UIHintDot GetFreeHintDot()
	{
		return null;
	}
}
