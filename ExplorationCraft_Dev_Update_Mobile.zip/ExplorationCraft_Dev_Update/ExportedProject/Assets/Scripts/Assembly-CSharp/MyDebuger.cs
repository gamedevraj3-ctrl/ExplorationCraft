public class MyDebuger
{
	public int lookChunkDistance;

	public int chunkCountLoaded;

	public int chunkCountSaved;

	public int chunkUpdateCount;

	public int allVerticleCount;

	public int allTriangleCount;

	public int blocksMemory;
}
