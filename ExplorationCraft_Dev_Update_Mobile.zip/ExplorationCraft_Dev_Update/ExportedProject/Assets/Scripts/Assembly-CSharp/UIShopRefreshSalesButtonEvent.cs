using UnityEngine;

public class UIShopRefreshSalesButtonEvent : MonoBehaviour
{
	public UIShop uiShop;

	public int price;

	public MoneyType moneyType;

	private void Start()
	{
	}

	private void ButtonClick(GameObject go)
	{
	}

	private void RefreshShopSales()
	{
	}
}
