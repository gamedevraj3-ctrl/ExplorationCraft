public enum ItemMaterial
{
	None = 0,
	Wood = 1,
	Stone = 2,
	DarkIron = 3,
	Golden = 4,
	Amethyst = 5,
	Leather_Armor = 6,
	DarkIron_Armor = 7,
	Golden_Armor = 8,
	Amethyst_Armor = 9
}
