using UnityEngine;

public class ChangeItemMaterial : MonoBehaviour
{
	public Renderer[] childRenderers;

	public Material[] itemMaterials;

	public void SetMaterial(ItemMaterial itemMaterial)
	{
	}

	public void SetMaterial(ItemMaterial itemMaterial, EnchantType enchantType)
	{
	}
}
