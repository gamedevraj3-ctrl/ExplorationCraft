public enum ItemType
{
	NULL_START = -1,
	ToolWeapons = 0,
	Blocks = 1,
	Food = 2,
	Armor = 3,
	Mis = 4,
	NULL_END = 5
}
