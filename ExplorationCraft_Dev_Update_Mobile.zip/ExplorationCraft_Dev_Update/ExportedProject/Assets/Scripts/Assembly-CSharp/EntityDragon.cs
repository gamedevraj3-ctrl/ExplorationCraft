using UnityEngine;

public class EntityDragon : EntityBoss
{
	public Transform magicSpawnPosition;

	protected override void StartInternal()
	{
	}

	protected override void AddExtraBevTreeNode()
	{
	}

	public override void DropItems()
	{
	}

	public override void MoveEntity(float x, float y, float z)
	{
	}
}
