using System;
using UnityEngine;

public class BlockGrass : Block
{
	private const float dropRatio = 0.1f;

	private float[] grassAABBOffset;

	public BlockGrass(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockGrass(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	[Obsolete("To avoid data race, directly get color from biome")]
	public override Color ColorMultiplier(Map map, int worldX, int worldY, int worldZ)
	{
		return default;
	}

	public override Color ColorMultiplier(Biome biome, BlockType type)
	{
		return default;
	}

	public override void GenBlockMesh(MeshGenerator meshGenerator, Map map, int blockX, int blockY, int blockZ, Chunk chunk, int x, int y, int z, byte blockLight)
	{
	}

	public override float[] GetAABBOffset(int metaData)
	{
		return null;
	}

	public override DiggingConvertType ConvertAfterDiggingAround(BlockFromDirection direction, int metaData)
	{
		return DiggingConvertType.None;
	}

	public override bool CanPlaceBlockAt(Block attachBlock, BlockFromDirection direction)
	{
		return false;
	}

	public override int GetDropItem(int metaData)
	{
		return 0;
	}
}
