public class ItemPackage
{
	public const int MAX_ITEM_COUNT = 1024;

	public const int MAX_CAPACITY = 56;

	public const int INIT_CAPACITY = 30;

	public int currentCapacity;

	public const int SHORT_BAR_COUNT = 6;

	public ItemPackageEntry[] itemEntrys;

	public int[] itemCountList;

	public static int[] expandPrice;

	public static MoneyType[] expandMoneyType;

	private const int MAX_OVERLAP_COUNT = 64;

	public ItemPackage()
	{
	}

	public ItemPackage(int capacity)
	{
	}

	public void SetItemEntry(int index, ItemPackageEntry entry, bool resetItemCount = true)
	{
	}

	public int AddItem(int id, int count, int durability = -1)
	{
		return 0;
	}

	public int CheckPackageCapacityForAddItem(int id, int count)
	{
		return 0;
	}

	public void RemoveItem(int id, int count)
	{
	}

	public int RemoveItem(ItemPackageEntry itemEntry, int count)
	{
		return 0;
	}

	public void DropoutAllItems()
	{
	}

	public void SwitchItem(int index1, int index2)
	{
	}

	public ItemPackageEntry GetItemPackageEntry(int index)
	{
		return null;
	}

	public int GetItemCount(int id)
	{
		return 0;
	}

	public bool IsItemEnough(int id, int count)
	{
		return false;
	}

	public void Clear()
	{
	}

	public void SortPackage()
	{
	}

	public void AddItemCount(int itemID, int count)
	{
	}

	public void RemoveItemCount(int itemID, int count)
	{
	}

	public void RemoveAllItemCount()
	{
	}

	public int GetExpandPrice()
	{
		return 0;
	}

	public MoneyType GetExpandMoneyType()
	{
		return MoneyType.Coin;
	}

	public void Expand()
	{
	}
}
