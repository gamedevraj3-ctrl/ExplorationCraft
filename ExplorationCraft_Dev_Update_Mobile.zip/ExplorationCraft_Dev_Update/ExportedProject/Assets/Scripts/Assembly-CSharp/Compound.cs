public class Compound
{
	public int id;

	public int itemTo;

	public int itemToCount;

	public int[] itemFromList;

	public int[] itemNeedCountList;

	public bool needCraftingTable;

	public bool needFurnance;

	public bool needOven;

	public int drawingID;

	public Compound()
	{
	}

	public Compound(int itemTo, int itemToCount, int[] itemFromList, int[] itemNeedCountList, bool needCraftingTable, bool needFurnance, bool needOven, int drawingID)
	{
	}

	public Compound(int itemTo, int itemToCount, int itemFrom, int itemNeed, bool needCraftingTable, bool needFurnance, bool needOven, int drawingID)
	{
	}

	public bool IsDrawingOK()
	{
		return false;
	}

	public void UnlockDrawing()
	{
	}
}
