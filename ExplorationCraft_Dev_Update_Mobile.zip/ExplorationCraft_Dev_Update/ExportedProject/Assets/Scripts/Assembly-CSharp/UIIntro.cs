using System.Collections.Generic;
using UnityEngine;

public class UIIntro : MonoBehaviour
{
	public Vector3[] messagePosition;

	public UISprite rightArrow;

	public UISprite finger;

	public UITutorialMessageEntry messageEntry;

	private List<Tutorial> introList;

	private int currentIndex;

	public bool IsEnabled { get; set; }

	public void Initialize()
	{
	}

	public void StartIntro()
	{
	}

	private void Update()
	{
	}

	public void ShowMessage(string message, UIMessage.MessagePosition position)
	{
	}

	public void HideMessage()
	{
	}
}
