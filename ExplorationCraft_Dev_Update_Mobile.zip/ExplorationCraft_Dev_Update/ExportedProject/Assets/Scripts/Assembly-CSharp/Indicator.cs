using UnityEngine;

public class Indicator : MonoBehaviour
{
	public bool isActived;

	public Vector2 showPosition;

	public Vector2 position;

	public Vector2i centerAxis;

	private float timeFlag;

	private bool autoDestruct;

	private const float DELAY = 2f;

	public void SetPosition(Vector2 position, Vector2i centerAxis)
	{
	}

	public void ResetPosition()
	{
	}

	private void Update()
	{
	}

	public void Show(bool autoDestruct)
	{
	}

	public void Hide()
	{
	}
}
