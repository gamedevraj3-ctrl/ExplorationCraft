using UnityEngine;

public class UIPackageButtonEvent : MonoBehaviour
{
	public NewUIPlaying uiPlaying;

	private void Start()
	{
	}

	private void ButtonClick(GameObject gameObject)
	{
	}
}
