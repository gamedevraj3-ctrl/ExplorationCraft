using System;
using UnityEngine;

[Serializable]
public class PrefabListFacade
{
	public GameObject[] prefabs;

	public string[] prefabNames;

	public bool isInstanceByName;

	private GameObject[] loadedPrefabs;

	public GameObject Instantiate(int index)
	{
		return null;
	}
}
