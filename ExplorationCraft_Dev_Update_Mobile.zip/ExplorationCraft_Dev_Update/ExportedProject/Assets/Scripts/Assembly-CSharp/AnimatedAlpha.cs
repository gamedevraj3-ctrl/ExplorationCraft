using UnityEngine;

public class AnimatedAlpha : MonoBehaviour
{
	public float alpha;

	private UIWidget mWidget;

	private UIPanel mPanel;

	private void Awake()
	{
	}

	private void Update()
	{
	}
}
