using System.Collections.Generic;
using UnityEngine;

public class ItemMeshGenerator
{
	public enum PlaneType
	{
		Small = 0,
		Normal = 1
	}

	private List<int> blockIndices;

	private List<Vector3> blockVertices;

	private List<Vector2> blockUVs;

	private List<Color32> blockColors;

	private int blockGenIndex;

	private Vector3[] blockPosList;

	private Vector3[] planePosList;

	private Vector3[] smallPlanePosList;

	public void GenBlockMesh(BlockType blockType, MeshFilter meshFilter)
	{
	}

	private void GenFace(Vector3 pos1, Vector3 pos2, Vector3 pos3, Vector3 pos4, BlockType blockType, BlockFace blockFace)
	{
	}

	public void GenPlaneMesh(int itemID, MeshFilter meshFilter, PlaneType planeType)
	{
	}

	public void GenFace(Vector3 pos1, Vector3 pos2, Vector3 pos3, Vector3 pos4, int itemID)
	{
	}
}
