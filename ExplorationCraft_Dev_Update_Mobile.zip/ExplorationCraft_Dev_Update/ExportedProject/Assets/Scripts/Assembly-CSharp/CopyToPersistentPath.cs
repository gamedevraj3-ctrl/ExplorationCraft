using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Cuizhe;

public class CopyToPersistentPath
{
	[CompilerGenerated]
	private sealed class _003CLoadFiles_003Ed__13 : IEnumerator<object>, IEnumerator, IDisposable
	{
		private int _003C_003E1__state;

		private object _003C_003E2__current;

		private int _003Ci_003E5__2;

		object IEnumerator<object>.Current
		{
			[DebuggerHidden]
			get
			{
				return null;
			}
		}

		object IEnumerator.Current
		{
			[DebuggerHidden]
			get
			{
				return null;
			}
		}

		[DebuggerHidden]
		public _003CLoadFiles_003Ed__13(int _003C_003E1__state)
		{
		}

		[DebuggerHidden]
		void IDisposable.Dispose()
		{
		}

		private bool MoveNext()
		{
			return false;
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			return this.MoveNext();
		}

		[DebuggerHidden]
		void IEnumerator.Reset()
		{
		}
	}

	private static string currVersion;

	private static string streamPath;

	private static string toPath;

	private static readonly string FileListName;

	private static DateTime unpackBeginTime;

	private static DateTime unpackEndTime;

	private static Action _action;

	private static string[] relativePaths;

	private static IEnumerator loadFileCoroutine;

	private static string currRelativePath;

	public static bool NeedCopyResources()
	{
		return false;
	}

	public static void CopyResources(Action action)
	{
	}

	private static void LoadFiles(FileUtil.WWWFileInfo fileInfo)
	{
	}

	[IteratorStateMachine(typeof(_003CLoadFiles_003Ed__13))]
	private static IEnumerator LoadFiles()
	{
		return null;
	}

	private static void OnFileLoadOver(FileUtil.WWWFileInfo fileInfo)
	{
	}
}
