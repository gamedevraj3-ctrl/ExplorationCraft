using System;
using System.Collections.Generic;
using UnityEngine;

[AddComponentMenu("NGUI/UI/Font")]
[ExecuteInEditMode]
public class UIFont : MonoBehaviour
{
	[SerializeField]
	[HideInInspector]
	private Material mMat;

	[HideInInspector]
	[SerializeField]
	private Rect mUVRect;

	[SerializeField]
	[HideInInspector]
	private BMFont mFont;

	[HideInInspector]
	[SerializeField]
	private UIAtlas mAtlas;

	[SerializeField]
	[HideInInspector]
	private UIFont mReplacement;

	[SerializeField]
	[HideInInspector]
	private float mPixelSize;

	[SerializeField]
	[HideInInspector]
	private List<BMSymbol> mSymbols;

	[HideInInspector]
	[SerializeField]
	private Font mDynamicFont;

	[SerializeField]
	[HideInInspector]
	private int mDynamicFontSize;

	[SerializeField]
	[HideInInspector]
	private FontStyle mDynamicFontStyle;

	private UISpriteData mSprite;

	private int mPMA;

	private bool mSpriteSet;

	public BMFont bmFont => null;

	public int texWidth => 0;

	public int texHeight => 0;

	public bool hasSymbols => false;

	public List<BMSymbol> symbols => null;

	public UIAtlas atlas
	{
		get
		{
			return null;
		}
		set
		{
		}
	}

	public Material material
	{
		get
		{
			return null;
		}
		set
		{
		}
	}

	public float pixelSize
	{
		get
		{
			return 0f;
		}
		set
		{
		}
	}

	public bool premultipliedAlpha => false;

	public Texture2D texture => null;

	public Rect uvRect
	{
		get
		{
			return default;
		}
		set
		{
		}
	}

	public string spriteName
	{
		get
		{
			return null;
		}
		set
		{
		}
	}

	public bool isValid => false;

	[Obsolete("Use UIFont.defaultSize instead")]
	public int size
	{
		get
		{
			return 0;
		}
		set
		{
		}
	}

	public int defaultSize
	{
		get
		{
			return 0;
		}
		set
		{
		}
	}

	public UISpriteData sprite => null;

	public UIFont replacement
	{
		get
		{
			return null;
		}
		set
		{
		}
	}

	public bool isDynamic => false;

	public Font dynamicFont
	{
		get
		{
			return null;
		}
		set
		{
		}
	}

	public FontStyle dynamicFontStyle
	{
		get
		{
			return FontStyle.Normal;
		}
		set
		{
		}
	}

	private Texture dynamicTexture => null;

	private void Trim()
	{
	}

	private bool References(UIFont font)
	{
		return false;
	}

	public static bool CheckIfRelated(UIFont a, UIFont b)
	{
		return false;
	}

	public void MarkAsChanged()
	{
	}

	private BMSymbol GetSymbol(string sequence, bool createIfMissing)
	{
		return null;
	}

	public BMSymbol MatchSymbol(string text, int offset, int textLength)
	{
		return null;
	}

	public void AddSymbol(string sequence, string spriteName)
	{
	}

	public void RemoveSymbol(string sequence)
	{
	}

	public void RenameSymbol(string before, string after)
	{
	}

	public bool UsesSprite(string s)
	{
		return false;
	}
}
