public class AchievementFileReader
{
	private const string ACHIEVEMENT_FILE_NAME = "Achievement";

	public static bool SetAchievementAttribute()
	{
		return false;
	}
}
