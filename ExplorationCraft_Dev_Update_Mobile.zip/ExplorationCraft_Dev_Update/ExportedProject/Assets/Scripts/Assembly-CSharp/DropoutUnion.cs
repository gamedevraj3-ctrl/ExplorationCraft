using System;

[Serializable]
public class DropoutUnion
{
	public int id;

	public int probabilityPercentage;

	public DropoutUnion(int id, int probabilityPercentage)
	{
	}
}
