public class RiverFootholdGenerator : IBaseCampGenerator
{
	private readonly Map map;

	public RiverFootholdGenerator(Map worldData)
	{
	}

	public Chunk GenerateBuilding(int blockX, int blockY, int blockZ, int metaData)
	{
		return null;
	}
}
