using System.Collections.Generic;
using LZ4Sharp;

public class ChunkProvider : MonoInstance<ChunkProvider>
{
	private const int BUFFER_SIZE = 4096;

	private const int REGION_SIZE_X = 32;

	private const int REGION_SIZE_Z = 32;

	private const int REGION_SIZE_SHIFT_X = 5;

	private const int REGION_SIZE_SHIFT_Z = 5;

	private const int REGION_BITS_X = 4;

	private const int REGION_BITS_Y = 8;

	private string regionFilePathRoot;

	private ILZ4Compressor compressor;

	private new void Awake()
	{
	}

	private string GetRegionFileName(int chunkX, int chunkZ)
	{
		return null;
	}

	public bool IsChunkExist(int chunkX, int chunkZ)
	{
		return false;
	}

	private void SaveGroupedChunks(List<Chunk> chunks, bool needRecycle = true)
	{
	}

	private bool IsChunkGroupKeyEqual(Chunk chunk1, Chunk chunk2)
	{
		return false;
	}

	private List<List<Chunk>> GroupChunks(List<Chunk> chunks)
	{
		return null;
	}

	public void SaveChunks(List<Chunk> chunks, bool needRecycle = true)
	{
	}

	public void SaveChunk(Chunk chunk, bool needRecycle = true)
	{
	}

	private void SaveChunkToFile(Chunk chunk, RegionFile regionFile, byte[] blockTypeData, byte[] blockMetaData, byte[] blockHeightData, byte[] blockBiomeData, byte[] buffer, bool needRecycle = true)
	{
	}

	private void LoadGroupedChunks(List<Chunk> chunks)
	{
	}

	public void LoadChunks(List<Chunk> chunks)
	{
	}

	public bool LoadChunk(Chunk chunk, int chunkX, int chunkZ)
	{
		return false;
	}

	private void LoadChunkFromFile(Chunk chunk, RegionFile regionFile, int chunkX, int chunkZ)
	{
	}

	public bool IsChunkSaved(int chunkX, int chunkZ)
	{
		return false;
	}
}
