public enum DamageType
{
	Entity = 1,
	Fall = 2,
	Hunger = 4,
	Drown = 8,
	Cactus = 0x10,
	Burning = 0x20,
	Frozen = 0x40
}
