public class UIRate : NewUIBase
{
	public TweenScale scaleTweener;

	public override void Show()
	{
	}

	public void HandleRateEvent()
	{
	}
}
