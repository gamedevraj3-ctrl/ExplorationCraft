using UnityEngine;

public class UIAlwaysRotate : MonoBehaviour
{
	public float rotateSpeed;

	private void Update()
	{
	}
}
