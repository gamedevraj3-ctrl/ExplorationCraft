using BehaviorTree;
using UnityEngine;

public class AnimalBehavior_Wander_Box : AnimalBehavior_Wander
{
	private Regulator moveTimer;

	public AnimalBehavior_Wander_Box(BevNode _o_ParentNode, Vector2 _wanderTimeRange)
		: base(null, default)
	{
	}

	protected override void _DoEnter(object input)
	{
	}

	protected override BevRunningStatus _DoExecute(object input, object output)
	{
		return BevRunningStatus.k_BRS_Executing;
	}
}
