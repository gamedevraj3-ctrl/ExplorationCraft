public interface IBaseCampGenerator
{
	Chunk GenerateBuilding(int blockX, int blockY, int blockZ, int metaData);
}
