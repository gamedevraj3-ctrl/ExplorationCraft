public class AchievementManager
{
	public Achievement[] achievementArray;

	public int[] craftItemAmountArray;

	public int[] breakedBlockAmountArray;

	public int[] killAmountArray;

	public AchievementManager(int count)
	{
	}

	public void AddKillCount(int id, int count = 1)
	{
	}

	public int GetKillCount(int id)
	{
		return 0;
	}

	public void AddCraftItemCount(int id, int count = 1)
	{
	}

	public int GetCraftItemCount(int id)
	{
		return 0;
	}

	public void AddBreakedBlockCount(int id, int count = 1)
	{
	}

	public int GetBreakedBlockCount(int id)
	{
		return 0;
	}

	public bool HasUnchecked()
	{
		return false;
	}
}
