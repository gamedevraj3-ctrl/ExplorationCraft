public enum FlyType
{
	Fly = 0,
	Glide = 1
}
