using System.Collections.Generic;

public class UITutorialSelect : NewUIBase
{
	public List<UISelectTutorialEntry> uiTutorialEntrys;

	public UIScrollView tutorialListView;

	public override void Show()
	{
	}

	public override void Hide()
	{
	}

	public void SelectWorld(UISelectTutorialEntry entry)
	{
	}

	public void EnterTutorial(int index)
	{
	}
}
