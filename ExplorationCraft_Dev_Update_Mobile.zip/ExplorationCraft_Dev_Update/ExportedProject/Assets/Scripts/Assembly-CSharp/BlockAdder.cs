using UnityEngine;

public class BlockAdder
{
	private Map map;

	private World world;

	private BlockType addBlockType;

	private static Vector3i[] blockAdjacentOffset;

	private static int[] blockAdjacentMetaData;

	private static int[] blockVineAdjacentMetaData;

	public BlockAdder(World _world, Map _map)
	{
	}

	public void ChangeCurrentBlockType(BlockType type)
	{
	}

	public bool AddBlockAt(Vector3 rayHitPos)
	{
		return false;
	}
}
