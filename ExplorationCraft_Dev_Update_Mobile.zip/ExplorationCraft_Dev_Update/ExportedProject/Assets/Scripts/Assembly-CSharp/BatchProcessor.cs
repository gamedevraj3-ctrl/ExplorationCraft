using System;
using System.Collections.Generic;

public class BatchProcessor<T> : IBatchProcessor<T> where T : class
{
	public void Process(List<T> itemsToProcess, Action<T> action, bool waitUntilAllThreadsFinish)
	{
	}

	public void Process(int numberOfThreads, List<T> itemsToProcess, Action<T> action, bool waitUntilAllThreadsFinish)
	{
	}

	private static void ActionAgainstMultiple(IList<T> items, int startIndex, int length, Action<T> action)
	{
	}
}
