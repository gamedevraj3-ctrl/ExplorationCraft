public enum AnimalType
{
	NULL_START = -1,
	alpaca = 0,
	tiger = 1,
	hag = 2,
	mummy = 3,
	duck = 4,
	wolf = 5,
	horse = 6,
	snowman = 7,
	cow = 8,
	pig = 9,
	spider = 10,
	vampire = 11,
	werewolf = 12,
	dragon = 13,
	cock = 14,
	hen = 15,
	skeleton = 16,
	pumpkin = 17,
	unicorn = 18,
	NULL_END = 19
}
