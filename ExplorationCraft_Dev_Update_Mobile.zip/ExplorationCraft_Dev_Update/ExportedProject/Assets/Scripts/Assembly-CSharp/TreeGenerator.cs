using System;

public class TreeGenerator : DecorationGenerator, ITreeGenerator
{
	private int size;

	private int minHeight;

	private int maxHeight;

	private int countPerChunk;

	private int probabilityPercentage;

	public TreeGenerator(int minHeight, int maxHeight, int count, int probabilityPercentage)
	{
	}

	public override void Decorate(Chunk chunk, Random rand)
	{
	}

	public bool Generate(int worldX, int worldY, int worldZ)
	{
		return false;
	}

	private bool CheckValidity(int x, int y, int z, int height)
	{
		return false;
	}

	private void GenerateTree(int x, int y, int z, int height, Random rand, bool updateHeight = false)
	{
	}

	private void PalmTree(int centerX, int centerY, int centerZ, Random rand, bool updateHeight)
	{
	}

	private void SmallTree(int centerX, int centerY, int centerZ, Random rand, bool updateHeight)
	{
	}

	private void OsmanthusTree(int centerX, int centerY, int centerZ, Random rand, bool updateHeight)
	{
	}

	private void DracaenaTree(int centerX, int centerY, int centerZ, Random rand, bool updateHeight)
	{
	}
}
