namespace BehaviorTree
{
	public class BevNodePreconditionTRUE : BevNodePrecondition
	{
		public bool ExternalCondition(object input)
		{
			return false;
		}
	}
}
