namespace BehaviorTree
{
	public class BevNodeNonePrioritySelector : BevNodePrioritySelector
	{
		public BevNodeNonePrioritySelector(BevNode _o_ParentNode, BevNodePrecondition _o_NodePrecondition)
			: base(null)
		{
		}

		protected override bool _DoEvaluate(object input)
		{
			return false;
		}
	}
}
