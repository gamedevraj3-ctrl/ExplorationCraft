namespace BehaviorTree
{
	public class BevNodePreconditionXOR : BevNodePrecondition
	{
		private BevNodePrecondition m_lhs;

		private BevNodePrecondition m_rhs;

		public BevNodePreconditionXOR(BevNodePrecondition lhs, BevNodePrecondition rhs)
		{
		}

		public bool ExternalCondition(object input)
		{
			return false;
		}
	}
}
