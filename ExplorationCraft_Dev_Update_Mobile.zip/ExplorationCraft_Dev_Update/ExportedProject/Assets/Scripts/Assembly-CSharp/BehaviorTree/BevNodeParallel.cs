namespace BehaviorTree
{
	public class BevNodeParallel : BevNode
	{
		private E_ParallelFinishCondition me_FinishCondition;

		private BevRunningStatus[] mab_ChildNodeStatus;

		public BevNodeParallel(BevNode _o_ParentNode)
			: base(null)
		{
		}

		public BevNodeParallel(BevNode _o_ParentNode, BevNodePrecondition _o_NodePrecondition)
			: base(null)
		{
		}

		public void SetFinishCondition(E_ParallelFinishCondition _e_Condition)
		{
		}

		protected override bool _DoEvaluate(object input)
		{
			return false;
		}

		protected override void _DoTransition(object input)
		{
		}

		protected override BevRunningStatus _DoTick(object input, object output)
		{
			return BevRunningStatus.k_BRS_Executing;
		}
	}
}
