namespace BehaviorTree
{
	public class BevNodeWeightedRandomSelector : BevNode
	{
		protected int mui_CurrentNodeIndex;

		protected float[] weightList;

		public BevNodeWeightedRandomSelector(BevNode _o_ParentNode)
			: base(null)
		{
		}

		public BevNodeWeightedRandomSelector(BevNode _o_ParentNode, BevNodePrecondition _o_NodePrecondition)
			: base(null)
		{
		}

		public BevNodeWeightedRandomSelector AddChildNode(BevNode _o_ChildNode, float weight)
		{
			return null;
		}

		protected override bool _DoEvaluate(object input)
		{
			return false;
		}

		protected override void _DoTransition(object input)
		{
		}

		protected override BevRunningStatus _DoTick(object input, object output)
		{
			return BevRunningStatus.k_BRS_Executing;
		}
	}
}
