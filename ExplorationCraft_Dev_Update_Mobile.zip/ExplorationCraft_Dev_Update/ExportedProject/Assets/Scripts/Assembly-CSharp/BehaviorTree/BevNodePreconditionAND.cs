namespace BehaviorTree
{
	public class BevNodePreconditionAND : BevNodePrecondition
	{
		private BevNodePrecondition m_lhs;

		private BevNodePrecondition m_rhs;

		public BevNodePreconditionAND(BevNodePrecondition lhs, BevNodePrecondition rhs)
		{
		}

		public bool ExternalCondition(object input)
		{
			return false;
		}
	}
}
