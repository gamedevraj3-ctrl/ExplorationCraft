namespace BehaviorTree
{
	public class BevNodePreconditionFALSE : BevNodePrecondition
	{
		public bool ExternalCondition(object input)
		{
			return false;
		}
	}
}
