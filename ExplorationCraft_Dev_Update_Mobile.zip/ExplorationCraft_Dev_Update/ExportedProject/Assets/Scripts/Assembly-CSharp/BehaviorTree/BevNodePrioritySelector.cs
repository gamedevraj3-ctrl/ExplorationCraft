namespace BehaviorTree
{
	public class BevNodePrioritySelector : BevNode
	{
		protected int mui_CurrentSelectIndex;

		protected int mui_LastSelectIndex;

		public BevNodePrioritySelector(BevNode _o_ParentNode)
			: base(null)
		{
		}

		public BevNodePrioritySelector(BevNode _o_ParentNode, BevNodePrecondition _o_NodePrecondition)
			: base(null)
		{
		}

		protected override bool _DoEvaluate(object input)
		{
			return false;
		}

		protected override void _DoTransition(object input)
		{
		}

		protected override BevRunningStatus _DoTick(object input, object output)
		{
			return BevRunningStatus.k_BRS_Executing;
		}
	}
}
