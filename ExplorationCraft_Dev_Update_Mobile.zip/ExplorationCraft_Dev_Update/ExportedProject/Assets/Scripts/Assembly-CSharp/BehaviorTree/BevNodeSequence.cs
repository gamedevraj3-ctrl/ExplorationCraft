namespace BehaviorTree
{
	public class BevNodeSequence : BevNode
	{
		private int mui_CurrentNodeIndex;

		public BevNodeSequence(BevNode _o_ParentNode)
			: base(null)
		{
		}

		public BevNodeSequence(BevNode _o_ParentNode, BevNodePrecondition _o_NodePrecondition)
			: base(null)
		{
		}

		protected override bool _DoEvaluate(object input)
		{
			return false;
		}

		protected override void _DoTransition(object input)
		{
		}

		protected override BevRunningStatus _DoTick(object input, object output)
		{
			return BevRunningStatus.k_BRS_Executing;
		}
	}
}
