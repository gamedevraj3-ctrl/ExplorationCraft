namespace BehaviorTree
{
	public class BevNodeLoopSelector : BevNode
	{
		public const int kInfiniteLoop = -1;

		private bool mb_IgnoreChildPrecondition;

		private int mi_LoopCount;

		private int mi_CurrentCount;

		public BevNodeLoopSelector(BevNode _o_ParentNode, int _i_LoopCnt = -1, bool _b_IgnoreChildPrecondition = false)
			: base(null)
		{
		}

		public BevNodeLoopSelector(BevNode _o_ParentNode, BevNodePrecondition _o_NodePrecondition, int _i_LoopCnt, bool _b_IgnoreChildPrecondition)
			: base(null)
		{
		}

		protected override bool _DoEvaluate(object input)
		{
			return false;
		}

		protected override void _DoTransition(object input)
		{
		}

		protected override BevRunningStatus _DoTick(object input, object output)
		{
			return BevRunningStatus.k_BRS_Executing;
		}
	}
}
