namespace BehaviorTree
{
	public enum E_TerminalNodeStatus
	{
		k_TNS_Ready = 1,
		k_TNS_Running = 2,
		k_TNS_Finish = 3
	}
}
