namespace BehaviorTree
{
	public class BevNodeTerminal : BevNode
	{
		private E_TerminalNodeStatus me_Status;

		private bool mb_NeedExit;

		public BevNodeTerminal(BevNode _o_ParentNode)
			: base(null)
		{
		}

		public BevNodeTerminal(BevNode _o_ParentNode, BevNodePrecondition _o_NodePrecondition)
			: base(null)
		{
		}

		protected virtual void _DoEnter(object input)
		{
		}

		protected virtual BevRunningStatus _DoExecute(object input, object output)
		{
			return BevRunningStatus.k_BRS_Executing;
		}

		protected virtual void _DoExit(object input, BevRunningStatus _ui_ExitID)
		{
		}

		protected override void _DoTransition(object input)
		{
		}

		protected override BevRunningStatus _DoTick(object input, object output)
		{
			return BevRunningStatus.k_BRS_Executing;
		}
	}
}
