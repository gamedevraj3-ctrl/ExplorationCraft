namespace BehaviorTree
{
	public class BevNodePreconditionNOT : BevNodePrecondition
	{
		private BevNodePrecondition m_lhs;

		public BevNodePreconditionNOT(BevNodePrecondition lhs)
		{
		}

		public bool ExternalCondition(object input)
		{
			return false;
		}
	}
}
