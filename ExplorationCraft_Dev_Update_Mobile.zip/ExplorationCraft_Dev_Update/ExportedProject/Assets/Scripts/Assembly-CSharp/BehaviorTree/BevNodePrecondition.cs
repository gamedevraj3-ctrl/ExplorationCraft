namespace BehaviorTree
{
	public interface BevNodePrecondition
	{
		bool ExternalCondition(object input);
	}
}
