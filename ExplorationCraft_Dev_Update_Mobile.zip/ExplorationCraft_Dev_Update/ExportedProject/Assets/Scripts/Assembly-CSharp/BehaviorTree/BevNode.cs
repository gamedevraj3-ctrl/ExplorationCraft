namespace BehaviorTree
{
	public class BevNode
	{
		public const int k_BLimited_MaxChildNodeCnt = 16;

		public const int k_BLimited_InvalidChildNodeIndex = 16;

		protected BevNode[] mao_ChildNodeList;

		protected int mul_ChildNodeCount;

		protected BevNode mo_ParentNode;

		protected BevNode mo_ActiveNode;

		protected BevNode mo_LastActiveNode;

		protected BevNodePrecondition mo_NodePrecondition;

		protected string mz_DebugName;

		public BevNode(BevNode _o_ParentNode)
		{
		}

		public BevNode(BevNode _o_ParentNode, BevNodePrecondition _o_NodeScript)
		{
		}

		protected virtual bool _DoEvaluate(object input)
		{
			return false;
		}

		protected virtual void _DoTransition(object input)
		{
		}

		protected virtual BevRunningStatus _DoTick(object input, object output)
		{
			return BevRunningStatus.k_BRS_Executing;
		}

		protected void _SetParentNode(BevNode _o_ParentNode)
		{
		}

		protected bool _bCheckIndex(int _ui_Index)
		{
			return false;
		}

		public string GetDebugName()
		{
			return null;
		}

		public BevNode SetDebugName(string _debugName)
		{
			return null;
		}

		public void SetActiveNode(BevNode _o_Node)
		{
		}

		public BevNode GetLastActiveNode()
		{
			return null;
		}

		public BevNode SetNodePrecondition(BevNodePrecondition _o_NodePrecondition)
		{
			return null;
		}

		public BevNode AddChildNode(BevNode _o_ChildNode)
		{
			return null;
		}

		public BevRunningStatus Tick(object input, object output)
		{
			return BevRunningStatus.k_BRS_Executing;
		}

		public bool Evaluate(object input)
		{
			return false;
		}

		public void Transition(object input)
		{
		}
	}
}
