namespace BehaviorTree
{
	public enum E_ParallelFinishCondition
	{
		k_PFC_OR = 1,
		k_PFC_AND = 2
	}
}
