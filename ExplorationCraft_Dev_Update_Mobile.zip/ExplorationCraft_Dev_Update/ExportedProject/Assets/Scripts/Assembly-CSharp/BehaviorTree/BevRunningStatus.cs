namespace BehaviorTree
{
	public enum BevRunningStatus
	{
		k_BRS_Executing = 0,
		k_BRS_Finish = 1,
		k_BRS_ERROR_Transition = -1
	}
}
