namespace BehaviorTree
{
	public class BevNodePreconditionOR : BevNodePrecondition
	{
		private BevNodePrecondition m_lhs;

		private BevNodePrecondition m_rhs;

		public BevNodePreconditionOR(BevNodePrecondition lhs, BevNodePrecondition rhs)
		{
		}

		public bool ExternalCondition(object input)
		{
			return false;
		}
	}
}
