public class AABBPool
{
	private int maxSize;

	private int nextPoolIndex;

	private AABB[] aabbArray;

	public AABBPool(int size)
	{
	}

	public AABB GetAABB(float minX, float minY, float minZ, float maxX, float maxY, float maxZ)
	{
		return null;
	}
}
