public enum PlayerAction
{
	Move = 0,
	Swing = 1,
	Jump = 2,
	Dig = 3,
	Attack = 4,
	MagicAttack = 5,
	Hurt = 6,
	Recovery = 7
}
