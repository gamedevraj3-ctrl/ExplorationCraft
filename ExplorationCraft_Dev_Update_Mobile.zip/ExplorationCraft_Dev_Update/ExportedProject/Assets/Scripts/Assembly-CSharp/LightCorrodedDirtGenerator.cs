using System;
using System.Collections.Generic;

public class LightCorrodedDirtGenerator : DecorationGenerator
{
	private int countPerChunk;

	private int probabilityPercentage;

	private bool[] noiseShape;

	private Queue<int> shapeQueue;

	private const int SHAPE_SIZE = 8;

	private const float MAX_PROBABILITY = 44f;

	private const float MIN_PROBABILITY = 10f;

	private float k;

	public LightCorrodedDirtGenerator(int count, int probability)
	{
	}

	public override void Decorate(Chunk chunk, Random rand)
	{
	}

	private void Reshape(Random rand)
	{
	}

	private float GetGrowthProbability(int lx, int lz)
	{
		return 0f;
	}
}
