using UnityEngine;

[ExecuteInEditMode]
[AddComponentMenu("NGUI/Interaction/Button Color")]
public class UIButtonColor : UIWidgetContainer
{
	public GameObject tweenTarget;

	public Color hover;

	public Color pressed;

	public float duration;

	protected Color mColor;

	protected bool mStarted;

	protected UIWidget mWidget;

	public Color defaultColor
	{
		get
		{
			return default;
		}
		set
		{
		}
	}

	private void Start()
	{
	}

	protected virtual void OnEnable()
	{
	}

	protected virtual void OnDisable()
	{
	}

	protected void Init()
	{
	}

	protected virtual void OnPress(bool isPressed)
	{
	}

	protected virtual void OnHover(bool isOver)
	{
	}

	protected virtual void OnDragOver()
	{
	}

	protected virtual void OnDragOut()
	{
	}

	protected virtual void OnSelect(bool isSelected)
	{
	}
}
