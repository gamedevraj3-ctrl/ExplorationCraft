public class BlockChest : Block
{
	public BlockChest(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockChest(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	public override bool OnHit(AABB hitAABB)
	{
		return false;
	}

	public override void OnBlockAdd(World world, int worldX, int worldY, int worldZ)
	{
	}

	public override void OnBlockDestroy(World world, int worldX, int worldY, int worldZ)
	{
	}
}
