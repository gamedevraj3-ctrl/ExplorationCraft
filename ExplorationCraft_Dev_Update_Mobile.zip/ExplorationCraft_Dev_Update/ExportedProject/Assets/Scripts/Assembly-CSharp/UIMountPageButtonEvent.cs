using UnityEngine;

public class UIMountPageButtonEvent : MonoBehaviour
{
	public NewUITabMount uiMount;

	public int index;

	public UISprite icon;

	public UISprite imgCheck;

	public string lockSpriteName;

	public string normalSpriteaName;

	private void Start()
	{
	}

	private void ButtonClick(GameObject go)
	{
	}

	public void SetUnlock()
	{
	}

	public void SetLock()
	{
	}

	public void SetSelected()
	{
	}

	public void SetUnselected()
	{
	}

	public void SetChecked()
	{
	}

	public void SetUnchecked()
	{
	}
}
