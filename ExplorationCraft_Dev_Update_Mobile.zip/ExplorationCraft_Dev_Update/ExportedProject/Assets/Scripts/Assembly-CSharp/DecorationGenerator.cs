using System;

public class DecorationGenerator
{
	public virtual void Decorate(Chunk chunk, Random rand)
	{
	}
}
