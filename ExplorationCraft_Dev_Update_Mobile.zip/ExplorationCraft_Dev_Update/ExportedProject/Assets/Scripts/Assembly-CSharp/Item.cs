public class Item
{
	public const int ITEM_TYPE_COUNT = 5;

	public int id;

	public bool canOverlap;

	public int price;

	public static ItemCommonProperty[] itemPropertyList;

	public static Item[] itemList;

	public static Item waterBucket;

	public static Item emptyBucket;

	public static Item woodStick;

	public static Item woodSword;

	public static Item woodHoe;

	public static Item darkIronPickaxe;

	public static Item arrow;

	public static Item ripeWheat;

	public static Item wool;

	public static Item orange;

	public static Item bread;

	public static Item darkIronOre;

	public static Item goldOre;

	public static Item amethystOre;

	public static Item magicCrystal;

	public static Item emptyBottle;

	public static Item milkBottle;

	public static Item compass;

	public static Item indicator;

	public static Item indicatorRed;

	public static Item indicatorYellow;

	public static Item indicatorBlue;

	public static Item berries;

	public static Item ripeSugarbeet;

	public static bool hasInit;

	public Item(int _id, bool canOverlap = true)
	{
	}

	public static void Init()
	{
	}

	public void SetPrice(int price)
	{
	}

	public static Item GetItem(int index)
	{
		return null;
	}

	public static int GetItemPrice(int index)
	{
		return 0;
	}

	public static ItemCommonProperty GetItemProperty(int index)
	{
		return null;
	}
}
