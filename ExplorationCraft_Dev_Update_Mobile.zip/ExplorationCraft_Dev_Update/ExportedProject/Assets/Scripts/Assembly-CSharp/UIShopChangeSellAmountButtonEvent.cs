using UnityEngine;

public class UIShopChangeSellAmountButtonEvent : MonoBehaviour
{
	public enum ChangeType
	{
		Plus = 0,
		Minus = 1
	}

	public UIShop uiShop;

	public ChangeType changeType;

	private bool isContinousChange;

	private float timeFlag;

	private const float PRESS_TIME_DURATION = 0.5f;

	private void Start()
	{
	}

	private void OnEnable()
	{
	}

	private void Update()
	{
	}

	private void ButtonClick(GameObject go)
	{
	}

	private void SendEvent()
	{
	}

	private void DragOut(GameObject go1, GameObject go2)
	{
	}

	private void ButtonPress(GameObject go, bool isPressed)
	{
	}
}
