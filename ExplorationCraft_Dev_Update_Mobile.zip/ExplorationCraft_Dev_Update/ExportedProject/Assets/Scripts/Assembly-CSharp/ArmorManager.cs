using UnityEngine;

public class ArmorManager : MonoBehaviour
{
	public NewUIPlayerStatus uiPlayerStatus;

	public EquipMaterialController equipMaterialController;

	private ItemToolProperty[] armorProperties;

	private ItemPackageEntry[] armorPackageEntry;

	private int totalArmorDefense;

	private void Awake()
	{
	}

	public int GetTotalArmorDefense()
	{
		return 0;
	}

	public ItemToolProperty GetArmorProperty(int index)
	{
		return null;
	}

	public int GetItemId(int index)
	{
		return 0;
	}

	public ItemPackageEntry GetPackageEntry(int index)
	{
		return null;
	}

	public void EquipArmor(int index, ItemPackageEntry itemPackageEntry)
	{
	}

	private bool UnequipArmor(int index)
	{
		return false;
	}

	public void ReduceDurability()
	{
	}
}
