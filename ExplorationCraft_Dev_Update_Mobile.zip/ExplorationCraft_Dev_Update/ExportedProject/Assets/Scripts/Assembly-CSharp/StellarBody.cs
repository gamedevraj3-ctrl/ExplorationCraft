using UnityEngine;

public class StellarBody : MonoBehaviour
{
	public Transform targetCamera;

	public float distance;

	public float offset;

	private Transform tr;

	private void Awake()
	{
	}

	public void SetTime(float time)
	{
	}
}
