using UnityEngine;

public class FallObjectCreateRequest
{
	public Vector3 position;

	public int itemID;

	public int amount;

	public int durability;

	public bool checkAxis;

	public Vector3i centerAxis;

	public FallObjectCreateRequest(Vector3 position, int itemID, int amount, int durability)
	{
	}

	public FallObjectCreateRequest(Vector3 position, int itemID, int amount, int durability, Vector3i centerAxis)
	{
	}
}
