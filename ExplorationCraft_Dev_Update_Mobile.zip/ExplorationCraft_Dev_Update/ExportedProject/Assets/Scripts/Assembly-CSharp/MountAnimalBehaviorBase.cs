using BehaviorTree;

public class MountAnimalBehaviorBase : BevNodeTerminal
{
	protected MountBevInputData bevInputData;

	public MountAnimalBehaviorBase(BevNode _o_ParentNode, MountBevInputData _bevInputData)
		: base(null)
	{
	}
}
