public class CompoundBundle
{
	public Compound compound;

	public int count;

	public int finished;

	public int percentage;

	public const int MAX_BUNDLE_COUNT = 16;

	public CompoundBundle(Compound c)
	{
	}
}
