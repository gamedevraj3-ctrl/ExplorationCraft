using UnityEngine;

public class UIAchievementEntry : MonoBehaviour
{
	public UIAchievement uiAchievement;

	public string grayStarSpriteName;

	public string normalStarSpriteName;

	public string coinSpriteName;

	public string gemSpriteName;

	public string completedBtSpriteName;

	public string normalBtSpriteName;

	public UISprite imgBt;

	public UISprite[] imgStarArray;

	public UILabel txtName;

	public UILabel description;

	public UISlider progressSlider;

	public UILabel txtProgress;

	public UISprite imgMoneyType;

	public UILabel moneyAmount;

	public UISprite imgFinished;

	public void SetAchievement(Achievement achievement)
	{
	}

	private void Start()
	{
	}

	private void ButtonClick(GameObject go)
	{
	}
}
