using System;
using UnityEngine;

[AddComponentMenu("NGUI/UI/NGUI Panel")]
[ExecuteInEditMode]
public class UIPanel : UIRect
{
	public enum DebugInfo
	{
		None = 0,
		Gizmos = 1,
		Geometry = 2
	}

	public enum RenderQueue
	{
		Automatic = 0,
		StartAt = 1,
		Explicit = 2
	}

	public delegate void OnChangeDelegate();

	public static BetterList<UIPanel> list;

	public OnChangeDelegate onChange;

	public bool showInPanelTool;

	public bool generateNormals;

	public bool widgetsAreStatic;

	public bool cullWhileDragging;

	public bool alwaysOnScreen;

	public bool anchorOffset;

	public RenderQueue renderQueue;

	public int startingRenderQueue;

	[NonSerialized]
	public BetterList<UIWidget> widgets;

	[NonSerialized]
	public BetterList<UIDrawCall> drawCalls;

	[NonSerialized]
	public Matrix4x4 worldToLocal;

	[HideInInspector]
	[SerializeField]
	private float mAlpha;

	[HideInInspector]
	[SerializeField]
	private UIDrawCall.Clipping mClipping;

	[HideInInspector]
	[SerializeField]
	private Vector4 mClipRange;

	[SerializeField]
	[HideInInspector]
	private Vector2 mClipSoftness;

	[HideInInspector]
	[SerializeField]
	private int mDepth;

	private bool mRebuild;

	private bool mResized;

	private static BetterList<Vector3> mVerts;

	private static BetterList<Vector3> mNorms;

	private static BetterList<Vector4> mTans;

	private static BetterList<Vector2> mUvs;

	private static BetterList<Color32> mCols;

	private Camera mCam;

	private Vector2 mClipOffset;

	private float mCullTime;

	private float mUpdateTime;

	private int mMatrixFrame;

	private int mLayer;

	private static float[] mTemp;

	private Vector2 mMin;

	private Vector2 mMax;

	private bool mHalfPixelOffset;

	private bool mSortWidgets;

	private static Vector3[] mCorners;

	private int mAlphaFrameID;

	private static int mUpdateFrame;

	public static int nextUnusedDepth => 0;

	public override float alpha
	{
		get
		{
			return 0f;
		}
		set
		{
		}
	}

	public int depth
	{
		get
		{
			return 0;
		}
		set
		{
		}
	}

	public float width => 0f;

	public float height => 0f;

	public bool halfPixelOffset => false;

	public bool usedForUI => false;

	public Vector3 drawCallOffset => default;

	public UIDrawCall.Clipping clipping
	{
		get
		{
			return UIDrawCall.Clipping.None;
		}
		set
		{
		}
	}

	public Vector2 clipOffset
	{
		get
		{
			return default;
		}
		set
		{
		}
	}

	[Obsolete("Use 'finalClipRegion' or 'baseClipRegion' instead")]
	public Vector4 clipRange
	{
		get
		{
			return default;
		}
		set
		{
		}
	}

	public Vector4 baseClipRegion
	{
		get
		{
			return default;
		}
		set
		{
		}
	}

	public Vector4 finalClipRegion => default;

	public Vector2 clipSoftness
	{
		get
		{
			return default;
		}
		set
		{
		}
	}

	public override Vector3[] localCorners => null;

	public override Vector3[] worldCorners => null;

	public static int CompareFunc(UIPanel a, UIPanel b)
	{
		return 0;
	}

	public override Vector3[] GetSides(Transform relativeTo)
	{
		return null;
	}

	public override float CalculateFinalAlpha(int frameID)
	{
		return 0f;
	}

	public bool IsVisible(Vector3 a, Vector3 b, Vector3 c, Vector3 d)
	{
		return false;
	}

	public bool IsVisible(Vector3 worldPos)
	{
		return false;
	}

	public bool IsVisible(UIRect w)
	{
		return false;
	}

	[ContextMenu("Force Refresh")]
	public void RebuildAllDrawCalls()
	{
	}

	public void SetDirty()
	{
	}

	private void Awake()
	{
	}

	protected override void OnStart()
	{
	}

	protected override void OnInit()
	{
	}

	protected override void OnDisable()
	{
	}

	private void UpdateTransformMatrix()
	{
	}

	protected override void OnAnchor()
	{
	}

	private void LateUpdate()
	{
	}

	private void UpdateSelf()
	{
	}

	public void SortWidgets()
	{
	}

	private void FillAllDrawCalls()
	{
	}

	private void SubmitDrawCall(UIDrawCall dc)
	{
	}

	private bool FillDrawCall(UIDrawCall dc)
	{
		return false;
	}

	private void UpdateDrawCalls()
	{
	}

	private void UpdateLayers()
	{
	}

	private void UpdateWidgets()
	{
	}

	public UIDrawCall FindDrawCall(UIWidget w)
	{
		return null;
	}

	public void AddWidget(UIWidget w)
	{
	}

	public void RemoveWidget(UIWidget w)
	{
	}

	public void Refresh()
	{
	}

	public virtual Vector3 CalculateConstrainOffset(Vector2 min, Vector2 max)
	{
		return default;
	}

	public bool ConstrainTargetToBounds(Transform target, ref Bounds targetBounds, bool immediate)
	{
		return false;
	}

	public bool ConstrainTargetToBounds(Transform target, bool immediate)
	{
		return false;
	}

	public static UIPanel Find(Transform trans)
	{
		return null;
	}

	public static UIPanel Find(Transform trans, bool createIfMissing)
	{
		return null;
	}

	public static UIPanel Find(Transform trans, bool createIfMissing, int layer)
	{
		return null;
	}

	private Vector2 GetWindowSize()
	{
		return default;
	}

	public Vector2 GetViewSize()
	{
		return default;
	}
}
