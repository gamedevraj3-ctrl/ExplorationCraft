using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class EventDelegate
{
	public delegate void Callback();

	[SerializeField]
	private MonoBehaviour mTarget;

	[SerializeField]
	private string mMethodName;

	public bool oneShot;

	private Callback mCachedCallback;

	private bool mRawDelegate;

	private static int s_Hash;

	public MonoBehaviour target
	{
		get
		{
			return null;
		}
		set
		{
		}
	}

	public string methodName
	{
		get
		{
			return null;
		}
		set
		{
		}
	}

	public bool isValid => false;

	public bool isEnabled => false;

	public EventDelegate()
	{
	}

	public EventDelegate(Callback call)
	{
	}

	public EventDelegate(MonoBehaviour target, string methodName)
	{
	}

	private static string GetMethodName(Callback callback)
	{
		return null;
	}

	private static bool IsValid(Callback callback)
	{
		return false;
	}

	public override bool Equals(object obj)
	{
		return false;
	}

	public override int GetHashCode()
	{
		return 0;
	}

	private Callback Get()
	{
		return null;
	}

	private void Set(Callback call)
	{
	}

	public void Set(MonoBehaviour target, string methodName)
	{
	}

	public bool Execute()
	{
		return false;
	}

	public void Clear()
	{
	}

	public override string ToString()
	{
		return null;
	}

	public static void Execute(List<EventDelegate> list)
	{
	}

	public static bool IsValid(List<EventDelegate> list)
	{
		return false;
	}

	public static void Set(List<EventDelegate> list, Callback callback)
	{
	}

	public static void Add(List<EventDelegate> list, Callback callback)
	{
	}

	public static void Add(List<EventDelegate> list, Callback callback, bool oneShot)
	{
	}

	public static void Add(List<EventDelegate> list, EventDelegate ev)
	{
	}

	public static void Add(List<EventDelegate> list, EventDelegate ev, bool oneShot)
	{
	}

	public static bool Remove(List<EventDelegate> list, Callback callback)
	{
		return false;
	}
}
