public class BlockFarmLand : Block
{
	public BlockFarmLand(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockFarmLand(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	public override int GetDropItem(int metaData)
	{
		return 0;
	}

	public override bool NeedRandomUpdate()
	{
		return false;
	}

	public override void UpdateTick(World world, Chunk chunk, int x, int y, int z)
	{
	}
}
