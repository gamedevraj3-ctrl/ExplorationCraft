using UnityEngine;

public class UIShopPackageItemSelectEvent : MonoBehaviour
{
	public UIShopPackage uiShopPackage;

	public NewUIItemPackageEntry itemEntry;

	private void Start()
	{
	}

	private void ButtonClick(GameObject go)
	{
	}
}
