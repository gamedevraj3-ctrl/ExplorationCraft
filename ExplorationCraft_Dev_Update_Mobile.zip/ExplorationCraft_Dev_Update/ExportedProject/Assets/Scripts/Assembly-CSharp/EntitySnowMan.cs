public class EntitySnowMan : EntityLiving
{
	protected override void AddExtraBevTreeNode()
	{
	}
}
