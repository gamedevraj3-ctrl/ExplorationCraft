public class EntityMummy : EntityLiving
{
	protected override void AddExtraBevTreeNode()
	{
	}
}
