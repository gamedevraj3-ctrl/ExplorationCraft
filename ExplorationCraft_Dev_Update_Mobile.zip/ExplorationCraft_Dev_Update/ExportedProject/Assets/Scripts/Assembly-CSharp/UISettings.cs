public class UISettings : NewUIBase
{
	public UISprite imgAutoJump;

	public UILabel autoJumpSwitch;

	public UISprite imgMusic;

	public UILabel musicSwitch;

	public UISprite imgSound;

	public UILabel soundSwitch;

	public UISprite imgReverseYAsxis;

	public UILabel reverseYAxisSwitch;

	public UISprite imgSensitivity;

	public UILabel sensitivitySwitch;

	public UISprite imgIndicator;

	public UILabel indicatorSwitch;

	public UISprite imgNotification;

	public UILabel notificationSwitch;

	public string onSpriteName;

	public string offSpriteName;

	public string[] sensitivitySpriteNames;

	public TweenScale scaleTweener;

	public override void Show()
	{
	}

	public void SwitchAutoJump()
	{
	}

	public void SwitchMusic()
	{
	}

	public void SwitchSound()
	{
	}

	public void ReverseYAxis()
	{
	}

	public void ChangeSensitivity()
	{
	}

	public void ChangeIndicator()
	{
	}

	public void ChangeNotification()
	{
	}

	public void OpenCredit()
	{
	}

	public void RefreshButtons()
	{
	}
}
