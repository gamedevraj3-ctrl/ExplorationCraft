using UnityEngine;

public class UIEquipTypeSelectEvent : MonoBehaviour
{
	public NewUITabEquip uiTabEquip;

	private NewUIItemPackageEntry itemEntry;

	private void Start()
	{
	}

	private void ButtonClick(GameObject go)
	{
	}
}
