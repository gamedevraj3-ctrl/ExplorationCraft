using UnityEngine;

public class UIPlayingDismountButtonEvent : MonoBehaviour
{
	private void Start()
	{
	}

	private void ButtonClick(GameObject go)
	{
	}
}
