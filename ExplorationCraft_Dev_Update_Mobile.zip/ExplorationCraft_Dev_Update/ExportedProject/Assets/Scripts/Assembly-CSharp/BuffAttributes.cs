public class BuffAttributes
{
	public static float[] burningDamage;

	public static float[] burningDuration;

	public static float[] frozenSpeedReduce;

	public static float[] frozenDuration;

	public static float[] sleepDuration;

	private static bool hasInited;

	public static void Init(float[] _burningDamage, float[] _burningDuration, float[] _frozenSpeedReduce, float[] _frozenDuration, float[] _sleepDuration)
	{
	}
}
