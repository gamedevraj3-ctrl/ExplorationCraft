using BehaviorTree;
using UnityEngine;

public class AnimalBehavior_MagicAttackTarget : BevNodeTerminal
{
	public Entity targetEntity;

	private Vector3 direction;

	private float timeFlag;

	private float endTime;

	private float attackDuration;

	private float cooltime;

	public AnimalBehavior_MagicAttackTarget(BevNode _o_ParentNode, Entity _targetEntity, float _attackDuration, float _cooltime)
		: base(null)
	{
	}

	protected override void _DoEnter(object input)
	{
	}

	protected override BevRunningStatus _DoExecute(object input, object output)
	{
		return BevRunningStatus.k_BRS_Executing;
	}

	protected override void _DoExit(object input, BevRunningStatus _ui_ExitID)
	{
	}

	protected override bool _DoEvaluate(object input)
	{
		return false;
	}
}
