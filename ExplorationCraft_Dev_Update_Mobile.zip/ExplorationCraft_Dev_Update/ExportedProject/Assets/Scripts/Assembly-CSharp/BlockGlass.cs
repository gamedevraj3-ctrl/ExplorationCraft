public class BlockGlass : Block
{
	public BlockGlass(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockGlass(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	public override void GenBlockMesh(MeshGenerator meshGenerator, Map map, int blockX, int blockY, int blockZ, Chunk chunk, int x, int y, int z, byte blockLight)
	{
	}

	public override bool CanPlaceBlockAt(Block attachBlock, BlockFromDirection direction)
	{
		return false;
	}
}
