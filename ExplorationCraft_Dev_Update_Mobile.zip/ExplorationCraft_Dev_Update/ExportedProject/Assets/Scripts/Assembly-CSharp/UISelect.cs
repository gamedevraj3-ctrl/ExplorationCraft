using System.Collections.Generic;
using UnityEngine;

public class UISelect : NewUIBase
{
	public enum SelectMode
	{
		Normal = 0,
		Edit = 1
	}

	public UISprite imgEdit;

	public string normalSpriteName;

	public string editSpriteName;

	public UIScrollView worldList;

	public Transform listFirstPos;

	public float listOffset;

	public GameObject worldEntryPrefab;

	public SelectMode mode;

	private List<UISelectWorldEntry> uiWorldEntrys;

	private bool isFirst;

	public override void Show()
	{
	}

	public override void Hide()
	{
	}

	private void InstanceItems()
	{
	}

	private void RefreshWorldList()
	{
	}

	public void SelectWorld(UISelectWorldEntry entry)
	{
	}

	public void DeleteWorld(UISelectWorldEntry entry)
	{
	}

	public void CreateNewWorld()
	{
	}

	private void EnterWorld(WorldInfo worldInfo)
	{
	}

	public void ChangeMode()
	{
	}
}
