namespace AStar2D
{
	public class Map2D
	{
		private Node2D[,] map;

		public int xLength;

		public int yLength;

		private Map2D()
		{
		}

		public static Map2D newMap(int[,] mapFlags)
		{
			return null;
		}

		public Node2D getNode(int x, int y)
		{
			return null;
		}

		public void reset()
		{
		}
	}
}
