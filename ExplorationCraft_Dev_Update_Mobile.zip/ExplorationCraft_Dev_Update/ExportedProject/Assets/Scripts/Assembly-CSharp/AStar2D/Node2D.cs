namespace AStar2D
{
	public class Node2D
	{
		public int x;

		public int y;

		public Node2D parent;

		public int f;

		public int g;

		public int h;

		public int visitFlag;

		public bool canVisited()
		{
			return false;
		}

		public bool isInOpenTable()
		{
			return false;
		}

		public void addToCloseTable()
		{
		}

		public void addToOpenTable()
		{
		}
	}
}
