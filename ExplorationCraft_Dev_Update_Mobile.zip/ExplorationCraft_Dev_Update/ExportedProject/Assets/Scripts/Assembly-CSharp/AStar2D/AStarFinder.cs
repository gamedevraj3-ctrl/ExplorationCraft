using System.Collections.Generic;

namespace AStar2D
{
	public class AStarFinder
	{
		private List<Node2D> openList;

		private Map2D map2D;

		private Node2D startNode;

		private Node2D endNode;

		private int[] neighborOffsetXList;

		private int[] neighborOffsetYList;

		private float[] move2NeighborCostList;

		public void findPath(int xStart, int yStart, int xEnd, int yEnd)
		{
		}

		private bool checkNeighbors(Node2D currentNode)
		{
			return false;
		}

		private void checkNode(Node2D node, Node2D parent, int neighborIndex)
		{
		}

		public void addToOpenList(Node2D node)
		{
		}

		public void addToCloseList(Node2D node)
		{
		}

		public Node2D getMinFNode()
		{
			return null;
		}

		public int calcH(int x, int y)
		{
			return 0;
		}
	}
}
