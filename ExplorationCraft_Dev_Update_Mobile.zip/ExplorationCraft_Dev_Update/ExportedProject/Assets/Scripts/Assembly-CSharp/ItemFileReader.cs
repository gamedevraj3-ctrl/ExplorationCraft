public class ItemFileReader
{
	private const string ITEM_BASIC_FILE_NAME = "Item_Basic";

	private const string ITEM_MATERIAL_FILE_NAME = "Item_Material";

	private const string ITEM_COMPOUND_FILE_NAME = "Item_Compound";

	private const string ITEM_DRAWING_FILE_NAME = "Item_Drawing";

	public static bool SetItemBasic()
	{
		return false;
	}

	public static bool SetItemMaterial()
	{
		return false;
	}

	public static bool SetItemCompound()
	{
		return false;
	}

	public static bool SetItemDrawing()
	{
		return false;
	}
}
