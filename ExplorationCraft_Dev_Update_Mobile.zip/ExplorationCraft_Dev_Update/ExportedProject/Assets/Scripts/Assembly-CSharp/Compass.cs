using UnityEngine;

public class Compass : MonoBehaviour
{
	public UISprite[] imgIndicator;

	public Transform[] trIndicatorList;

	public Transform trCamera;

	public void Show()
	{
	}

	public void Hide()
	{
	}

	private void Update()
	{
	}

	private void SetIndicator(Transform trIndicator, Indicator indicator)
	{
	}
}
