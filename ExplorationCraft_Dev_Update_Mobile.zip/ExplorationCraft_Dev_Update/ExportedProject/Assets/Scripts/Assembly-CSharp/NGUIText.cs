using System.Text;
using UnityEngine;

public static class NGUIText
{
	public enum SymbolStyle
	{
		None = 0,
		Uncolored = 1,
		Colored = 2
	}

	public class GlyphInfo
	{
		public Vector2 v0;

		public Vector2 v1;

		public Vector2 u0;

		public Vector2 u1;

		public float advance;

		public int channel;

		public bool rotatedUVs;
	}

	public static UIFont bitmapFont;

	public static Font dynamicFont;

	public static GlyphInfo glyph;

	public static int size;

	public static float pixelDensity;

	public static FontStyle style;

	public static TextAlignment alignment;

	public static Color tint;

	public static int lineWidth;

	public static int lineHeight;

	public static int maxLines;

	public static bool gradient;

	public static Color gradientBottom;

	public static Color gradientTop;

	public static bool encoding;

	public static int spacingX;

	public static int spacingY;

	public static bool premultiply;

	public static SymbolStyle symbolStyle;

	public static int finalSize;

	public static float baseline;

	public static bool useSymbols;

	private static Color mInvisible;

	private static BetterList<Color> mColors;

	private static CharacterInfo mTempChar;

	private static BetterList<float> mSizes;

	private static Color32 s_c0;

	private static Color32 s_c1;

	public static void Update()
	{
	}

	public static void Update(bool request)
	{
	}

	public static void Prepare(string text)
	{
	}

	public static BMSymbol GetSymbol(string text, int index, int textLength)
	{
		return null;
	}

	public static float GetGlyphWidth(int ch, int prev)
	{
		return 0f;
	}

	public static GlyphInfo GetGlyph(int ch, int prev)
	{
		return null;
	}

	public static Color ParseColor(string text, int offset)
	{
		return default;
	}

	public static string EncodeColor(Color c)
	{
		return null;
	}

	public static int ParseSymbol(string text, int index)
	{
		return 0;
	}

	public static bool ParseSymbol(string text, ref int index)
	{
		return false;
	}

	public static bool ParseSymbol(string text, ref int index, BetterList<Color> colors, bool premultiply)
	{
		return false;
	}

	public static string StripSymbols(string text)
	{
		return null;
	}

	public static void Align(BetterList<Vector3> verts, int indexOffset, float offset)
	{
	}

	public static int GetClosestCharacter(BetterList<Vector3> verts, Vector2 pos)
	{
		return 0;
	}

	public static void EndLine(ref StringBuilder s)
	{
	}

	public static Vector2 CalculatePrintedSize(string text)
	{
		return default;
	}

	public static int CalculateOffsetToFit(string text)
	{
		return 0;
	}

	public static string GetEndOfLineThatFits(string text)
	{
		return null;
	}

	public static void RequestCharactersInTexture(Font font, string text)
	{
	}

	public static bool WrapText(string text, out string finalText)
	{
		finalText = null;
		return false;
	}

	public static void Print(string text, BetterList<Vector3> verts, BetterList<Vector2> uvs, BetterList<Color32> cols)
	{
	}

	public static void PrintCharacterPositions(string text, BetterList<Vector3> verts, BetterList<int> indices)
	{
	}

	public static void PrintCaretAndSelection(string text, int start, int end, BetterList<Vector3> caret, BetterList<Vector3> highlight)
	{
	}
}
