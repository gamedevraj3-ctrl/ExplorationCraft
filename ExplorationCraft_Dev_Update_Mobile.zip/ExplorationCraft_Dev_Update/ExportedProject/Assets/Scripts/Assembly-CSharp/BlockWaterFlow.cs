using UnityEngine;

public class BlockWaterFlow : BlockWaterStill
{
	public BlockWaterFlow(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockWaterFlow(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	protected OccupyType IsBlockWaterCanFlowTo(Map map, Vector3i pos)
	{
		return OccupyType.None;
	}

	public override bool NeedUpdate()
	{
		return false;
	}

	public override void UpdateTick(World world, Chunk chunk, int x, int y, int z)
	{
	}

	public Vector3 GetFlowDirection(Map map, int worldX, int worldY, int worldZ)
	{
		return default;
	}

	public override void GenBlockMesh(MeshGenerator meshGenerator, Map map, int blockX, int blockY, int blockZ, Chunk chunk, int x, int y, int z, byte blockLight)
	{
	}

	public override int GetDropItem(int metaData)
	{
		return 0;
	}
}
