using System;
using System.Collections.Generic;

public interface IBatchProcessor<T>
{
	void Process(List<T> itemsToProcess, Action<T> action, bool waitUntilAllThreadsFinishh);

	void Process(int numberOfThreads, List<T> itemsToProcess, Action<T> action, bool waitUntilAllThreadsFinish);
}
