public class EntityPig : EntityLiving
{
	protected override void AddExtraBevTreeNode()
	{
	}

	protected override void SpawnFavorParticle()
	{
	}
}
