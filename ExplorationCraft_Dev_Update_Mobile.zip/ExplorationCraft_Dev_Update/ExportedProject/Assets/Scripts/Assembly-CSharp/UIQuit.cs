public class UIQuit : NewUIBase
{
	public UIWidget titleContainer;

	public UIWidget btContainer;

	public float titlePositionTopNormal;

	public float titlePositionTopNoAd;

	public float titlePositionBottomNormal;

	public float titlePositionBottomNoAd;

	public float btPositionTopNormal;

	public float btPositionTopNoAd;

	public float btPositionBottomNormal;

	public float btPositionBottomNoAd;

	public override void Show()
	{
	}

	public override void Hide()
	{
	}

	public void HandleQuitEvent()
	{
	}
}
