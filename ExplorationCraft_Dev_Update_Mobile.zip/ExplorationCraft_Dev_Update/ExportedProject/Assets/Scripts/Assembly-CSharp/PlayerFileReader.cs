public class PlayerFileReader
{
	private const string PLAYER_ARROW_FILE_NAME = "Player_Arrow";

	private const string PLAYER_BUFF_FILE_NAME = "Player_Buff";

	private const string PLAYER_EXPERIENCE_FILE_NAME = "Player_Experience";

	private const string PLAYER_COMBAT_SKILL_FILE_NAME = "Player_Combat_Skill";

	private const string PLAYER_PASSIVE_SKILL_FILE_NAME = "Player_Passive_Skill";

	public static bool SetPlayerAttribute()
	{
		return false;
	}

	private static bool SetArrowAttribute()
	{
		return false;
	}

	private static bool SetBuffAttribute()
	{
		return false;
	}

	private static bool SetSkill()
	{
		return false;
	}

	private static bool SetExperience()
	{
		return false;
	}
}
