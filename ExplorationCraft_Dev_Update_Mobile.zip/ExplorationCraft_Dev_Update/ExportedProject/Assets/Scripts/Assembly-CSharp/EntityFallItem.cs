using UnityEngine;

public class EntityFallItem : EntityFallObject
{
	private Transform cameraTr;

	protected override void StartInternal()
	{
	}

	protected override void UpdateInternal()
	{
	}

	public override bool IsStaticEntity()
	{
		return false;
	}
}
