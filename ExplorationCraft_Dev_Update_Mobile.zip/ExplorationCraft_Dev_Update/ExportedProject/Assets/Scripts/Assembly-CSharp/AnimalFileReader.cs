public class AnimalFileReader
{
	private const string DUNGEON_FILE_NAME = "Dungeon_Basic";

	private const string ANIMAL_FEEDING_FILE_NAME = "Animal_Feeding";

	public static bool SetAnimalAttribute()
	{
		return false;
	}

	private static bool SetMountFeeding()
	{
		return false;
	}

	private static bool SetDungeon()
	{
		return false;
	}
}
