using System.Collections.Generic;

public class CompundTable
{
	private static int availableCount;

	private static int furnanceCompoundCount;

	private static List<Compound> compounds;

	public static List<Compound> availableCompounds;

	public static List<Compound>[] typedCompoundList;

	public static Compound GetCompund(int id)
	{
		return null;
	}

	public static void Init()
	{
	}

	public static void AddCompound(Compound c)
	{
	}

	public static int GetAvailableCount()
	{
		return 0;
	}

	public static int GetFurnanceCompoundCount()
	{
		return 0;
	}
}
