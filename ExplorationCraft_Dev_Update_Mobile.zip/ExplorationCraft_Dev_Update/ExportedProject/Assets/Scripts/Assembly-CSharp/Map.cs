using System.Collections.Generic;

public class Map
{
	public int chunkRectWidthX;

	public int chunkRectWidthZ;

	public int chunkBlockCountX;

	public int chunkBlockCountZ;

	public int maxHeight;

	private Chunk[] loadedChunks;

	public int chunkRectMinX;

	public int chunkRectMinZ;

	public int chunkRectMaxX;

	public int chunkRectMaxZ;

	public int chunkRectMinBlockX;

	public int chunkRectMinBlockZ;

	public int chunkRectMaxBlockX;

	public int chunkRectMaxBlockZ;

	public Queue<Chunk> chunksNeedToMesh;

	private List<Chunk> saveChunksInBossStage;

	public Map(int widthX, int widthZ)
	{
	}

	public void InitializeGridChunks(int playerChunkX, int playerChunkZ)
	{
	}

	public void ResetMapCenter(int chunkX, int chunkZ)
	{
	}

	public int GetHeight(int worldX, int worldZ)
	{
		return 0;
	}

	public int GetPrecipitationHeight(int worldX, int worldZ)
	{
		return 0;
	}

	public int GetPrecipitationHeightInBossStage(int worldX, int worldZ)
	{
		return 0;
	}

	public void MarkBlockUpdate(int x, int y, int z)
	{
	}

	public void MarkBlockLightDirt(int x, int y, int z)
	{
	}

	public Block GetBlock(int x, int y, int z)
	{
		return null;
	}

	public BlockType GetBlockType(int x, int y, int z)
	{
		return BlockType.Air;
	}

	public void SetBlockType(int x, int y, int z, BlockType blockType)
	{
	}

	public void SetBlockMetaData(int x, int y, int z, int data)
	{
	}

	public void SetSkyLight(int x, int y, int z, byte light)
	{
	}

	public byte GetSkyLight(int x, int y, int z)
	{
		return 0;
	}

	public void SetBlockLight(int x, int y, int z, byte light)
	{
	}

	public byte GetBlockLight(int x, int y, int z)
	{
		return 0;
	}

	public byte GetBlockLightValue(int x, int y, int z)
	{
		return 0;
	}

	public int GetBlockMetaData(int x, int y, int z)
	{
		return 0;
	}

	public int GetBiomeAt(int x, int z)
	{
		return 0;
	}

	public bool IsAirBlock(int x, int y, int z)
	{
		return false;
	}

	public bool IsChunkExist(int chunkX, int chunkZ)
	{
		return false;
	}

	public Chunk GetChunk(int chunkX, int chunkZ)
	{
		return null;
	}

	public Chunk GetRectLocalChunk(int localX, int localZ)
	{
		return null;
	}

	public void SetRectLocalChunk(Chunk chunk, int loclaX, int localZ)
	{
	}

	public void SetChunk(Chunk chunk)
	{
	}

	public bool IsBlockExist(int x, int y, int z)
	{
		return false;
	}

	public int GetChunkRectCenterX()
	{
		return 0;
	}

	public int GetChunkRectCenterZ()
	{
		return 0;
	}

	public void SetBlockAfterDigging(int x, int y, int z, BlockFromDirection direction)
	{
	}

	public List<Chunk> GetAllChunks()
	{
		return null;
	}

	public List<Chunk> GetAllVisibleChunks()
	{
		return null;
	}

	public List<Chunk> GetAllChunksInBossStage()
	{
		return null;
	}

	public List<Chunk> GetAllVisibleChunksInBossStage()
	{
		return null;
	}

	public List<Chunk> GetAllUnusedChunksInBossStage()
	{
		return null;
	}

	public void UpdateTick(World world)
	{
	}

	public void RandomUpdateTick(World world)
	{
	}

	public void SpawnMonster(World world)
	{
	}

	public void GenMesh(World world)
	{
	}

	public void SaveDirtChunks()
	{
	}
}
