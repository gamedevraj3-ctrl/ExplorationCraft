public enum DiggingConvertType
{
	None = 0,
	Air = 1,
	WaterStill = 2,
	LavaStill = 3
}
