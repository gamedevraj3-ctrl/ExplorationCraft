using UnityEngine;

public class UIPurchaseConfirmationInMain : UIPurchaseComfirmation
{
	public GameObject objMoney;

	public override void OnComfirm()
	{
	}

	public override void ShowInAppPurchaseCoin()
	{
	}

	public override void ShowInAppPurchaseGem()
	{
	}
}
