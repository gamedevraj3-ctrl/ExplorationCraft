using System.Collections.Generic;

public class MyProfiler
{
	private static float timeStart;

	private static List<float> stepTimeList;

	public static void Start()
	{
	}

	public static void Step()
	{
	}

	public static float EndAndLog(string name)
	{
		return 0f;
	}
}
