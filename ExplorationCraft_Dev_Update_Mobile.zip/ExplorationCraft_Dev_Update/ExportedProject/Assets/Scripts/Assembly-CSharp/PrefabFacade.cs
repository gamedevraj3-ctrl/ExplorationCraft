using System;
using UnityEngine;

[Serializable]
public class PrefabFacade
{
	public GameObject prefab;

	public string prefabName;

	public bool isInstanceByName;

	private GameObject loadedPrefab;

	public GameObject Instantiate()
	{
		return null;
	}
}
