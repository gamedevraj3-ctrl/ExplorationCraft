public class ItemConverter
{
	public ItemPackage itemPackage;

	public ItemConverter(ItemPackage _itemPackage)
	{
	}

	public int GetCanConvertCompoundCount(Compound compound)
	{
		return 0;
	}

	public int GetConvertType(Compound compound, bool ignoreDrawing = true)
	{
		return 0;
	}

	public bool IsCompoundOk(Compound compound)
	{
		return false;
	}

	public virtual void Convert(Compound compound)
	{
	}

	protected void UseMaterials(Compound compound)
	{
	}

	protected bool ClaimResult(Compound compound)
	{
		return false;
	}

	public void EndCompound(Compound compound)
	{
	}

	public void SortCompounds(Compound[] compounds)
	{
	}
}
