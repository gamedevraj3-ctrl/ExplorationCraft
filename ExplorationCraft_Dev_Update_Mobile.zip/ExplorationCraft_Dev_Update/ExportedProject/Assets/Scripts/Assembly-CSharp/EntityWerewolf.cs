public class EntityWerewolf : EntityBoss
{
	protected override void AddExtraBevTreeNode()
	{
	}
}
