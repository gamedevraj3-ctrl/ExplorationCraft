public class CompoundDrawing
{
	public bool isUnlocked;

	public MoneyType moneyType;

	public int price;

	public CompoundDrawing(MoneyType moneyType, int price)
	{
	}

	public void SetUnlockState(bool isUnlocked)
	{
	}
}
