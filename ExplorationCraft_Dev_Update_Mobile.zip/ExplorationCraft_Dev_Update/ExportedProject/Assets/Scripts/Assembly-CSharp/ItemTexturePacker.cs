using UnityEngine;

public class ItemTexturePacker : MonoBehaviour
{
	public ItemTextureUnion[] textureArrayList;

	public AtlasTexture atlas;
}
