public class DailyBonusController
{
	public const string LAST_LOGIN_TAG = "LastLogin";

	public const string CONTINOUS_LOGIN_DAYS_TAG = "ContinousLogin";

	public const int MAX_CONTINOUS_LOGIN_DAYS = 7;

	public int continousLoginDays;

	public bool needShowDailyBonus;

	public bool NeedShowDailyBonus()
	{
		return false;
	}

	public void SetContinousLoginDays()
	{
	}
}
