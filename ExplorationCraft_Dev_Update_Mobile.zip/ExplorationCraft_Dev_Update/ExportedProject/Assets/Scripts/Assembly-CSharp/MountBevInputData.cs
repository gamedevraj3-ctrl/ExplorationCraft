using System;

[Serializable]
public class MountBevInputData
{
	public TamedEntityModel entity;
}
