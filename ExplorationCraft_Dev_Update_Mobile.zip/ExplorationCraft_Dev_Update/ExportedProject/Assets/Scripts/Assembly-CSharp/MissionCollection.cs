public class MissionCollection : Mission
{
	private int itemID;

	public MissionCollection(string description, int param, IMissionPrecondition precondition, int experience, int type, int amount)
		: base(null, 0, null, 0, 0, 0)
	{
	}

	public MissionCollection(string description, int param, IMissionPrecondition precondition, int itemID, int experience, int type, int amount)
		: base(null, 0, null, 0, 0, 0)
	{
	}

	public override void SetActive()
	{
	}

	public override bool CheckComplete()
	{
		return false;
	}

	public override void OnComplete()
	{
	}

	public override string GetProgress()
	{
		return null;
	}
}
