using UnityEngine;

public class UIDailyBonusEntry : MonoBehaviour
{
	public enum BonusType
	{
		Coin = 0,
		Gem = 1,
		Mount = 2,
		Mix = 3
	}

	public UISprite imgBackground;

	public UISprite imgCheck;

	public TweenScale scaleTweener;

	public string unclaimSpriteName;

	public string claimedSpriteName;

	public BonusType bonusType;

	public int bonusAmount;

	public int extraCoinAmount;

	public int extraGemAmount;

	public void SetClaimed()
	{
	}

	public void SetUnclaimed()
	{
	}

	public void SetNeedClaim()
	{
	}

	public void Check()
	{
	}
}
