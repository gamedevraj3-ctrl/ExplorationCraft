using System.Collections.Generic;
using UnityEngine;

public class ProjectileFactory : MonoInstance<ProjectileFactory>
{
	private const int PROJECTILE_TYPE_COUNT = 9;

	public GameObject[] projectilePrefabs;

	private List<GameObject>[] usingOjs;

	private List<GameObject>[] storedOjs;

	private Queue<ProjectileCreateRequest> createRequest;

	private Queue<EntityProjectile> recycleRequest;

	private new void Awake()
	{
	}

	private void Update()
	{
	}

	public GameObject Create(ProjectileType type, Vector3 pos, Quaternion rot, Quaternion targetRot, float speed, float damage, Entity.CollideLayer collideLayer, Vector3 sourcePos, int buffLevel = 0)
	{
		return null;
	}

	public GameObject Create(ProjectileType type, Vector3 pos, Quaternion rot, Quaternion targetRot, float speed, float damage, Entity.CollideLayer collideLayer, Vector3 sourcePos, bool checkAxis, Vector3i centerAxis, int buffLevel = 0)
	{
		return null;
	}

	public void Recycle(EntityProjectile projectile)
	{
	}

	public void AddCreateRequest(ProjectileCreateRequest request)
	{
	}

	public void AddRecycleRequest(EntityProjectile entity)
	{
	}

	public void RecycleAllUnused()
	{
	}
}
