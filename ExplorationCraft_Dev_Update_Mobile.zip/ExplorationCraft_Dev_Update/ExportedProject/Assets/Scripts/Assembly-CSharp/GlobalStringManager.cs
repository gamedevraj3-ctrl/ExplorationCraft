using System.Collections.Generic;

public class GlobalStringManager
{
	public static Dictionary<string, string> dict;

	public static TipsManager tips;

	private const string STRING_FILE = "Strings";

	private const string TIPS_FILE = "Tips";

	public static bool Initialize()
	{
		return false;
	}

	private static bool ReadStrings()
	{
		return false;
	}

	private static bool ReadTips()
	{
		return false;
	}
}
