using UnityEngine;

public class NewUITabMount : NewUITabBase
{
	public TamedEntityManager tamedEntityManager;

	public ItemPackage itemPackage;

	public GameObject lockedGroup;

	public GameObject unlockedGroup;

	public UISprite selectedMountFlag;

	public UISprite uiSummoningFavorability;

	public UISprite uiSummoningLackFavorability;

	public int selectedPage;

	public UIMountPageButtonEvent[] pageFlag;

	public TamedEntityModel[] tamedEntityModels;

	public string feedSpriteName;

	public UISprite imgFeedItem;

	public UILabel txtFeedCount;

	public UISprite imgTameItem;

	public UISprite unlockMoneyType;

	public UILabel unlockPrice;

	public string coinSpriteName;

	public string gemSpriteName;

	public UIPanel feedPanel;

	public UIScrollView feedItemList;

	public Transform feedListFirstPos;

	public float feedListOffset;

	public GameObject prefabFeedEntry;

	public GameObject ojDialogFeedList;

	public UIButton pagePrev;

	public UIButton pageNext;

	private NewUIItemPackageEntry[] uiFeedEntrys;

	private bool hasInstanceItem;

	private bool isShowingDialogFeed;

	private string errorMessage;

	public bool forbidFeed;

	public UISprite imgSummonBack;

	public UISprite imgFavorBack0;

	public UISprite imgFavorBack1;

	public UISprite imgFavorBack2;

	public NewUIItemPackageEntry GetFeedEntry(int feedID)
	{
		return null;
	}

	public override void Show()
	{
	}

	public override bool IsLevelLimited()
	{
		return false;
	}

	public override string GetErrorMessage()
	{
		return null;
	}

	public override void InstanceItems()
	{
	}

	public void SetSelectPrev()
	{
	}

	public void SetSelectNext()
	{
	}

	public void SetSelect(int index)
	{
	}

	public void SelectSummoningMount()
	{
	}

	private void RefreshSelectedMountFlag()
	{
	}

	public void HandleFeedButtonEvent()
	{
	}

	public void HandleAddFeedEvent(NewUIItemPackageEntry itemEntry)
	{
	}

	private void ShowDialogFeed()
	{
	}

	public void HideDialogFeed()
	{
	}

	private void RevertFeed()
	{
	}

	private void RefreshFeedList()
	{
	}

	private void SetFeed(FeedController feedController, int itemID)
	{
	}

	private void RefreshPage()
	{
	}

	public override void Hide()
	{
	}

	private void RefreshPageFlag()
	{
	}

	private void SetPrice(MoneyType type, int price)
	{
	}

	public void RefreshFeed()
	{
	}

	public void BuySelectedMount()
	{
	}

	public void PurchaseCallBack()
	{
	}
}
