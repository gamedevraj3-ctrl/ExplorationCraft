using LibNbt;
using UnityEngine;

public class TestNbt : MonoBehaviour
{
	public NbtFile nbtFile;

	public static string rootPath;

	private void Start()
	{
	}

	private void Update()
	{
	}
}
