using UnityEngine;

public class UIQuestCheckButtonEvent : MonoBehaviour
{
	public UIQuestEntry uiQuestEntry;

	private void Start()
	{
	}

	private void ButtonClick(GameObject go)
	{
	}
}
