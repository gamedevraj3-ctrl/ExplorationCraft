using System;
using UnityEngine;

[Serializable]
public class ItemTextureUnion
{
	public int id;

	public Texture2D texture;
}
