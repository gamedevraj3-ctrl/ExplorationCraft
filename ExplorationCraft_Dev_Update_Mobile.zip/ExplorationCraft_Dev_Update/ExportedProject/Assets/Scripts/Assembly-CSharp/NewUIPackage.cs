using UnityEngine;

public class NewUIPackage : NewUIBase
{
	public ItemPackage itemPackage;

	public int currentSelect;

	public NewUITabCrafting uiTabCrafting;

	public NewUITabHolder uiTabHolder;

	public NewUITabMount uiTabMount;

	public string[] backgroundSpriteNames;

	public UISprite background;

	public GameObject buttonMask;

	public UIPanel uiPanelPackage;

	public UISprite imgCrafting;

	public UISprite imgCraftingTitle;

	public UISprite imgClose;

	public UISprite imgMount;

	public UISprite imgMountTitle;

	private void Awake()
	{
	}

	private void OnChangeItemListTab(int fromIndex, int toIndex)
	{
	}

	public override void Show()
	{
	}

	public void ShowCrafting()
	{
	}

	public void HideUIPackage()
	{
	}

	public void HideAfterDeath()
	{
	}
}
