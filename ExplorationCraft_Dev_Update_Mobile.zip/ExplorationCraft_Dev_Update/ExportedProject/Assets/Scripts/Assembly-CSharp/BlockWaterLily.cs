public class BlockWaterLily : Block
{
	private float[] waterLilyAABBOffset;

	public BlockWaterLily(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockWaterLily(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	public override void GenBlockMesh(MeshGenerator meshGenerator, Map map, int blockX, int blockY, int blockZ, Chunk chunk, int x, int y, int z, byte blockLight)
	{
	}

	public override float[] GetAABBOffset(int metaData)
	{
		return null;
	}

	public override bool CanPlaceBlockAt(Block attachBlock, BlockFromDirection direction)
	{
		return false;
	}
}
