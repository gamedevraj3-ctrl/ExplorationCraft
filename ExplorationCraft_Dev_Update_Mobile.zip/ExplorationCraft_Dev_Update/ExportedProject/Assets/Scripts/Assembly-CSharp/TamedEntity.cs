using System;

[Serializable]
public class TamedEntity
{
	public bool isUnlocked;

	public MoneyType moneyType;

	public int price;

	public int id;

	public float summoningFavorability;

	public int maxSummoningFavorability;

	public int summoningSucceedFavorability;

	public float summoningFavorDec;

	public float summoningFavorDecPerMeter;

	public FeedController feedController;

	public EntityLiving summonedEntity;
}
