public class BlockWater : Block
{
	public BlockWater(BlockType type)
		: base(BlockType.Air)
	{
	}

	public BlockWater(BlockType type, DiggingType material)
		: base(BlockType.Air)
	{
	}

	public override void GenBlockMesh(MeshGenerator meshGenerator, Map map, int blockX, int blockY, int blockZ, Chunk chunk, int x, int y, int z, byte blockLight)
	{
	}

	public override bool OnHit(AABB hitAABB)
	{
		return false;
	}

	public override DiggingConvertType ConvertAfterDiggingAround(BlockFromDirection direction, int metaData)
	{
		return DiggingConvertType.None;
	}

	public override int GetDropItem(int metaData)
	{
		return 0;
	}
}
