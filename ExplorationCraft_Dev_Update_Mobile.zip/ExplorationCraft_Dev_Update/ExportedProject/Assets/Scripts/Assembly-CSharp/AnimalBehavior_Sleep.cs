using BehaviorTree;

public class AnimalBehavior_Sleep : BevNodeTerminal
{
	public AnimalBehavior_Sleep(BevNode _o_ParentNode)
		: base(null)
	{
	}

	protected override void _DoEnter(object input)
	{
	}

	protected override BevRunningStatus _DoExecute(object input, object output)
	{
		return BevRunningStatus.k_BRS_Executing;
	}

	protected override bool _DoEvaluate(object input)
	{
		return false;
	}
}
