using UnityEngine;

public class UIConverterFuelSelectEvent : MonoBehaviour
{
	public NewUIConverter uiConverter;

	private NewUIItemPackageEntry itemEntry;

	private void Start()
	{
	}

	private void ButtonClick(GameObject go)
	{
	}
}
